package com.crf.ratingmotor.domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 * The five dates the maturity mismatch rule needs.
 *
 * <p>The rule is the same for every kind of credit protection (guarantee, credit insurance, collateral).
 * The components are named after the guarantee, the first product built; the factory methods below put a
 * credit insurance's or a collateral's dates in the guarantee's place, so every "guarantee" calculation in
 * {@link MaturityAssessment} then reads as "credit insurance" or "collateral".</p>
 */
public record MaturityDates(LocalDate currentDate,
                            LocalDate guaranteeImplementationDate, LocalDate guaranteeMaturityDate,
                            LocalDate facilityImplementationDate, LocalDate facilityMaturityDate) {
    public MaturityDates {
        Objects.requireNonNull(currentDate, "currentDate");
        Objects.requireNonNull(guaranteeImplementationDate, "guaranteeImplementationDate");
        Objects.requireNonNull(guaranteeMaturityDate, "guaranteeMaturityDate");
        Objects.requireNonNull(facilityImplementationDate, "facilityImplementationDate");
        Objects.requireNonNull(facilityMaturityDate, "facilityMaturityDate");
    }

    /** Maturity dates for a credit insurance: its dates take the guarantee's place. */
    public static MaturityDates forCreditInsurance(LocalDate currentDate,
                                                   LocalDate creditInsurerImplementationDate,
                                                   LocalDate creditInsurerMaturityDate,
                                                   LocalDate facilityImplementationDate,
                                                   LocalDate facilityMaturityDate) {
        return forProtection("creditInsurer", currentDate, creditInsurerImplementationDate, creditInsurerMaturityDate,
                             facilityImplementationDate, facilityMaturityDate);
    }

    /** Maturity dates for a collateral: its dates take the guarantee's place. */
    public static MaturityDates forCollateral(LocalDate currentDate,
                                              LocalDate collateralImplementationDate,
                                              LocalDate collateralMaturityDate,
                                              LocalDate facilityImplementationDate,
                                              LocalDate facilityMaturityDate) {
        return forProtection("collateral", currentDate, collateralImplementationDate, collateralMaturityDate,
                             facilityImplementationDate, facilityMaturityDate);
    }

    /** Checks the protection's own dates first, so a missing date is reported with the request's field name. */
    private static MaturityDates forProtection(String protection, LocalDate currentDate,
                                               LocalDate implementationDate, LocalDate maturityDate,
                                               LocalDate facilityImplementationDate, LocalDate facilityMaturityDate) {
        Objects.requireNonNull(implementationDate, protection + "ImplementationDate");
        Objects.requireNonNull(maturityDate, protection + "MaturityDate");
        return new MaturityDates(currentDate, implementationDate, maturityDate,
                                 facilityImplementationDate, facilityMaturityDate);
    }
}
