package com.crf.ratingmotor.application.collateral;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Request from crf-back for the collateral expected recovery.
 *
 * <p>Format rules only (presence, ranges, patterns). Units and currencies arrive as text and are converted
 * with {@code Unit.from} and {@code CurrencyCode} in the application service, as for guarantees and credit
 * insurance, so an invalid value is a 400 that names the field.</p>
 */
@Schema(description = "Inputs sent by crf-back to compute the expected recovery on a collateral")
public record CollateralComputeQuery(

    @Schema(description = "Date on which crf-back calls the rating motor", example = "2026-11-26")
    @NotNull LocalDate currentDate,

    @Schema(example = "2025-01-01")
    @NotNull LocalDate collateralImplementationDate,

    @Schema(example = "2031-01-01")
    @NotNull LocalDate collateralMaturityDate,

    @Schema(description = "Percent 0..100", example = "60")
    @NotNull @DecimalMin("0") @DecimalMax("100") BigDecimal proposedRecoveryRateOnCollateral,

    @Schema(description = "0 or more, expressed in currentEconomicValueUnit", example = "12")
    @NotNull @PositiveOrZero BigDecimal currentEconomicValue,

    @Schema(allowableValues = {"UNIT", "THOUSAND", "MILLION", "BILLION", "TRILLION"}, example = "MILLION")
    @NotBlank @Pattern(regexp = "(?i)UNIT|THOUSAND|MILLION|BILLION|TRILLION")
    String currentEconomicValueUnit,

    @Schema(description = "ISO 4217 code", example = "EUR")
    @NotBlank @Pattern(regexp = "\\s*[A-Za-z]{3}\\s*", message = "must be a 3-letter currency code")
    String currentEconomicValueCurrency,

    @Schema(description = "Percent 0..100", example = "50")
    @NotNull @DecimalMin("0") @DecimalMax("100") BigDecimal allocationRate,

    @Schema(example = "2025-01-01")
    @NotNull LocalDate facilityImplementationDate,

    @Schema(example = "2030-01-01")
    @NotNull LocalDate facilityMaturityDate,

    @Schema(description = "0 or more, expressed in facilityUnit", example = "10")
    @NotNull @PositiveOrZero BigDecimal facilityAmount,

    @Schema(allowableValues = {"UNIT", "THOUSAND", "MILLION", "BILLION", "TRILLION"}, example = "MILLION")
    @NotBlank @Pattern(regexp = "(?i)UNIT|THOUSAND|MILLION|BILLION|TRILLION")
    String facilityUnit,

    @Schema(description = "ISO 4217 code", example = "EUR")
    @NotBlank @Pattern(regexp = "\\s*[A-Za-z]{3}\\s*", message = "must be a 3-letter currency code")
    String facilityCurrency,

    @Schema(description = "Required only when the currencies differ", example = "1")
    @Positive BigDecimal facilityToCollateralCurrencyRate,

    @Schema(description = "Required only when the currencies differ", example = "1")
    @Positive BigDecimal collateralToFacilityCurrencyRate,

    @Schema(description = "Collateral currency exists in the currency_mismatch nomenclature", example = "true")
    @NotNull Boolean currentEconomicCurrencyExistFlag,

    @Schema(description = "Nomenclature discount as a fraction (0.085 = 8.5%)", example = "0.085")
    @DecimalMin("0") @DecimalMax("1") BigDecimal currencyMismatch
) {}
