package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.domain.DayCountConvention;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.MaturityAssessment;
import com.crf.ratingmotor.domain.MaturityDates;
import com.crf.ratingmotor.domain.MaturityMismatchIndicator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static com.crf.ratingmotor.domain.TestValues.assertApproximately;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/**
 * Collateral driver #1, discount related to a maturity mismatch (Dmm). The guarantee rule is reused unchanged,
 * with the collateral's dates in place of the guarantee's. Offsets are days from "today" (2026-01-01) under
 * ACT/365 Fixed, so 365 days is exactly 1 year. Argument order of dates(...): collateral start, collateral end,
 * facility start, facility end. Expected values are worked out by hand from the specification.
 */
class CollateralMaturityMismatchTest {

    private static final LocalDate TODAY = LocalDate.of(2026, 1, 1);

    private static MaturityDates dates(int collateralStart, int collateralEnd, int facilityStart, int facilityEnd) {
        return MaturityDates.forCollateral(TODAY,
            TODAY.plusDays(collateralStart), TODAY.plusDays(collateralEnd),
            TODAY.plusDays(facilityStart), TODAY.plusDays(facilityEnd));
    }

    private static MaturityAssessment assess(int collateralStart, int collateralEnd, int facilityStart, int facilityEnd) {
        return MaturityAssessment.of(dates(collateralStart, collateralEnd, facilityStart, facilityEnd),
                                     DayCountConvention.ACT_365_FIXED);
    }

    private static DiscountMaturityMismatchDriver driver(int collateralStart, int collateralEnd, int facilityStart, int facilityEnd) {
        return new DiscountMaturityMismatchDriver(assess(collateralStart, collateralEnd, facilityStart, facilityEnd));
    }

    @Test
    @DisplayName("the collateral's dates take the guarantee's place")
    void mapsCollateralDates() {
        MaturityDates d = dates(-10, 20, -30, 40);

        assertThat(d.currentDate()).isEqualTo(TODAY);
        assertThat(d.guaranteeImplementationDate()).isEqualTo(TODAY.plusDays(-10));
        assertThat(d.guaranteeMaturityDate()).isEqualTo(TODAY.plusDays(20));
        assertThat(d.facilityImplementationDate()).isEqualTo(TODAY.plusDays(-30));
        assertThat(d.facilityMaturityDate()).isEqualTo(TODAY.plusDays(40));
    }

    @Nested
    @DisplayName("Calculations 1 to 3: residual and initial maturities")
    class Maturities {

        @Test
        @DisplayName("1. residual facility counts from today, or from the facility start if later")
        void residualFacility() {
            assertExactly(assess(-365, 2000, -365, 730).residualFacility(), "2");   // from today
            assertExactly(assess(-365, 2000, 365, 1095).residualFacility(), "2");   // from facility start
        }

        @Test
        @DisplayName("2. residual collateral counts from the latest of collateral start, today and facility start")
        void residualCollateral() {
            assertExactly(assess(-365, 730, -730, 2000).residualGuarantee(), "2");  // today is latest
            assertExactly(assess(365, 1095, -365, 2000).residualGuarantee(), "2");  // collateral start is latest
            assertExactly(assess(-365, 1095, 365, 2000).residualGuarantee(), "2");  // facility start is latest
        }

        @Test
        @DisplayName("3. initial collateral counts from the later of collateral start and facility start, ignoring today")
        void initialCollateral() {
            assertExactly(assess(-365, 730, -730, 2000).initialGuarantee(), "3");   // collateral start is later
            assertExactly(assess(-730, 730, -365, 2000).initialGuarantee(), "3");   // facility start is later
        }
    }

    @Nested
    @DisplayName("Calculation 4: maturity mismatch flag")
    class Flag {

        @Test
        @DisplayName("0 when the collateral outlives the facility")
        void collateralOutlivesFacility() {
            assertThat(assess(-365, 1460, -365, 730).indicator()).isEqualTo(MaturityMismatchIndicator.NO_MISMATCH);
        }

        @Test
        @DisplayName("0 when both end on the same day")
        void sameMaturity() {
            assertThat(assess(-365, 730, -365, 730).indicator()).isEqualTo(MaturityMismatchIndicator.NO_MISMATCH);
        }

        @Test
        @DisplayName("1 when the collateral ends one day before the facility")
        void oneDayShort() {
            assertThat(assess(-365, 729, -365, 730).indicator()).isEqualTo(MaturityMismatchIndicator.MISMATCH);
        }

        @Test
        @DisplayName("0 when the collateral starts after the facility and has not started yet")
        void notYetStarted() {
            MaturityAssessment a = assess(100, 400, -365, 1460);
            assertThat(a.guaranteeNotYetStarted()).isTrue();
            assertThat(a.indicator()).isEqualTo(MaturityMismatchIndicator.NO_MISMATCH);
        }

        @Test
        @DisplayName("1 when the collateral started after the facility but is already running")
        void startedAfterFacility() {
            MaturityAssessment a = assess(-100, 400, -365, 1460);
            assertThat(a.guaranteeNotYetStarted()).isFalse();
            assertThat(a.indicator()).isEqualTo(MaturityMismatchIndicator.MISMATCH);
        }
    }

    @Nested
    @DisplayName("Calculation 5: discount related to a maturity mismatch")
    class Discount {

        @Test
        @DisplayName("flag 0: 0%")
        void noMismatch() {
            assertExactly(driver(-365, 1460, -365, 730).getEstimateValue(), "0");
        }

        @Test
        @DisplayName("flag 1, residual collateral of 91 days (under 3 months): 100%")
        void underThreeMonths() {
            assertExactly(driver(-365, 91, -365, 1460).getEstimateValue(), "1");
        }

        @Test
        @DisplayName("flag 1, initial collateral of 364 days (under 1 year): 100%")
        void underOneYear() {
            assertExactly(driver(0, 364, 0, 1460).getEstimateValue(), "1");
        }

        @Test
        @DisplayName("flag 1, t = 2 and T = 4: 1 - 1.75 / 3.75")
        void partial() {
            DiscountMaturityMismatchDriver d = driver(-365, 730, -365, 1460);
            assertThat(d.getName()).isEqualTo("DISCOUNT_MATURITY_MISMATCH");
            assertApproximately(d.getEstimateValue(), "0.5333333333333333333333333333");
        }

        @Test
        @DisplayName("flag 1, t = 2 and T = 6 capped to 5: 1 - 1.75 / 4.75")
        void facilityCappedAtFiveYears() {
            assertApproximately(driver(-365, 730, -365, 2190).getEstimateValue(), "0.6315789473684210526315789474");
        }

        @Test
        @DisplayName("flag 1, t = 6 and T = 7, both capped to 5: 0%")
        void bothCapped() {
            assertExactly(driver(-365, 2190, -365, 2555).getEstimateValue(), "0");
        }

        @Test
        @DisplayName("collateral not started yet: 0%")
        void notYetStarted() {
            assertExactly(driver(100, 120, -365, 1460).getEstimateValue(), "0");
        }
    }

    @Test
    @DisplayName("missing collateral dates are reported with the collateral field names")
    void nullDatesNamedForCollateral() {
        LocalDate d = TODAY;
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityDates.forCollateral(d, null, d, d, d))
            .withMessage("collateralImplementationDate");
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityDates.forCollateral(d, d, null, d, d))
            .withMessage("collateralMaturityDate");
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityDates.forCollateral(null, d, d, d, d))
            .withMessage("currentDate");
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityDates.forCollateral(d, d, d, null, d))
            .withMessage("facilityImplementationDate");
    }
}
