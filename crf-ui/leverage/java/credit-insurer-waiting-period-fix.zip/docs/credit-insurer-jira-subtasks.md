# Credit Insurer Expected Recovery: JIRA Sub-tasks

---

## Sub-task 1: Request contract and reference enums

**Summary:** Define `CreditInsurerComputeQuery` and the two enums, with every type and rule confirmed by Clara.

**Description:** crf-back sends 18 fields for a credit insurance. Several types were unknown at the start; they were clarified with Clara and implemented as Bean Validation rules, so invalid requests are rejected with a 400 before any calculation.

**Work done:**
- **Request record `CreditInsurerComputeQuery`:**
  - Dates (`currentDate`, credit insurer start and end, facility start and end) are required.
  - `oecdFlag`, `positiveRecoveryFlag`, `waitingPeriodInterestCovered` and `prorataShareOfExpectedRecovery` are required booleans.
  - `pctOfBnppFinancingCoveredByCreditInsurer` and `sugrr` are 0..100.
  - `facilityAmount` is 0 or more (0 allowed, as confirmed by Clara); `facilityUnit` was added (UNIT to TRILLION).
  - Both ratings accept 1..10 with an optional + or -.
  - Every field has a Swagger `@Schema` description and example.
- **`CreditInsurerType` enum:** 8 values: the 5 from the first list and the 3 from the user story ("First demand Guarantee", "Insurance policy from ECA", "Insurance policy from private insurer"). The story takes precedence.
- **`WaitingPeriod` enum:** 4 periods ("Less than 31 D", "31-90 D", "91-210 D", "More than 210 D"), each carrying its waiting period decote.
- **Parsing:** `from(text)` on both enums accepts the label or the constant name, ignoring case and surrounding spaces; anything else is a 400 naming the field.
- **Percentages kept as `BigDecimal`:** a `Float` such as 33.3 converts to 33.29999923706055, which would leak into a financial result.

**Tests:** `CreditInsurerEnumsTest`

**Open points:**
- "Guarantee at 1rt demand SBLC": check the exact label crf-back sends ("1rt" may be a typo for "1st").
- `sugrr` and `prorataShareOfExpectedRecovery` are validated but not used in any formula yet.

---

## Sub-task 2: Credit insurer correlation reference data (database, persistence, cache)

**Summary:** Store the 6 × 10 credit insurer correlation table in PostgreSQL and serve it through a cached repository.

**Description:** The table has a different shape from the guarantee tables (6 × 10, no LOW/HIGH split), so it has its own database table instead of rows in the guarantee table.

**Work done:**
- **Table `facility_grr_pgnnr_credit_insurer_correlation_coefficient_matrix`:**
  - Columns `id`, `credit_insurer_rating`, `guarantor_rating`, `coefficient NUMERIC(10,6)`.
  - Unique constraint on (credit_insurer_rating, guarantor_rating); checks on ratings (1..6 and 1..10) and on the coefficient (0..1).
  - The column is named `coefficient`, not `value`, to avoid the H2 reserved word.
- **Migration script:** creates the table and inserts the 60 values, written in percent as in the specification and divided by 100 on insert (92.0 is stored as 0.92). Re-runnable with `ON CONFLICT ... DO UPDATE`.
- **JPA:** entity `CreditInsurerCorrelationCoefficientEntity` and DAO `CreditInsurerCorrelationCoefficientDao`.
- **Repository adapter `CreditInsurerCorrelationMatrixRepositoryImpl`:** reads the 60 rows and builds the table. No rows, a missing cell or a rating out of range in the database is a server error (500) that names the problem.
- **Cache `CachingCreditInsurerCorrelationMatrixRepository`:** `@Primary` decorator; Caffeine cache `creditInsurerCorrelationMatrix` added to `CacheNames`; one fixed key; `evict()` available.
- **Test data:** `credit-insurer-correlation-seed.sql`, portable between H2 and PostgreSQL; run against H2 2.2 and checked.

**Tests:** `CreditInsurerCorrelationMatrixRepositoryTest`

---

## Sub-task 3: Driver 1, correlation coefficient

**Summary:** Look up the correlation coefficient between the debtor and the credit insurer.

**Work done:**
- **`RatingGrid` (shared, new):** a validated, immutable table addressed by two ratings, any size up to 10 × 10. It checks the exact size and that no cell is empty, and keeps a defensive copy.
- **`CreditInsurerCorrelationMatrix`:** the 6 × 10 table built on `RatingGrid`; credit insurer rating picks the row, guarantor rating the column.
- **Ratings above 6:** a credit insurer rated 7 to 10 has no row; its coefficient is 0 (confirmed by Clara). Rating 6 is still read from the table.
- **Signs:** ratings are parsed with the existing `CounterpartyRating`, so `1-` and `6+` read cell [1, 6].
- **`CreditInsurerCorrelationCoefficientDriver`:** name `CORRELATION_COEFFICIENT` (same as guarantees, confirmed by Clara); keeps both ratings for the audit trail.

**Tests:** `RatingGridTest`, `CreditInsurerCorrelationCoefficientDriverTest` (every cell checked against the business table)

---

## Sub-task 4: Driver 2, maturity mismatch discount (Dmm)

**Summary:** Apply the guarantee maturity mismatch rule to the credit insurance dates.

**Work done:**
- **Reuse, no new driver:** the rule is identical to the guarantee one. `MaturityDates.forCreditInsurance(...)` puts the credit insurer's start and end dates in place of the guarantee's dates; `MaturityAssessment` and `DiscountMaturityMismatchDriver` are used unchanged.
- **Benefit:** any later fix to the rule applies to both products; the guarantee code Clara tested is untouched.
- **Same settings:** ACT/365 Fixed day count, the 3-month and 1-year thresholds, the 5-year caps, and the "not started yet" rule.
- **Error messages:** a missing credit insurer date is reported with its credit insurer field name.

**Tests:** `CreditInsurerMaturityMismatchTest`

---

## Sub-task 5: Driver 3, waiting period decote (Ddci)

**Summary:** Discount for the time the bank waits before the credit insurer pays.

**Work done:**
- **`WaitingPeriodDecoteDriver`**, name `WAITING_PERIOD_DECOTE`:
  - 0% when the waiting-period interest is not covered, or the type is "First demand Guarantee" (BA fix, 27 Nov 2026).
  - Otherwise 0%, 1%, 2% or 3% by waiting period (under 31 days, 31-90, 91-210, over 210).
- **Decote values** live in the `WaitingPeriod` enum, so the table is defined once.
- **Audit trail:** the driver keeps the interest-covered flag, the type and the waiting period.

**Tests:** `CreditInsurerDecoteDriversTest` (each period, interest not covered for every period, "First demand Guarantee" for every period, every other type not exempt, the BA-reported case)

**Resolved:** the BA found that "First demand Guarantee" with interest covered got 1% instead of 0%. The exemption is now "First demand Guarantee"; "Guarantee at 1rt demand SBLC" gets the regular decote (change log item 18).

---

## Sub-task 6: Driver 4, additional decote (Dfe)

**Summary:** 10% additional discount for some credit insurance types.

**Work done:**
- **`AdditionalDecoteDriver`**, name `ADDITIONAL_DECOTE`. 10% when:
  1. the type is "Insurance policy from ECA" and the OECD flag or the positive recovery flag is true;
  2. the type is "First demand Guarantee";
  3. the type is "Insurance policy from private insurer".
- **Otherwise 0%,** including the other five types even when both flags are true.
- **Audit trail:** the driver keeps the type and both flags.

**Tests:** `CreditInsurerDecoteDriversTest` (full truth table)

---

## Sub-task 7: Expected recovery on the credit insurer (Gac, RecupEAC, RecupTAC, RecupEAC_F)

**Summary:** Implement the main calculation as the domain service `CreditInsurerExpectedRecoveryCalculatorDomainService`.

**Work done:**
- **`CreditInsuranceCoverage`:** Gac = facility amount × unit × covered percentage / 100; the percentage is checked to be 0..100.
- **`CreditInsurerRecoveryFactors`:** groups the four drivers and lists them in a fixed order for the response.
- **Calculations:**
  1. RecupEAC = Gac × (1 − Dmm) × (1 − Ddci) × (1 − Dfe) × correlation coefficient.
  2. RecupTAC (%) = RecupEAC / Gac × 100.
  3. RecupEAC_F = RecupEAC.
- **Special cases:**
  - Credit insurance not started yet: RecupEAC, RecupTAC and RecupEAC_F are 0; Gac is still returned.
  - Gac of 0 (facility amount 0, or 0% covered): RecupTAC is 0 instead of dividing by zero.
- **Result names** (from the specification's wording): `facilityAmountCoveredByCreditInsurer`, `expectedRecoveryOnCreditInsurer`, `recoveryRateOnCreditInsurerPercent`, `expectedRecoveryInFacilityCurrency`.
- **Units:** drivers are fractions, so the specification's (1 − x/100) is (1 − x) in the code, as for guarantees.
- **Design:** framework-free domain service, registered as a bean in `RatingMotorConfig`, with full Javadoc.

**Tests:** `CreditInsurerExpectedRecoveryCalculatorDomainServiceTest`

**Open points:**
- Confirm with Clara that RecupTAC should be 0 when Gac is 0.
- Confirm that the correlation coefficient should be in the drivers list (it was not in the output list).

---

## Sub-task 8: Application service and REST endpoint

**Summary:** Expose `POST calculate/creditInsurerExpectedRecoveryAmount`.

**Work done:**
- **`CreditInsurerRecoveryComputeManagementService`:** translates the request into domain types, loads the cached table, builds the four drivers and the coverage, and calls the domain service. No business rules.
- **`RequiredValues` (shared, new):** `required` and `requiredFlag`, so a missing value is a 400 naming the field. The guarantee service can switch to it to remove duplicate code.
- **`CreditInsurerExpectedRecoveryResponse`:** the four results and the four drivers; amounts rounded to 2 decimals, the rate and drivers to 6, HALF_UP. Reuses the guarantee `DriverValue`.
- **`CreditInsurerComputeController`:** `@Valid` request body, Swagger `@Operation` and responses.
- **Error handling:** the existing exception handler's scope now includes the new controller.

**Tests:** `CreditInsurerRecoveryComputeManagementServiceTest`, `CreditInsurerExpectedRecoveryResponseTest`

**Open points:**
- Confirm the endpoint path with crf-back.
- Controller slice tests and the integration test for this endpoint are not written yet; they follow the guarantee ones.

---

## Sub-task 9: Unit tests and quality

**Summary:** Test suite for the credit insurer calculation.

**Work done:**
- **167 credit insurer tests,** all passing; 436 in the module including guarantees.
- **Coverage:** 100% of lines and branches in the domain and application layers.
- **Hand-worked examples** from the specification:
  - worked example: Gac 8,000,000, RecupEAC 6,771,600, RecupTAC 84.645%
  - no discount (SBLC, interest not covered, top-rated insurer): RecupEAC = Gac
  - all factors combined: 401.6964 on a covered amount of 1,000
  - credit insurer rated 7, not started yet, Gac of 0
- **Deliberate-bug check:** `||` changed to `&&` in both decote rules, the coefficient used as 1 − x, RecupEAC_F set to Gac, rating 6 treated as outside the table. Each one makes tests fail.
- **Shared fixtures:** `CreditInsurerTables` (the business table in percent), `CreditInsurerFactorsBuilder`, `CreditInsurerComputeQueryBuilder`.

---

## Sub-task 10: Specification analysis and clarifications

**Summary:** Record the questions raised while building the credit insurer calculation and the answers.

**Work done:**
- **Closed with Clara:** ratings above 6 give 0; `guarantorCounterpartyRating` is the table's column axis; all field types; facility amount 0 allowed; driver name `CORRELATION_COEFFICIENT`.
- **Decided by the team:** a separate table for credit insurers; reuse of the guarantee maturity rule; story values added to `CreditInsurerType`; `BigDecimal` for percentages.
- **Still open:**
  - RecupTAC when Gac is 0.
  - Correlation coefficient in the drivers list.
  - Use of `sugrr` and `prorataShareOfExpectedRecovery`.
  - Endpoint path with crf-back.
