package com.crf.ratingmotor.domain.creditinsurer;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class CreditInsurerDecoteDriversTest {

    @Nested
    @DisplayName("Calculation 1: waiting period decote (Ddci)")
    class WaitingPeriodDecote {

        @ParameterizedTest(name = "{0} -> {1}")
        @CsvSource({
            "LESS_THAN_31_DAYS,   0",
            "FROM_31_TO_90_DAYS,  0.01",
            "FROM_91_TO_210_DAYS, 0.02",
            "MORE_THAN_210_DAYS,  0.03"
        })
        @DisplayName("interest covered: the decote depends on the waiting period")
        void byWaitingPeriod(WaitingPeriod period, String expected) {
            WaitingPeriodDecoteDriver driver = new WaitingPeriodDecoteDriver(true, CreditInsurerType.CROSS_GUARANTEES, period);
            assertExactly(driver.getEstimateValue(), expected);
            assertExactly(period.decote(), expected);
        }

        @ParameterizedTest(name = "{0}")
        @EnumSource(WaitingPeriod.class)
        @DisplayName("interest not covered: 0% whatever the waiting period")
        void interestNotCovered(WaitingPeriod period) {
            assertExactly(new WaitingPeriodDecoteDriver(false, CreditInsurerType.CROSS_GUARANTEES, period).getEstimateValue(), "0");
        }

        @ParameterizedTest(name = "{0}")
        @EnumSource(WaitingPeriod.class)
        @DisplayName("First demand Guarantee: 0% even with interest covered (BA fix, change log item 18)")
        void firstDemandGuarantee(WaitingPeriod period) {
            assertExactly(new WaitingPeriodDecoteDriver(true, CreditInsurerType.FIRST_DEMAND_GUARANTEE, period)
                .getEstimateValue(), "0");
        }

        @Test
        @DisplayName("BA case: \"First Demand guarantee\", interest covered, 31-90 days -> 0%, not 1%")
        void baReportedCase() {
            WaitingPeriodDecoteDriver driver = new WaitingPeriodDecoteDriver(true,
                CreditInsurerType.from("First Demand guarantee"), WaitingPeriod.FROM_31_TO_90_DAYS);
            assertExactly(driver.getEstimateValue(), "0");
        }

        @ParameterizedTest(name = "{0}")
        @EnumSource(value = CreditInsurerType.class, mode = EnumSource.Mode.EXCLUDE, names = "FIRST_DEMAND_GUARANTEE")
        @DisplayName("every other type, SBLC included, gets the regular decote when interest is covered")
        void otherTypesAreNotExempt(CreditInsurerType type) {
            assertExactly(new WaitingPeriodDecoteDriver(true, type, WaitingPeriod.FROM_31_TO_90_DAYS)
                .getEstimateValue(), "0.01");
        }

        @Test
        void exposesNameAndInputs() {
            WaitingPeriodDecoteDriver d = new WaitingPeriodDecoteDriver(true, CreditInsurerType.GUARANTEE,
                WaitingPeriod.FROM_91_TO_210_DAYS);
            assertThat(d.getName()).isEqualTo("WAITING_PERIOD_DECOTE").isEqualTo(WaitingPeriodDecoteDriver.NAME);
            assertThat(d.waitingPeriodInterestCovered()).isTrue();
            assertThat(d.creditInsurerType()).isEqualTo(CreditInsurerType.GUARANTEE);
            assertThat(d.waitingPeriod()).isEqualTo(WaitingPeriod.FROM_91_TO_210_DAYS);
        }

        @Test
        void rejectsNulls() {
            assertThatNullPointerException()
                .isThrownBy(() -> new WaitingPeriodDecoteDriver(true, null, WaitingPeriod.LESS_THAN_31_DAYS))
                .withMessage("creditInsurerType");
            assertThatNullPointerException()
                .isThrownBy(() -> new WaitingPeriodDecoteDriver(true, CreditInsurerType.GUARANTEE, null))
                .withMessage("waitingPeriod");
        }
    }

    @Nested
    @DisplayName("Calculation 2: additional decote (Dfe)")
    class AdditionalDecote {

        @ParameterizedTest(name = "{0}, OECD={1}, positive recovery={2} -> {3}")
        @CsvSource({
            "INSURANCE_POLICY_FROM_ECA,             true,  false, 0.10",
            "INSURANCE_POLICY_FROM_ECA,             false, true,  0.10",
            "INSURANCE_POLICY_FROM_ECA,             true,  true,  0.10",
            "INSURANCE_POLICY_FROM_ECA,             false, false, 0",
            "FIRST_DEMAND_GUARANTEE,                false, false, 0.10",
            "FIRST_DEMAND_GUARANTEE,                true,  true,  0.10",
            "INSURANCE_POLICY_FROM_PRIVATE_INSURER, false, false, 0.10",
            "INSURANCE_POLICY_FROM_PRIVATE_INSURER, true,  false, 0.10"
        })
        void storyTypes(CreditInsurerType type, boolean oecd, boolean positiveRecovery, String expected) {
            assertExactly(new AdditionalDecoteDriver(type, oecd, positiveRecovery).getEstimateValue(), expected);
        }

        @ParameterizedTest(name = "{0}")
        @EnumSource(value = CreditInsurerType.class, names = {"GUARANTEE", "GUARANTEE_AT_FIRST_DEMAND_SBLC",
            "CROSS_GUARANTEES", "OTHER_PERSONAL_OR_CORPORATE_GUARANTEE", "THIRD_PARTY_COMMITMENTS"})
        @DisplayName("the other types get 0%, even with both flags set")
        void otherTypes(CreditInsurerType type) {
            assertExactly(new AdditionalDecoteDriver(type, true, true).getEstimateValue(), "0");
        }

        @Test
        void exposesNameAndInputs() {
            AdditionalDecoteDriver d = new AdditionalDecoteDriver(CreditInsurerType.INSURANCE_POLICY_FROM_ECA, true, false);
            assertThat(d.getName()).isEqualTo("ADDITIONAL_DECOTE").isEqualTo(AdditionalDecoteDriver.NAME);
            assertThat(d.creditInsurerType()).isEqualTo(CreditInsurerType.INSURANCE_POLICY_FROM_ECA);
            assertThat(d.oecdFlag()).isTrue();
            assertThat(d.positiveRecoveryFlag()).isFalse();
        }

        @Test
        void rejectsNullType() {
            assertThatNullPointerException()
                .isThrownBy(() -> new AdditionalDecoteDriver(null, false, false))
                .withMessage("creditInsurerType");
        }
    }
}
