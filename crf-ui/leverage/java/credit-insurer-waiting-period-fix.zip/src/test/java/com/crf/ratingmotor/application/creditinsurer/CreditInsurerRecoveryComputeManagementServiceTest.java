package com.crf.ratingmotor.application.creditinsurer;

import com.crf.ratingmotor.domain.DayCountConvention;
import com.crf.ratingmotor.domain.Driver;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerExpectedRecovery;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerTables;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDate;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

import static com.crf.ratingmotor.application.creditinsurer.CreditInsurerComputeQueryBuilder.creditInsurerQuery;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/** Real domain service and the real 6 x 10 table behind a fake repository; no Spring context. */
class CreditInsurerRecoveryComputeManagementServiceTest {

    private int loads;
    private CreditInsurerRecoveryComputeManagementService service;

    @BeforeEach
    void setUp() {
        service = new CreditInsurerRecoveryComputeManagementService(
            () -> { loads++; return CreditInsurerTables.matrix(); },
            DayCountConvention.ACT_365_FIXED,
            new CreditInsurerExpectedRecoveryCalculatorDomainService());
    }

    @Nested
    @DisplayName("end-to-end through the domain")
    class HappyPath {

        @Test
        @DisplayName("worked example: RecupEAC = 6,771,600, RecupTAC = 84.645%")
        void workedExample() {
            CreditInsurerExpectedRecovery r = service.compute(creditInsurerQuery().build()).recovery();

            assertExactly(r.facilityAmountCoveredByCreditInsurer(), "8000000");
            assertExactly(r.expectedRecoveryOnCreditInsurer(), "6771600");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "84.645");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "6771600");
            assertThat(loads).isEqualTo(1);
        }

        @Test
        @DisplayName("BA bug: \"First Demand guarantee\", interest covered, 31-90 D -> waiting period decote 0%, not 1%")
        void firstDemandGuaranteeHasNoWaitingPeriodDecote() {
            CreditInsurerRecoveryComputeResult result = service.compute(creditInsurerQuery()
                .creditInsurerType("First Demand guarantee").waitingPeriodInterestCovered(true).waitingPeriod("31-90 D")
                .build());

            assertExactly(result.drivers().get(2).getEstimateValue(), "0");
            assertExactly(result.drivers().get(3).getEstimateValue(), "0.10");
            // 8,000,000 x (1 - 0) x (1 - 0) x (1 - 0.10) x 0.95; it was 6,771,600 with the 1% decote
            assertExactly(result.recovery().expectedRecoveryOnCreditInsurer(), "6840000");
            assertExactly(result.recovery().recoveryRateOnCreditInsurerPercent(), "85.5");
        }

        @Test
        @DisplayName("returns the four drivers with their values")
        void drivers() {
            List<Driver> drivers = service.compute(creditInsurerQuery().build()).drivers();

            assertThat(drivers).extracting(Driver::getName).containsExactly(
                "CORRELATION_COEFFICIENT", "DISCOUNT_MATURITY_MISMATCH", "WAITING_PERIOD_DECOTE", "ADDITIONAL_DECOTE");
            assertExactly(drivers.get(0).getEstimateValue(), "0.95");
            assertExactly(drivers.get(1).getEstimateValue(), "0");
            assertExactly(drivers.get(2).getEstimateValue(), "0.01");
            assertExactly(drivers.get(3).getEstimateValue(), "0.10");
        }

        @Test
        @DisplayName("credit insurer dates drive the maturity mismatch")
        void creditInsurerDatesUsed() {
            // Credit insurance for 2 more years on a facility with 4 left: Dmm = 1 - 1.75/3.75
            List<Driver> drivers = service.compute(creditInsurerQuery()
                .currentDate(LocalDate.of(2026, 1, 1))
                .creditInsurerImplementationDate(LocalDate.of(2025, 1, 1)).creditInsurerMaturityDate(LocalDate.of(2028, 1, 1))
                .facilityImplementationDate(LocalDate.of(2025, 1, 1)).facilityMaturityDate(LocalDate.of(2029, 12, 31))
                .build()).drivers();

            assertThat(drivers.get(1).getEstimateValue().getValue().doubleValue()).isCloseTo(0.533333, org.assertj.core.data.Offset.offset(1e-6));
        }

        @Test
        @DisplayName("credit insurance not started yet: zero recovery")
        void notYetStarted() {
            CreditInsurerExpectedRecovery r = service.compute(creditInsurerQuery()
                .creditInsurerImplementationDate(LocalDate.of(2027, 1, 1)).build()).recovery();

            assertExactly(r.expectedRecoveryOnCreditInsurer(), "0");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "0");
        }

        @Test
        @DisplayName("facility amount 0 is allowed (confirmed by Clara): everything is 0")
        void zeroFacilityAmount() {
            CreditInsurerExpectedRecovery r = service.compute(creditInsurerQuery().facilityAmount("0").build()).recovery();

            assertExactly(r.facilityAmountCoveredByCreditInsurer(), "0");
            assertExactly(r.expectedRecoveryOnCreditInsurer(), "0");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "0");
        }

        @Test
        @DisplayName("credit insurer rated 8: coefficient 0")
        void creditInsurerAboveSix() {
            List<Driver> drivers = service.compute(creditInsurerQuery().creditInsurerCounterpartyRating("8-").build()).drivers();
            assertExactly(drivers.get(0).getEstimateValue(), "0");
        }

        @Test
        @DisplayName("types and waiting periods are accepted by label or constant name")
        void labelsAndNames() {
            List<Driver> drivers = service.compute(creditInsurerQuery()
                .creditInsurerType("insurance_policy_from_private_insurer").waitingPeriod("MORE_THAN_210_DAYS").build()).drivers();

            assertExactly(drivers.get(2).getEstimateValue(), "0.03");
            assertExactly(drivers.get(3).getEstimateValue(), "0.10");
        }
    }

    @Nested
    @DisplayName("invalid input is a client error (IllegalArgumentException)")
    class InvalidInput {

        @ParameterizedTest(name = "{0}")
        @MethodSource("com.crf.ratingmotor.application.creditinsurer.CreditInsurerRecoveryComputeManagementServiceTest#invalidQueries")
        void rejected(String expectedMessage, UnaryOperator<CreditInsurerComputeQueryBuilder> change) {
            CreditInsurerComputeQuery q = change.apply(creditInsurerQuery()).build();
            assertThatIllegalArgumentException()
                .isThrownBy(() -> service.compute(q))
                .withMessageStartingWith(expectedMessage);
        }

        @Test
        void nullQuery() {
            assertThatNullPointerException().isThrownBy(() -> service.compute(null)).withMessage("query");
        }
    }

    static Stream<Arguments> invalidQueries() {
        return Stream.of(
            Arguments.of("Unknown creditInsurerType", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.creditInsurerType("Letter of comfort")),
            Arguments.of("creditInsurerType must not be null", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.creditInsurerType(null)),
            Arguments.of("Unknown waitingPeriod", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.waitingPeriod("90 D")),
            Arguments.of("waitingPeriodInterestCovered must not be null", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.waitingPeriodInterestCovered(null)),
            Arguments.of("oecdFlag must not be null", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.oecdFlag(null)),
            Arguments.of("positiveRecoveryFlag must not be null", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.positiveRecoveryFlag(null)),
            Arguments.of("facilityAmount must not be null", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.facilityAmount(null)),
            Arguments.of("Amount must not be negative", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.facilityAmount("-1")),
            Arguments.of("Unknown Unit", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.facilityUnit("HUNDRED")),
            Arguments.of("pctOfBnppFinancingCoveredByCreditInsurer must not be null", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.pctOfBnppFinancingCoveredByCreditInsurer(null)),
            Arguments.of("pctOfBnppFinancingCoveredByCreditInsurer must be between 0 and 100", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.pctOfBnppFinancingCoveredByCreditInsurer("120")),
            Arguments.of("Invalid rating", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.guarantorCounterpartyRating("A")),
            Arguments.of("Rating must be 1..10", (UnaryOperator<CreditInsurerComputeQueryBuilder>) b -> b.creditInsurerCounterpartyRating("11")));
    }
}
