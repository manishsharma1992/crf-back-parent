package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.Driver;
import com.crf.ratingmotor.domain.MaturityScenarios;
import com.crf.ratingmotor.domain.UnitAmount;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static com.crf.ratingmotor.domain.TestValues.assertApproximately;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static com.crf.ratingmotor.domain.creditinsurer.CreditInsurerFactorsBuilder.factors;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/** Every expected value is worked out by hand from the specification. */
class CreditInsurerExpectedRecoveryCalculatorDomainServiceTest {

    private final CreditInsurerExpectedRecoveryCalculatorDomainService calculator =
        new CreditInsurerExpectedRecoveryCalculatorDomainService();

    private static CreditInsuranceCoverage coverage(String amount, Unit unit, String coveredPercent) {
        return new CreditInsuranceCoverage(new UnitAmount(rv(amount), unit), rv(coveredPercent));
    }

    @Nested
    @DisplayName("Calculation 3: amount of the facility covered by the credit insurer (Gac)")
    class Coverage {

        @ParameterizedTest(name = "{0} {1} x {2}% = {3}")
        @CsvSource({
            "10,   MILLION,  80,    8000000",
            "10,   MILLION,  100,   10000000",
            "2.5,  THOUSAND, 33.3,  832.5",
            "0,    MILLION,  80,    0",
            "10,   MILLION,  0,     0"
        })
        void coveredAmount(String amount, Unit unit, String percent, String expected) {
            assertExactly(coverage(amount, unit, percent).facilityAmountCoveredByCreditInsurer(), expected);
        }

        @ParameterizedTest(name = "{0}% is rejected")
        @ValueSource(strings = {"-0.01", "100.01", "150"})
        void rejectsPercentOutsideZeroToHundred(String percent) {
            UnitAmount facility = new UnitAmount(rv("1"), Unit.MILLION);
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new CreditInsuranceCoverage(facility, rv(percent)))
                .withMessageStartingWith("pctOfBnppFinancingCoveredByCreditInsurer must be between 0 and 100");
        }

        @Test
        void rejectsNulls() {
            UnitAmount facility = new UnitAmount(rv("1"), Unit.MILLION);
            assertThatNullPointerException().isThrownBy(() -> new CreditInsuranceCoverage(null, rv("1"))).withMessage("facility");
            assertThatNullPointerException().isThrownBy(() -> new CreditInsuranceCoverage(facility, null))
                .withMessage("financingCoveredPercent");
        }
    }

    @Nested
    @DisplayName("RecupEAC, RecupTAC and RecupEAC_F")
    class Recovery {

        @Test
        @DisplayName("worked example: ECA policy, OECD, 31-90 days covered, ratings 3 and 5")
        void workedExample() {
            // Gac      = 10,000,000 x 80% = 8,000,000
            // RecupEAC = 8,000,000 x (1 - 0) x (1 - 0.01) x (1 - 0.10) x 0.95 = 6,771,600
            // RecupTAC = 6,771,600 / 8,000,000 x 100 = 84.645
            CreditInsurerExpectedRecovery r = calculator.calculate(coverage("10", Unit.MILLION, "80"),
                factors().ratings(3, 5).type(CreditInsurerType.INSURANCE_POLICY_FROM_ECA).flags(true, false)
                    .waitingPeriod(true, WaitingPeriod.FROM_31_TO_90_DAYS).build());

            assertExactly(r.facilityAmountCoveredByCreditInsurer(), "8000000");
            assertExactly(r.expectedRecoveryOnCreditInsurer(), "6771600");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "84.645");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "6771600");
        }

        @Test
        @DisplayName("SBLC, top-rated insurer, fully covered, interest not covered: no discount at all")
        void noDiscount() {
            CreditInsurerExpectedRecovery r = calculator.calculate(coverage("5", Unit.MILLION, "100"),
                factors().type(CreditInsurerType.GUARANTEE_AT_FIRST_DEMAND_SBLC).flags(true, true)
                    .waitingPeriod(false, WaitingPeriod.MORE_THAN_210_DAYS).build());

            assertExactly(r.expectedRecoveryOnCreditInsurer(), "5000000");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "100");
        }

        @Test
        @DisplayName("First demand Guarantee, interest covered: Ddci 0%, Dfe 10% -> RecupEAC = 90% of Gac")
        void firstDemandGuarantee() {
            CreditInsurerExpectedRecovery r = calculator.calculate(coverage("5", Unit.MILLION, "100"),
                factors().type(CreditInsurerType.FIRST_DEMAND_GUARANTEE)
                    .waitingPeriod(true, WaitingPeriod.MORE_THAN_210_DAYS).build());

            assertExactly(r.expectedRecoveryOnCreditInsurer(), "4500000");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "90");
        }

        @Test
        @DisplayName("every factor is applied once and with the right sense")
        void allFactorsCombined() {
            // 1000 x (1 - 0.5333...) x (1 - 0.03) x (1 - 0.10) x 0.986 = 401.6964
            // = 1000 x (1.75 / 3.75) x 0.97 x 0.9 x 0.986
            CreditInsurerExpectedRecovery r = calculator.calculate(coverage("1000", Unit.UNIT, "100"),
                factors().ratings(5, 8).maturity(MaturityScenarios.partialMismatch())
                    .type(CreditInsurerType.INSURANCE_POLICY_FROM_PRIVATE_INSURER)
                    .waitingPeriod(true, WaitingPeriod.MORE_THAN_210_DAYS).build());

            assertApproximately(r.expectedRecoveryOnCreditInsurer(), "401.6964");
            assertApproximately(r.recoveryRateOnCreditInsurerPercent(), "40.16964");
        }

        @Test
        @DisplayName("credit insurer rated 7: coefficient 0, so recovery 0 through the formula")
        void creditInsurerAboveSix() {
            CreditInsurerExpectedRecovery r = calculator.calculate(coverage("10", Unit.MILLION, "80"),
                factors().ratings(7, 5).build());

            assertExactly(r.facilityAmountCoveredByCreditInsurer(), "8000000");
            assertExactly(r.expectedRecoveryOnCreditInsurer(), "0");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "0");
        }

        @Test
        @DisplayName("credit insurance not started yet: RecupEAC, RecupTAC and RecupEAC_F are 0, Gac is still shown")
        void notYetStarted() {
            CreditInsurerExpectedRecovery r = calculator.calculate(coverage("10", Unit.MILLION, "80"),
                factors().maturity(MaturityScenarios.guaranteeNotYetStarted()).build());

            assertExactly(r.facilityAmountCoveredByCreditInsurer(), "8000000");
            assertExactly(r.expectedRecoveryOnCreditInsurer(), "0");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "0");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "0");
        }

        @ParameterizedTest(name = "facility {0} at {1}% covered")
        @CsvSource({"0, 80", "10, 0"})
        @DisplayName("Gac of 0: RecupTAC is 0 instead of dividing by zero")
        void zeroCoveredAmount(String amount, String percent) {
            CreditInsurerExpectedRecovery r = calculator.calculate(coverage(amount, Unit.MILLION, percent), factors().build());

            assertExactly(r.facilityAmountCoveredByCreditInsurer(), "0");
            assertExactly(r.expectedRecoveryOnCreditInsurer(), "0");
            assertExactly(r.recoveryRateOnCreditInsurerPercent(), "0");
        }

        @Test
        @DisplayName("RecupEAC_F always equals RecupEAC")
        void facilityCurrencyEqualsExpectedRecovery() {
            CreditInsurerExpectedRecovery r = calculator.calculate(coverage("3.7", Unit.BILLION, "61.5"),
                factors().ratings(4, 7).waitingPeriod(true, WaitingPeriod.FROM_91_TO_210_DAYS).build());

            assertThat(r.expectedRecoveryInFacilityCurrency()).isEqualTo(r.expectedRecoveryOnCreditInsurer());
        }

        @Test
        void rejectsNulls() {
            CreditInsuranceCoverage c = coverage("1", Unit.UNIT, "100");
            CreditInsurerRecoveryFactors f = factors().build();
            assertThatNullPointerException().isThrownBy(() -> calculator.calculate(null, f)).withMessage("coverage");
            assertThatNullPointerException().isThrownBy(() -> calculator.calculate(c, null)).withMessage("factors");
        }
    }

    @Nested
    @DisplayName("factors")
    class Factors {

        @Test
        @DisplayName("four drivers are reported, in a fixed order")
        void reportedDrivers() {
            CreditInsurerRecoveryFactors f = factors().build();
            assertThat(f.reportedDrivers()).extracting(Driver::getName).containsExactly(
                "CORRELATION_COEFFICIENT", "DISCOUNT_MATURITY_MISMATCH", "WAITING_PERIOD_DECOTE", "ADDITIONAL_DECOTE");
            assertThat(f.reportedDrivers()).containsExactly(f.correlation(), f.maturity(), f.waitingPeriod(), f.additional());
        }

        @Test
        void notYetStarted() {
            assertThat(factors().build().creditInsuranceNotYetStarted()).isFalse();
            assertThat(factors().maturity(MaturityScenarios.guaranteeNotYetStarted()).build().creditInsuranceNotYetStarted())
                .isTrue();
        }

        @Test
        void rejectsNulls() {
            CreditInsurerRecoveryFactors v = factors().build();
            assertThatNullPointerException()
                .isThrownBy(() -> new CreditInsurerRecoveryFactors(null, v.maturity(), v.waitingPeriod(), v.additional()))
                .withMessage("correlation");
            assertThatNullPointerException()
                .isThrownBy(() -> new CreditInsurerRecoveryFactors(v.correlation(), null, v.waitingPeriod(), v.additional()))
                .withMessage("maturity");
            assertThatNullPointerException()
                .isThrownBy(() -> new CreditInsurerRecoveryFactors(v.correlation(), v.maturity(), null, v.additional()))
                .withMessage("waitingPeriod");
            assertThatNullPointerException()
                .isThrownBy(() -> new CreditInsurerRecoveryFactors(v.correlation(), v.maturity(), v.waitingPeriod(), null))
                .withMessage("additional");
        }
    }
}
