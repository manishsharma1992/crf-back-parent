package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.RoundedValue;

/**
 * Results of the credit insurer expected recovery.
 *
 * @param facilityAmountCoveredByCreditInsurer Gac
 * @param expectedRecoveryOnCreditInsurer      RecupEAC
 * @param recoveryRateOnCreditInsurerPercent   RecupTAC, 0 to 100
 * @param expectedRecoveryInFacilityCurrency   RecupEAC_F (equals RecupEAC)
 */
public record CreditInsurerExpectedRecovery(RoundedValue facilityAmountCoveredByCreditInsurer,
                                            RoundedValue expectedRecoveryOnCreditInsurer,
                                            RoundedValue recoveryRateOnCreditInsurerPercent,
                                            RoundedValue expectedRecoveryInFacilityCurrency) {}
