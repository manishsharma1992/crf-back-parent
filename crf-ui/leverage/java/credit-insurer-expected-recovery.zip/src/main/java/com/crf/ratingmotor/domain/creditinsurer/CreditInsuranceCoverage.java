package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.UnitAmount;

import java.util.Objects;

/**
 * How much of the facility the credit insurer covers.
 *
 * @param facility                facility amount and unit; may be 0
 * @param financingCoveredPercent share of BNPP's financing covered by the credit insurer, 0 to 100
 */
public record CreditInsuranceCoverage(UnitAmount facility, RoundedValue financingCoveredPercent) {

    private static final RoundedValue HUNDRED = RoundedValue.of(100);

    public CreditInsuranceCoverage {
        Objects.requireNonNull(facility, "facility");
        Objects.requireNonNull(financingCoveredPercent, "financingCoveredPercent");
        if (financingCoveredPercent.isLessThan(RoundedValue.ZERO) || financingCoveredPercent.isGreaterThan(HUNDRED)) {
            throw new IllegalArgumentException(
                "pctOfBnppFinancingCoveredByCreditInsurer must be between 0 and 100: " + financingCoveredPercent);
        }
    }

    /** Gac: facility amount x unit x covered percent / 100. */
    public RoundedValue facilityAmountCoveredByCreditInsurer() {
        return facility.baseAmount().multiply(financingCoveredPercent.divide(HUNDRED));
    }
}
