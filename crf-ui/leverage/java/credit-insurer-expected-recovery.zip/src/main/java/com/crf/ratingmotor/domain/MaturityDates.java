package com.crf.ratingmotor.domain;

import java.time.LocalDate;
import java.util.Objects;

public record MaturityDates(LocalDate currentDate,
                            LocalDate guaranteeImplementationDate, LocalDate guaranteeMaturityDate,
                            LocalDate facilityImplementationDate, LocalDate facilityMaturityDate) {
    public MaturityDates {
        Objects.requireNonNull(currentDate, "currentDate");
        Objects.requireNonNull(guaranteeImplementationDate, "guaranteeImplementationDate");
        Objects.requireNonNull(guaranteeMaturityDate, "guaranteeMaturityDate");
        Objects.requireNonNull(facilityImplementationDate, "facilityImplementationDate");
        Objects.requireNonNull(facilityMaturityDate, "facilityMaturityDate");
    }

    /**
     * Maturity dates for a credit insurance. The maturity mismatch rule is the same as for a guarantee,
     * so the credit insurer's dates take the guarantee's place: every "guarantee" calculation in
     * {@link MaturityAssessment} then reads as "credit insurance".
     */
    public static MaturityDates forCreditInsurance(LocalDate currentDate,
                                                   LocalDate creditInsurerImplementationDate,
                                                   LocalDate creditInsurerMaturityDate,
                                                   LocalDate facilityImplementationDate,
                                                   LocalDate facilityMaturityDate) {
        Objects.requireNonNull(creditInsurerImplementationDate, "creditInsurerImplementationDate");
        Objects.requireNonNull(creditInsurerMaturityDate, "creditInsurerMaturityDate");
        return new MaturityDates(currentDate, creditInsurerImplementationDate, creditInsurerMaturityDate,
                                 facilityImplementationDate, facilityMaturityDate);
    }
}
