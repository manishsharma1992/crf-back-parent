package com.crf.ratingmotor.application;

import com.crf.ratingmotor.common.RoundedValue;

import java.math.BigDecimal;

/** Shared translation of request values into domain values, with field-specific messages for a 400. */
public final class RequiredValues {

    private RequiredValues() {}

    public static RoundedValue required(BigDecimal value, String field) {
        if (value == null) {
            throw new IllegalArgumentException(field + " must not be null");
        }
        return RoundedValue.of(value);
    }

    public static boolean requiredFlag(Boolean value, String field) {
        if (value == null) {
            throw new IllegalArgumentException(field + " must not be null");
        }
        return value;
    }
}
