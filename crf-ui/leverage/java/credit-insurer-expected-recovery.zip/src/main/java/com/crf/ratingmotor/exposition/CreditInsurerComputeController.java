package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.creditinsurer.CreditInsurerComputeQuery;
import com.crf.ratingmotor.application.creditinsurer.CreditInsurerRecoveryComputeManagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Tag(name = "BIRD SUGRR", description = "Expected recovery on guarantees and credit insurance")
public class CreditInsurerComputeController {

    private final CreditInsurerRecoveryComputeManagementService computeService;

    @Operation(summary = "Compute the expected recovery amount on a credit insurance",
               description = "Computes Gac, RecupEAC, RecupTAC and RecupEAC_F and returns the drivers used.")
    @ApiResponse(responseCode = "200", description = "Expected recovery computed")
    @ApiResponse(responseCode = "400", description = "Invalid request",
                 content = @Content(schema = @Schema(implementation = ProblemDetail.class)))
    @ApiResponse(responseCode = "500", description = "Unexpected server error",
                 content = @Content(schema = @Schema(implementation = ProblemDetail.class)))
    @PostMapping(path = "calculate/creditInsurerExpectedRecoveryAmount",
                 consumes = MediaType.APPLICATION_JSON_VALUE,
                 produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CreditInsurerExpectedRecoveryResponse> calculateCreditInsurerExpectedRecoveryAmount(
            @Valid @RequestBody CreditInsurerComputeQuery query) {
        return ResponseEntity.ok(CreditInsurerExpectedRecoveryResponse.from(computeService.compute(query)));
    }
}
