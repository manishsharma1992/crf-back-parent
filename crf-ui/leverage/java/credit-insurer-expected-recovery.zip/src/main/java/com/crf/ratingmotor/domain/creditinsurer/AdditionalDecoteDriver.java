package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.GenericDriver;

import java.util.Objects;

/**
 * Additional decote (Dfe): 10% when one of these is true, otherwise 0%.
 *
 * <ol>
 *   <li>Insurance policy from an ECA, and the OECD flag or the positive recovery flag is set.</li>
 *   <li>First demand guarantee.</li>
 *   <li>Insurance policy from a private insurer.</li>
 * </ol>
 */
public final class AdditionalDecoteDriver extends GenericDriver {

    public static final String NAME = "ADDITIONAL_DECOTE";

    private static final RoundedValue TEN_PERCENT = RoundedValue.of("0.10");

    private final CreditInsurerType creditInsurerType;
    private final boolean oecdFlag;
    private final boolean positiveRecoveryFlag;

    public AdditionalDecoteDriver(CreditInsurerType creditInsurerType, boolean oecdFlag, boolean positiveRecoveryFlag) {
        super(NAME);
        this.creditInsurerType = Objects.requireNonNull(creditInsurerType, "creditInsurerType");
        this.oecdFlag = oecdFlag;
        this.positiveRecoveryFlag = positiveRecoveryFlag;
        this.estimateValue = applies(creditInsurerType, oecdFlag, positiveRecoveryFlag) ? TEN_PERCENT : RoundedValue.ZERO;
    }

    private static boolean applies(CreditInsurerType type, boolean oecd, boolean positiveRecovery) {
        return switch (type) {
            case INSURANCE_POLICY_FROM_ECA -> oecd || positiveRecovery;
            case FIRST_DEMAND_GUARANTEE, INSURANCE_POLICY_FROM_PRIVATE_INSURER -> true;
            default -> false;
        };
    }

    public CreditInsurerType creditInsurerType() { return creditInsurerType; }
    public boolean oecdFlag()                    { return oecdFlag; }
    public boolean positiveRecoveryFlag()        { return positiveRecoveryFlag; }
}
