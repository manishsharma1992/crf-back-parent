package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.Driver;

import java.util.Objects;

/**
 * Domain service that computes the expected recovery on a credit insurance.
 *
 * <ol>
 *   <li><b>Gac</b>, amount of the facility covered by the credit insurer:
 *       {@code facilityAmount x facilityUnit x pctOfBnppFinancingCoveredByCreditInsurer / 100}.</li>
 *   <li><b>RecupEAC</b>, expected recovery on the credit insurer:
 *       {@code Gac x (1 - Dmm) x (1 - Ddci) x (1 - Dfe) x correlation coefficient}.</li>
 *   <li><b>RecupTAC</b>, recovery rate on the credit insurer: {@code RecupEAC / Gac x 100}.</li>
 *   <li><b>RecupEAC_F</b>, expected recovery in the facility currency: equal to RecupEAC.</li>
 * </ol>
 *
 * <p>If the credit insurance starts after the facility and has not started yet, RecupEAC and RecupTAC are 0.
 * If Gac is 0 (a facility amount of 0, or 0% covered), RecupTAC is 0, because the rate is undefined.</p>
 *
 * <p>All drivers are fractions, so the specification's {@code (1 - x / 100)} is {@code (1 - x)} here.
 * Framework-free and stateless; registered as a bean in configuration.</p>
 */
public final class CreditInsurerExpectedRecoveryCalculatorDomainService {

    private static final RoundedValue HUNDRED = RoundedValue.of(100);

    public CreditInsurerExpectedRecovery calculate(CreditInsuranceCoverage coverage, CreditInsurerRecoveryFactors factors) {
        Objects.requireNonNull(coverage, "coverage");
        Objects.requireNonNull(factors, "factors");

        RoundedValue covered = coverage.facilityAmountCoveredByCreditInsurer();
        RoundedValue expectedRecovery = expectedRecovery(covered, factors);
        RoundedValue recoveryRate = recoveryRatePercent(expectedRecovery, covered, factors);

        return new CreditInsurerExpectedRecovery(covered, expectedRecovery, recoveryRate, expectedRecovery);
    }

    private static RoundedValue expectedRecovery(RoundedValue covered, CreditInsurerRecoveryFactors factors) {
        if (factors.creditInsuranceNotYetStarted()) {
            return RoundedValue.ZERO;
        }
        return covered
            .multiply(complement(factors.maturity()))
            .multiply(complement(factors.waitingPeriod()))
            .multiply(complement(factors.additional()))
            .multiply(factors.correlation().getEstimateValue());
    }

    private static RoundedValue recoveryRatePercent(RoundedValue expectedRecovery, RoundedValue covered,
                                                    CreditInsurerRecoveryFactors factors) {
        if (factors.creditInsuranceNotYetStarted() || !covered.isGreaterThan(RoundedValue.ZERO)) {
            return RoundedValue.ZERO;
        }
        return expectedRecovery.divide(covered).multiply(HUNDRED);
    }

    private static RoundedValue complement(Driver discount) {
        return RoundedValue.ONE.subtract(discount.getEstimateValue());
    }
}
