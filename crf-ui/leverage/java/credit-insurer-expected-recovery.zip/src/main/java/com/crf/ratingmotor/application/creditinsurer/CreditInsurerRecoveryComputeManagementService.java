package com.crf.ratingmotor.application.creditinsurer;

import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.CounterpartyRating;
import com.crf.ratingmotor.domain.DayCountConvention;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.MaturityAssessment;
import com.crf.ratingmotor.domain.MaturityDates;
import com.crf.ratingmotor.domain.UnitAmount;
import com.crf.ratingmotor.domain.creditinsurer.AdditionalDecoteDriver;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsuranceCoverage;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationCoefficientDriver;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrixRepository;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerRecoveryFactors;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerType;
import com.crf.ratingmotor.domain.creditinsurer.WaitingPeriod;
import com.crf.ratingmotor.domain.creditinsurer.WaitingPeriodDecoteDriver;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static com.crf.ratingmotor.application.RequiredValues.required;
import static com.crf.ratingmotor.application.RequiredValues.requiredFlag;

/**
 * Application service for the credit insurer expected recovery: translates the request into domain types,
 * builds the four drivers and delegates to the domain service. No business rules of its own.
 */
@Service
@RequiredArgsConstructor
public class CreditInsurerRecoveryComputeManagementService {

    private final CreditInsurerCorrelationMatrixRepository matrixRepository;   // cached decorator via @Primary
    private final DayCountConvention dayCountConvention;                       // ACT_365_FIXED, shared with guarantees
    private final CreditInsurerExpectedRecoveryCalculatorDomainService calculator;

    public CreditInsurerRecoveryComputeResult compute(CreditInsurerComputeQuery query) {
        Objects.requireNonNull(query, "query");

        CreditInsurerType type = CreditInsurerType.from(query.creditInsurerType());
        CreditInsurerRecoveryFactors factors = new CreditInsurerRecoveryFactors(
            correlationDriver(query),
            maturityDriver(query),
            new WaitingPeriodDecoteDriver(
                requiredFlag(query.waitingPeriodInterestCovered(), "waitingPeriodInterestCovered"),
                type,
                WaitingPeriod.from(query.waitingPeriod())),
            new AdditionalDecoteDriver(
                type,
                requiredFlag(query.oecdFlag(), "oecdFlag"),
                requiredFlag(query.positiveRecoveryFlag(), "positiveRecoveryFlag")));

        CreditInsuranceCoverage coverage = new CreditInsuranceCoverage(
            new UnitAmount(required(query.facilityAmount(), "facilityAmount"), Unit.from(query.facilityUnit())),
            required(query.pctOfBnppFinancingCoveredByCreditInsurer(), "pctOfBnppFinancingCoveredByCreditInsurer"));

        return new CreditInsurerRecoveryComputeResult(calculator.calculate(coverage, factors), factors.reportedDrivers());
    }

    private CreditInsurerCorrelationCoefficientDriver correlationDriver(CreditInsurerComputeQuery query) {
        return new CreditInsurerCorrelationCoefficientDriver(
            matrixRepository.load(),
            CounterpartyRating.parse(query.creditInsurerCounterpartyRating()),
            CounterpartyRating.parse(query.guarantorCounterpartyRating()));
    }

    private DiscountMaturityMismatchDriver maturityDriver(CreditInsurerComputeQuery query) {
        MaturityDates dates = MaturityDates.forCreditInsurance(
            query.currentDate(),
            query.creditInsurerImplementationDate(), query.creditInsurerMaturityDate(),
            query.facilityImplementationDate(), query.facilityMaturityDate());
        return new DiscountMaturityMismatchDriver(MaturityAssessment.of(dates, dayCountConvention));
    }
}
