package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.creditinsurer.CreditInsurerRecoveryComputeResult;
import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerExpectedRecovery;
import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Schema(description = "Expected recovery on the credit insurance and the drivers used to compute it")
public record CreditInsurerExpectedRecoveryResponse(
    @Schema(description = "Gac: amount of the facility covered by the credit insurer")
    BigDecimal facilityAmountCoveredByCreditInsurer,
    @Schema(description = "RecupEAC: expected recovery on the credit insurer")
    BigDecimal expectedRecoveryOnCreditInsurer,
    @Schema(description = "RecupTAC: recovery rate on the credit insurer, percent 0..100")
    BigDecimal recoveryRateOnCreditInsurerPercent,
    @Schema(description = "RecupEAC_F: expected recovery in the facility currency")
    BigDecimal expectedRecoveryInFacilityCurrency,
    @Schema(description = "Drivers used, values as fractions")
    List<ExpectedRecoveryResponse.DriverValue> drivers) {

    private static final int AMOUNT_SCALE = 2;
    private static final int RATE_SCALE = 6;

    public static CreditInsurerExpectedRecoveryResponse from(CreditInsurerRecoveryComputeResult result) {
        CreditInsurerExpectedRecovery r = result.recovery();
        return new CreditInsurerExpectedRecoveryResponse(
            scaled(r.facilityAmountCoveredByCreditInsurer(), AMOUNT_SCALE),
            scaled(r.expectedRecoveryOnCreditInsurer(), AMOUNT_SCALE),
            scaled(r.recoveryRateOnCreditInsurerPercent(), RATE_SCALE),
            scaled(r.expectedRecoveryInFacilityCurrency(), AMOUNT_SCALE),
            result.drivers().stream()
                  .map(d -> new ExpectedRecoveryResponse.DriverValue(d.getName(), scaled(d.getEstimateValue(), RATE_SCALE)))
                  .toList());
    }

    private static BigDecimal scaled(RoundedValue value, int scale) {
        return value.getValue().setScale(scale, RoundingMode.HALF_UP);
    }
}
