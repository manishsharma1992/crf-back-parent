package com.crf.ratingmotor.application.creditinsurer;

import com.crf.ratingmotor.domain.Driver;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerExpectedRecovery;

import java.util.List;

public record CreditInsurerRecoveryComputeResult(CreditInsurerExpectedRecovery recovery, List<Driver> drivers) {}
