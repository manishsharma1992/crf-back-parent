package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.Driver;

import java.util.List;
import java.util.Objects;

/** The four drivers that scale the covered amount in the credit insurer expected recovery. */
public record CreditInsurerRecoveryFactors(CreditInsurerCorrelationCoefficientDriver correlation,
                                           DiscountMaturityMismatchDriver maturity,
                                           WaitingPeriodDecoteDriver waitingPeriod,
                                           AdditionalDecoteDriver additional) {
    public CreditInsurerRecoveryFactors {
        Objects.requireNonNull(correlation, "correlation");
        Objects.requireNonNull(maturity, "maturity");
        Objects.requireNonNull(waitingPeriod, "waitingPeriod");
        Objects.requireNonNull(additional, "additional");
    }

    /** The drivers returned with the result, in a fixed order. */
    public List<Driver> reportedDrivers() {
        return List.of(correlation, maturity, waitingPeriod, additional);
    }

    /** Credit insurance that starts after the facility and has not started yet. */
    boolean creditInsuranceNotYetStarted() {
        return maturity.assessment().guaranteeNotYetStarted();
    }
}
