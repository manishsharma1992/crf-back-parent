package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.GenericDriver;

import java.util.Objects;

/**
 * Waiting period decote (Ddci): a discount for the time the bank waits before the credit insurer pays.
 *
 * <ul>
 *   <li>0% if the waiting-period interest is not covered, or the type is a guarantee at first demand (SBLC).</li>
 *   <li>Otherwise by waiting period: under 31 days 0%, 31-90 days 1%, 91-210 days 2%, over 210 days 3%.</li>
 * </ul>
 */
public final class WaitingPeriodDecoteDriver extends GenericDriver {

    public static final String NAME = "WAITING_PERIOD_DECOTE";

    private final boolean waitingPeriodInterestCovered;
    private final CreditInsurerType creditInsurerType;
    private final WaitingPeriod waitingPeriod;

    public WaitingPeriodDecoteDriver(boolean waitingPeriodInterestCovered, CreditInsurerType creditInsurerType,
                                     WaitingPeriod waitingPeriod) {
        super(NAME);
        this.waitingPeriodInterestCovered = waitingPeriodInterestCovered;
        this.creditInsurerType = Objects.requireNonNull(creditInsurerType, "creditInsurerType");
        this.waitingPeriod = Objects.requireNonNull(waitingPeriod, "waitingPeriod");
        this.estimateValue = decoteFor(waitingPeriodInterestCovered, creditInsurerType, waitingPeriod);
    }

    private static RoundedValue decoteFor(boolean interestCovered, CreditInsurerType type, WaitingPeriod period) {
        if (!interestCovered || type == CreditInsurerType.GUARANTEE_AT_FIRST_DEMAND_SBLC) {
            return RoundedValue.ZERO;
        }
        return period.decote();
    }

    public boolean waitingPeriodInterestCovered() { return waitingPeriodInterestCovered; }
    public CreditInsurerType creditInsurerType()  { return creditInsurerType; }
    public WaitingPeriod waitingPeriod()          { return waitingPeriod; }
}
