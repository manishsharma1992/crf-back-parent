package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.CounterpartyRating;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/** Expected values are read straight from the business table (in %), divided by 100. */
class CreditInsurerCorrelationCoefficientDriverTest {

    private final CreditInsurerCorrelationMatrix matrix = CreditInsurerTables.matrix();

    private CreditInsurerCorrelationCoefficientDriver driver(String creditInsurer, String guarantor) {
        return new CreditInsurerCorrelationCoefficientDriver(
            matrix, CounterpartyRating.parse(creditInsurer), CounterpartyRating.parse(guarantor));
    }

    @ParameterizedTest(name = "credit insurer {0}, guarantor {1} -> {2}")
    @CsvSource({
        "1-, 6+, 1",       // example from the specification: 1- and 6+ read cell [1, 6]
        "1,  1,  1",
        "2,  10, 1",
        "3,  3,  0",       // last 0 before the diagonal
        "3,  4,  0.92",    // first value after it
        "3+, 10, 0.993",
        "4,  5,  0.91",
        "5,  8,  0.986",
        "6,  6,  0",
        "6-, 7,  0.91",
        "6,  10, 0.931"
    })
    @DisplayName("credit insurer rating picks the row, guarantor rating the column, signs ignored")
    void looksUpTheTable(String creditInsurer, String guarantor, String expected) {
        assertExactly(driver(creditInsurer, guarantor).getEstimateValue(), expected);
    }

    @Test
    @DisplayName("the axes are not interchangeable: [3, 5] is 95% but [5, 3] is 0%")
    void orientation() {
        assertExactly(driver("3", "5").getEstimateValue(), "0.95");
        assertExactly(driver("5", "3").getEstimateValue(), "0");
    }

    @ParameterizedTest(name = "credit insurer rating {0} with guarantor {1} -> 0")
    @CsvSource({"7, 10", "7-, 1", "8+, 6", "9, 9", "10-, 10"})
    @DisplayName("credit insurer ratings above 6 have no row, so the coefficient is 0 (confirmed by Clara)")
    void creditInsurerRatingAboveSixIsZero(String creditInsurer, String guarantor) {
        assertExactly(driver(creditInsurer, guarantor).getEstimateValue(), "0");
    }

    @Test
    @DisplayName("rating 6 is still read from the table, so the boundary is exclusive")
    void ratingSixStillFromTable() {
        assertExactly(driver("6+", "10").getEstimateValue(), "0.931");
    }

    @Test
    void matrixRejectsNullRatings() {
        CounterpartyRating one = new CounterpartyRating(1);
        CounterpartyRating seven = new CounterpartyRating(7);
        assertThatNullPointerException().isThrownBy(() -> matrix.coefficientFor(null, one)).withMessage("creditInsurerRating");
        assertThatNullPointerException().isThrownBy(() -> matrix.coefficientFor(seven, null)).withMessage("guarantorRating");
    }

    @Test
    void exposesNameAndInputs() {
        CreditInsurerCorrelationCoefficientDriver d = driver("2+", "7-");

        assertThat(d.getName()).isEqualTo("CORRELATION_COEFFICIENT").isEqualTo(CreditInsurerCorrelationCoefficientDriver.NAME);
        assertThat(d.creditInsurerRating()).isEqualTo(new CounterpartyRating(2));
        assertThat(d.guarantorRating()).isEqualTo(new CounterpartyRating(7));
    }

    @Test
    void rejectsNulls() {
        CounterpartyRating one = new CounterpartyRating(1);
        assertThatNullPointerException()
            .isThrownBy(() -> new CreditInsurerCorrelationCoefficientDriver(null, one, one)).withMessage("matrix");
        assertThatNullPointerException()
            .isThrownBy(() -> new CreditInsurerCorrelationCoefficientDriver(matrix, null, one)).withMessage("creditInsurerRating");
        assertThatNullPointerException()
            .isThrownBy(() -> new CreditInsurerCorrelationCoefficientDriver(matrix, one, null)).withMessage("guarantorRating");
    }

    @Test
    @DisplayName("the matrix only accepts a complete 6 x 10 table")
    void matrixRequiresSixByTen() {
        RoundedValue[][] tenRows = new RoundedValue[10][10];
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new CreditInsurerCorrelationMatrix(tenRows))
            .withMessage("Credit insurer correlation: expected 6 rows but got 10");
    }
}
