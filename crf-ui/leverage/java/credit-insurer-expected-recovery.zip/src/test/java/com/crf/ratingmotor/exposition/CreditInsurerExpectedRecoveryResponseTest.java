package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.creditinsurer.CreditInsurerRecoveryComputeResult;
import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.MaturityScenarios;
import com.crf.ratingmotor.domain.UnitAmount;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsuranceCoverage;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerRecoveryFactors;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerType;
import com.crf.ratingmotor.domain.creditinsurer.WaitingPeriod;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static com.crf.ratingmotor.domain.TestValues.rv;
import static com.crf.ratingmotor.domain.creditinsurer.CreditInsurerFactorsBuilder.factors;
import static org.assertj.core.api.Assertions.assertThat;

/** Amounts are rounded to 2 decimals, the rate and the drivers to 6, HALF_UP. */
class CreditInsurerExpectedRecoveryResponseTest {

    private static CreditInsurerRecoveryComputeResult compute(String amount, String percent, CreditInsurerRecoveryFactors f) {
        CreditInsuranceCoverage coverage = new CreditInsuranceCoverage(new UnitAmount(rv(amount), Unit.UNIT), rv(percent));
        return new CreditInsurerRecoveryComputeResult(
            new CreditInsurerExpectedRecoveryCalculatorDomainService().calculate(coverage, f), f.reportedDrivers());
    }

    @Test
    void roundsAndNamesEveryOutput() {
        // Gac = 1000 x 100% = 1000; RecupEAC = 1000 x (1.75/3.75) = 466.666...; RecupTAC = 46.666...%
        CreditInsurerExpectedRecoveryResponse response = CreditInsurerExpectedRecoveryResponse.from(compute("1000", "100",
            factors().maturity(MaturityScenarios.partialMismatch()).build()));

        assertThat(response.facilityAmountCoveredByCreditInsurer()).isEqualTo(new BigDecimal("1000.00"));
        assertThat(response.expectedRecoveryOnCreditInsurer()).isEqualTo(new BigDecimal("466.67"));
        assertThat(response.recoveryRateOnCreditInsurerPercent()).isEqualTo(new BigDecimal("46.666667"));
        assertThat(response.expectedRecoveryInFacilityCurrency()).isEqualTo(new BigDecimal("466.67"));
    }

    @Test
    void driversInOrder() {
        CreditInsurerExpectedRecoveryResponse response = CreditInsurerExpectedRecoveryResponse.from(compute("1000", "80",
            factors().ratings(3, 5).type(CreditInsurerType.INSURANCE_POLICY_FROM_ECA).flags(false, true)
                .waitingPeriod(true, WaitingPeriod.FROM_91_TO_210_DAYS).build()));

        assertThat(response.drivers()).containsExactly(
            new ExpectedRecoveryResponse.DriverValue("CORRELATION_COEFFICIENT", new BigDecimal("0.950000")),
            new ExpectedRecoveryResponse.DriverValue("DISCOUNT_MATURITY_MISMATCH", new BigDecimal("0.000000")),
            new ExpectedRecoveryResponse.DriverValue("WAITING_PERIOD_DECOTE", new BigDecimal("0.020000")),
            new ExpectedRecoveryResponse.DriverValue("ADDITIONAL_DECOTE", new BigDecimal("0.100000")));
    }
}
