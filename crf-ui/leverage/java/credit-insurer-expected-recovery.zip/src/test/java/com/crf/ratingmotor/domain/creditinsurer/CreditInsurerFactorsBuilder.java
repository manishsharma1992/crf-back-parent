package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.domain.CounterpartyRating;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.MaturityAssessment;
import com.crf.ratingmotor.domain.MaturityScenarios;

/**
 * Builds CreditInsurerRecoveryFactors with neutral defaults, so each test changes only what it is about.
 *
 * <p>Defaults: credit insurer rating 1 and guarantor rating 1 (coefficient 100%), no maturity mismatch,
 * waiting-period interest not covered (Ddci 0%), type "Guarantee" with both flags false (Dfe 0%).
 * With these defaults RecupEAC equals Gac.</p>
 */
public final class CreditInsurerFactorsBuilder {

    private int creditInsurerRating = 1;
    private int guarantorRating = 1;
    private MaturityAssessment maturity = MaturityScenarios.noMismatch();
    private boolean interestCovered = false;
    private CreditInsurerType type = CreditInsurerType.GUARANTEE;
    private WaitingPeriod waitingPeriod = WaitingPeriod.LESS_THAN_31_DAYS;
    private boolean oecd = false;
    private boolean positiveRecovery = false;

    public static CreditInsurerFactorsBuilder factors() {
        return new CreditInsurerFactorsBuilder();
    }

    public CreditInsurerFactorsBuilder ratings(int creditInsurer, int guarantor) {
        this.creditInsurerRating = creditInsurer;
        this.guarantorRating = guarantor;
        return this;
    }

    public CreditInsurerFactorsBuilder maturity(MaturityAssessment assessment) {
        this.maturity = assessment;
        return this;
    }

    public CreditInsurerFactorsBuilder waitingPeriod(boolean interestCovered, WaitingPeriod period) {
        this.interestCovered = interestCovered;
        this.waitingPeriod = period;
        return this;
    }

    public CreditInsurerFactorsBuilder type(CreditInsurerType value) {
        this.type = value;
        return this;
    }

    public CreditInsurerFactorsBuilder flags(boolean oecdFlag, boolean positiveRecoveryFlag) {
        this.oecd = oecdFlag;
        this.positiveRecovery = positiveRecoveryFlag;
        return this;
    }

    public CreditInsurerRecoveryFactors build() {
        return new CreditInsurerRecoveryFactors(
            new CreditInsurerCorrelationCoefficientDriver(CreditInsurerTables.matrix(),
                new CounterpartyRating(creditInsurerRating), new CounterpartyRating(guarantorRating)),
            new DiscountMaturityMismatchDriver(maturity),
            new WaitingPeriodDecoteDriver(interestCovered, type, waitingPeriod),
            new AdditionalDecoteDriver(type, oecd, positiveRecovery));
    }
}
