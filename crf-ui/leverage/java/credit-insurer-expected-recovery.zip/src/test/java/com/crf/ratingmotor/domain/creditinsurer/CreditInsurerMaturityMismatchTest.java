package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.domain.DayCountConvention;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.MaturityAssessment;
import com.crf.ratingmotor.domain.MaturityDates;
import com.crf.ratingmotor.domain.MaturityMismatchIndicator;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static com.crf.ratingmotor.domain.TestValues.assertApproximately;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/**
 * The maturity mismatch discount for a credit insurance reuses the guarantee rule unchanged, with the credit
 * insurer's dates in place of the guarantee's. Offsets are days from "today" (2026-01-01), ACT/365.
 */
class CreditInsurerMaturityMismatchTest {

    private static final LocalDate TODAY = LocalDate.of(2026, 1, 1);

    private static MaturityDates dates(int ciStart, int ciEnd, int facilityStart, int facilityEnd) {
        return MaturityDates.forCreditInsurance(TODAY,
            TODAY.plusDays(ciStart), TODAY.plusDays(ciEnd), TODAY.plusDays(facilityStart), TODAY.plusDays(facilityEnd));
    }

    private static DiscountMaturityMismatchDriver driver(int ciStart, int ciEnd, int facilityStart, int facilityEnd) {
        return new DiscountMaturityMismatchDriver(
            MaturityAssessment.of(dates(ciStart, ciEnd, facilityStart, facilityEnd), DayCountConvention.ACT_365_FIXED));
    }

    @Test
    @DisplayName("the credit insurer's dates take the guarantee's place")
    void mapsCreditInsurerDates() {
        MaturityDates d = dates(-10, 20, -30, 40);

        assertThat(d.currentDate()).isEqualTo(TODAY);
        assertThat(d.guaranteeImplementationDate()).isEqualTo(TODAY.plusDays(-10));
        assertThat(d.guaranteeMaturityDate()).isEqualTo(TODAY.plusDays(20));
        assertThat(d.facilityImplementationDate()).isEqualTo(TODAY.plusDays(-30));
        assertThat(d.facilityMaturityDate()).isEqualTo(TODAY.plusDays(40));
    }

    @Test
    @DisplayName("credit insurance outlives the facility: 0%")
    void noMismatch() {
        assertExactly(driver(-365, 1460, -365, 730).getEstimateValue(), "0");
    }

    @Test
    @DisplayName("credit insurance for 2 more years on a 4-year facility: 1 - 1.75 / 3.75")
    void partialMismatch() {
        DiscountMaturityMismatchDriver d = driver(-365, 730, -365, 1460);

        assertThat(d.getName()).isEqualTo("DISCOUNT_MATURITY_MISMATCH");
        assertThat(d.assessment().indicator()).isEqualTo(MaturityMismatchIndicator.MISMATCH);
        assertApproximately(d.getEstimateValue(), "0.5333333333333333333333333333");
    }

    @Test
    @DisplayName("less than 3 months of credit insurance left: 100%")
    void fullDiscount() {
        assertExactly(driver(-365, 60, -365, 1460).getEstimateValue(), "1");
    }

    @Test
    @DisplayName("credit insurance that starts after the facility and has not started yet: 0%")
    void notYetStarted() {
        DiscountMaturityMismatchDriver d = driver(100, 400, -365, 1460);

        assertThat(d.assessment().guaranteeNotYetStarted()).isTrue();
        assertExactly(d.getEstimateValue(), "0");
    }

    @Test
    @DisplayName("missing credit insurer dates are reported with credit insurer names")
    void nullDatesNamedForCreditInsurer() {
        LocalDate d = TODAY;
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityDates.forCreditInsurance(d, null, d, d, d))
            .withMessage("creditInsurerImplementationDate");
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityDates.forCreditInsurance(d, d, null, d, d))
            .withMessage("creditInsurerMaturityDate");
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityDates.forCreditInsurance(null, d, d, d, d))
            .withMessage("currentDate");
    }
}
