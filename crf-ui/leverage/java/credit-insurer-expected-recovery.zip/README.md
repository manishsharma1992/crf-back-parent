# Credit insurer expected recovery

Packages use the `com.crf.ratingmotor` placeholder: replace with yours. This zip replaces the earlier credit
insurer zips and contains everything for credit insurers so far.

## Files

| File | Layer | Purpose |
|---|---|---|
| `domain/RatingGrid.java` | Domain (shared) | Validated, immutable table of coefficients addressed by two ratings |
| `domain/MaturityDates.java` | Domain (changed) | Adds `forCreditInsurance(...)`; nothing else changes |
| `domain/creditinsurer/CreditInsurerCorrelationMatrix.java` | Domain | 6 x 10 table; credit insurer rated 7..10 gives 0 |
| `domain/creditinsurer/CreditInsurerCorrelationMatrixRepository.java` | Domain port | Where the table comes from |
| `domain/creditinsurer/CreditInsurerCorrelationCoefficientDriver.java` | Domain | Driver 1: `CORRELATION_COEFFICIENT` |
| `domain/creditinsurer/CreditInsurerType.java` | Domain | 8 types: the 5 earlier ones plus the 3 from the story |
| `domain/creditinsurer/WaitingPeriod.java` | Domain | 4 periods, each with its decote (0%, 1%, 2%, 3%) |
| `domain/creditinsurer/WaitingPeriodDecoteDriver.java` | Domain | Calculation 1, Ddci: `WAITING_PERIOD_DECOTE` |
| `domain/creditinsurer/AdditionalDecoteDriver.java` | Domain | Calculation 2, Dfe: `ADDITIONAL_DECOTE` |
| `domain/creditinsurer/CreditInsuranceCoverage.java` | Domain | Calculation 3, Gac |
| `domain/creditinsurer/CreditInsurerRecoveryFactors.java` | Domain | The four drivers, and the ones reported |
| `domain/creditinsurer/CreditInsurerExpectedRecovery.java` | Domain | The four results |
| `domain/creditinsurer/CreditInsurerExpectedRecoveryCalculatorDomainService.java` | Domain service | RecupEAC, RecupTAC, RecupEAC_F |
| `application/RequiredValues.java` | Application (shared) | `required` / `requiredFlag` with field-specific 400 messages |
| `application/creditinsurer/CreditInsurerComputeQuery.java` | Application | Request, with every confirmed type and rule |
| `application/creditinsurer/CreditInsurerRecoveryComputeResult.java` | Application | Result and drivers |
| `application/creditinsurer/CreditInsurerRecoveryComputeManagementService.java` | Application | Use case |
| `exposition/CreditInsurerExpectedRecoveryResponse.java` | Exposition | Response, rounded (amounts 2 decimals, rate and drivers 6) |
| `exposition/CreditInsurerComputeController.java` | Exposition | `POST calculate/creditInsurerExpectedRecoveryAmount` |
| `infrastructure/CreditInsurerCorrelation*`, `CachingCreditInsurer*` | Infrastructure | Table, DAO, adapter, cache |
| `sql/V__credit_insurer_correlation_coefficient.sql` | Database | PostgreSQL table and data |
| `src/test/resources/sql/credit-insurer-correlation-seed.sql` | Test data | H2 and PostgreSQL seed |

## Changes to existing files

1. `CacheNames`: add `CREDIT_INSURER_CORRELATION_MATRIX("creditInsurerCorrelationMatrix")`.
2. `RatingMotorConfig`: register the domain service as a bean.
   ```java
   @Bean
   CreditInsurerExpectedRecoveryCalculatorDomainService creditInsurerExpectedRecoveryCalculatorDomainService() {
       return new CreditInsurerExpectedRecoveryCalculatorDomainService();
   }
   ```
3. The exception handler: add the new controller to the scope.
   ```java
   @RestControllerAdvice(assignableTypes = {GuaranteeRecoveryComputeController.class, CreditInsurerComputeController.class})
   ```
4. Optional: the guarantee management service can use `RequiredValues` instead of its own private
   `required` and `requiredFlag`, which removes the duplicate code Sonar may flag.

## Tests

Domain: `RatingGridTest`, `CreditInsurerEnumsTest`, `CreditInsurerMaturityMismatchTest`,
`CreditInsurerCorrelationCoefficientDriverTest`, `CreditInsurerDecoteDriversTest`,
`CreditInsurerExpectedRecoveryCalculatorDomainServiceTest`.
Application: `CreditInsurerRecoveryComputeManagementServiceTest`. Exposition: `CreditInsurerExpectedRecoveryResponseTest`.
Infrastructure: `CreditInsurerCorrelationMatrixRepositoryTest`.
Fixtures: `CreditInsurerTables` (the table in percent), `CreditInsurerFactorsBuilder`, `CreditInsurerComputeQueryBuilder`.
