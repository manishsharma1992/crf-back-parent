package com.crf.ratingmotor.application.creditinsurer;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Request from crf-back for the credit insurer expected recovery.
 *
 * <p>Format rules only (presence, ranges, patterns). The two enums arrive as their labels and are
 * converted with {@code CreditInsurerType.from} and {@code WaitingPeriod.from} in the application service,
 * which keeps Jackson and Swagger out of the domain.</p>
 */
@Schema(description = "Inputs sent by crf-back to compute the expected recovery on a credit insurance")
public record CreditInsurerComputeQuery(

    @Schema(description = "Date on which crf-back calls the rating motor", example = "2026-11-18")
    @NotNull LocalDate currentDate,

    @Schema(example = "2025-01-01")
    @NotNull LocalDate creditInsurerImplementationDate,

    @Schema(example = "2031-01-01")
    @NotNull LocalDate creditInsurerMaturityDate,

    @Schema(allowableValues = {"Guarantee", "Guarantee at 1rt demand SBLC", "Cross guarantees",
                               "Other personal or corporate guarantee", "Third party commitments"},
            example = "Guarantee")
    @NotBlank String creditInsurerType,

    @Schema(description = "Credit insurer rating 1..10, optionally followed by + or -; above 6 gives a coefficient of 0",
            example = "1-")
    @NotBlank @Pattern(regexp = "\\s*(10|[1-9])[+-]?\\s*", message = "must be 1..10 optionally followed by + or -")
    String creditInsurerCounterpartyRating,

    @Schema(example = "true")
    @NotNull Boolean oecdFlag,

    @Schema(example = "true")
    @NotNull Boolean positiveRecoveryFlag,

    @Schema(example = "false")
    @NotNull Boolean waitingPeriodInterestCovered,

    @Schema(allowableValues = {"Less than 31 D", "31-90 D", "91-210 D", "More than 210 D"}, example = "31-90 D")
    @NotBlank String waitingPeriod,

    @Schema(description = "Percent 0..100", example = "80")
    @NotNull @Min(0) @Max(100) Short pctOfBnppFinancingCoveredByCreditInsurer,

    @Schema(example = "false")
    @NotNull Boolean prorataShareOfExpectedRecovery,

    @Schema(description = "Percent 0..100", example = "50")
    @NotNull @Min(0) @Max(100) Short sugrr,

    @Schema(description = "Percent 0..100", example = "90")
    @NotNull @DecimalMin("0") @DecimalMax("100") BigDecimal pctOfBnppCoveredByCreditInsurer,

    @Schema(example = "2025-01-01")
    @NotNull LocalDate facilityImplementationDate,

    @Schema(example = "2030-01-01")
    @NotNull LocalDate facilityMaturityDate,

    @Schema(description = "Must be greater than 0", example = "10000000")
    @NotNull @Positive BigDecimal facilityAmount,

    @Schema(description = "Guarantor rating 1..10, optionally followed by + or -", example = "6+")
    @NotBlank @Pattern(regexp = "\\s*(10|[1-9])[+-]?\\s*", message = "must be 1..10 optionally followed by + or -")
    String guarantorCounterpartyRating
) {}
