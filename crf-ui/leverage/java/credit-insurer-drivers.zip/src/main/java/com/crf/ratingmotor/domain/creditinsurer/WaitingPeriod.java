package com.crf.ratingmotor.domain.creditinsurer;

import java.util.Locale;

/** Waiting period before the credit insurer pays, with the label crf-back sends. */
public enum WaitingPeriod {
    LESS_THAN_31_DAYS("Less than 31 D"),
    FROM_31_TO_90_DAYS("31-90 D"),
    FROM_91_TO_210_DAYS("91-210 D"),
    MORE_THAN_210_DAYS("More than 210 D");

    private final String label;

    WaitingPeriod(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    /** Accepts the label ("31-90 D") or the constant name ("FROM_31_TO_90_DAYS"), ignoring case and spaces around it. */
    public static WaitingPeriod from(String text) {
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException("waitingPeriod must not be null or blank");
        }
        String value = text.trim();
        for (WaitingPeriod period : values()) {
            if (period.label.equalsIgnoreCase(value) || period.name().equals(value.toUpperCase(Locale.ROOT))) {
                return period;
            }
        }
        throw new IllegalArgumentException("Unknown waitingPeriod: " + text);
    }
}
