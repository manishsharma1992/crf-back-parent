package com.crf.ratingmotor.domain.creditinsurer;

import java.util.Locale;

/** Type of credit insurance, with the label crf-back sends. */
public enum CreditInsurerType {
    GUARANTEE("Guarantee"),
    GUARANTEE_AT_FIRST_DEMAND_SBLC("Guarantee at 1rt demand SBLC"),
    CROSS_GUARANTEES("Cross guarantees"),
    OTHER_PERSONAL_OR_CORPORATE_GUARANTEE("Other personal or corporate guarantee"),
    THIRD_PARTY_COMMITMENTS("Third party commitments");

    private final String label;

    CreditInsurerType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    /** Accepts the label ("Cross guarantees") or the constant name ("CROSS_GUARANTEES"), ignoring case and spaces around it. */
    public static CreditInsurerType from(String text) {
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException("creditInsurerType must not be null or blank");
        }
        String value = text.trim();
        for (CreditInsurerType type : values()) {
            if (type.label.equalsIgnoreCase(value) || type.name().equals(value.toUpperCase(Locale.ROOT))) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown creditInsurerType: " + text);
    }
}
