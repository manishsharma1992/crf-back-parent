package com.crf.ratingmotor.domain.creditinsurer;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

class CreditInsurerEnumsTest {

    @ParameterizedTest(name = "\"{0}\" -> {1}")
    @CsvSource(delimiter = '|', value = {
        "Guarantee                             | GUARANTEE",
        "Guarantee at 1rt demand SBLC          | GUARANTEE_AT_FIRST_DEMAND_SBLC",
        "Cross guarantees                      | CROSS_GUARANTEES",
        "Other personal or corporate guarantee | OTHER_PERSONAL_OR_CORPORATE_GUARANTEE",
        "Third party commitments               | THIRD_PARTY_COMMITMENTS",
        "'  cross GUARANTEES '                 | CROSS_GUARANTEES",
        "third_party_commitments               | THIRD_PARTY_COMMITMENTS"
    })
    void creditInsurerTypeFromLabelOrName(String text, CreditInsurerType expected) {
        assertThat(CreditInsurerType.from(text)).isEqualTo(expected);
    }

    @ParameterizedTest
    @EnumSource(CreditInsurerType.class)
    void creditInsurerTypeLabelRoundTrip(CreditInsurerType type) {
        assertThat(CreditInsurerType.from(type.getLabel())).isEqualTo(type);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {"  "})
    void creditInsurerTypeBlank(String text) {
        assertThatIllegalArgumentException().isThrownBy(() -> CreditInsurerType.from(text))
            .withMessage("creditInsurerType must not be null or blank");
    }

    @Test
    void creditInsurerTypeUnknown() {
        assertThatIllegalArgumentException().isThrownBy(() -> CreditInsurerType.from("Letter of comfort"))
            .withMessage("Unknown creditInsurerType: Letter of comfort");
    }

    @ParameterizedTest(name = "\"{0}\" -> {1}")
    @CsvSource(delimiter = '|', value = {
        "Less than 31 D     | LESS_THAN_31_DAYS",
        "31-90 D            | FROM_31_TO_90_DAYS",
        "91-210 D           | FROM_91_TO_210_DAYS",
        "More than 210 D    | MORE_THAN_210_DAYS",
        "'  more THAN 210 d ' | MORE_THAN_210_DAYS",
        "from_31_to_90_days | FROM_31_TO_90_DAYS"
    })
    void waitingPeriodFromLabelOrName(String text, WaitingPeriod expected) {
        assertThat(WaitingPeriod.from(text)).isEqualTo(expected);
    }

    @ParameterizedTest
    @EnumSource(WaitingPeriod.class)
    void waitingPeriodLabelRoundTrip(WaitingPeriod period) {
        assertThat(WaitingPeriod.from(period.getLabel())).isEqualTo(period);
    }

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {"  "})
    void waitingPeriodBlank(String text) {
        assertThatIllegalArgumentException().isThrownBy(() -> WaitingPeriod.from(text))
            .withMessage("waitingPeriod must not be null or blank");
    }

    @Test
    void waitingPeriodUnknown() {
        assertThatIllegalArgumentException().isThrownBy(() -> WaitingPeriod.from("90 D"))
            .withMessage("Unknown waitingPeriod: 90 D");
    }
}
