# Credit insurer: request and first driver (correlation coefficient)

Packages use the `com.crf.ratingmotor` placeholder: replace with yours.

## New files

| File | Layer | Purpose |
|---|---|---|
| `domain/RatingGrid.java` | Domain (shared) | Validated, immutable table of coefficients addressed by two ratings, any size up to 10 x 10 |
| `domain/creditinsurer/CreditInsurerCorrelationMatrix.java` | Domain | The 6 x 10 table: credit insurer rating (row) by guarantor rating (column) |
| `domain/creditinsurer/CreditInsurerCorrelationMatrixRepository.java` | Domain port | Where the table comes from |
| `domain/creditinsurer/CreditInsurerCorrelationCoefficientDriver.java` | Domain | The driver: looks up the coefficient, keeps both ratings for the audit trail |
| `infrastructure/CreditInsurerCorrelationCoefficientEntity.java` | JPA | One cell of the table |
| `infrastructure/CreditInsurerCorrelationCoefficientDao.java` | JPA | Spring Data DAO (`findAll`) |
| `infrastructure/CreditInsurerCorrelationMatrixRepositoryImpl.java` | Infrastructure | Rows to table; incomplete or out-of-range data is a server error |
| `infrastructure/CachingCreditInsurerCorrelationMatrixRepository.java` | Infrastructure | `@Primary` cache decorator, one fixed key |
| `domain/creditinsurer/CreditInsurerType.java`, `WaitingPeriod.java` | Domain | Enums with crf-back's labels; `from(text)` accepts the label or the constant name |
| `domain/MaturityDates.java` | Domain (changed) | Adds `forCreditInsurance(...)`; nothing else changes |
| `application/creditinsurer/CreditInsurerComputeQuery.java` | Application | Request record with every type and rule confirmed by Clara |
| `sql/V__credit_insurer_correlation_coefficient.sql` | Database | PostgreSQL table and data, re-runnable (`ON CONFLICT`) |
| `src/test/resources/sql/credit-insurer-correlation-seed.sql` | Test data | H2 and PostgreSQL seed for the integration test |

## One change to an existing file

Add to `CacheNames`:

```java
CREDIT_INSURER_CORRELATION_MATRIX("creditInsurerCorrelationMatrix");
```

`CacheConfig` registers it automatically, because it builds cache names from `CacheNames.values()`.

## Tests

`RatingGridTest`, `CreditInsurerEnumsTest`, `CreditInsurerMaturityMismatchTest`, `CreditInsurerCorrelationCoefficientDriverTest` (every value checked against the business
table, including the specification example 1- / 6+ = 100%), `CreditInsurerCorrelationMatrixRepositoryTest`
(adapter and cache). `CreditInsurerTables` is the shared fixture holding the table in percent.
