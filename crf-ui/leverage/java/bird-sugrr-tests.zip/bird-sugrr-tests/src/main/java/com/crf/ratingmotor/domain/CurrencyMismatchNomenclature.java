package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;

/**
 * The "currency_mismatch nomenclature" lookup result supplied by crf-back.
 *
 * <p>The discount is only needed when the currencies differ and both are in the nomenclature, so its
 * presence is checked when it is used, not here. A same-currency request with both flags true and no
 * currencyMismatch value is valid: its discount is 0%.</p>
 */
public record CurrencyMismatchNomenclature(boolean guaranteeCurrencyExists,
                                           boolean facilityCurrencyExists,
                                           RoundedValue discount) {
    public CurrencyMismatchNomenclature {
        if (discount != null && (discount.isLessThan(RoundedValue.ZERO) || discount.isGreaterThan(RoundedValue.ONE))) {
            throw new IllegalArgumentException("currencyMismatch must be a fraction between 0 and 1: " + discount);
        }
    }

    boolean coversBothCurrencies() {
        return guaranteeCurrencyExists && facilityCurrencyExists;
    }

    RoundedValue requiredDiscount() {
        if (discount == null) {
            throw new IllegalArgumentException(
                "currencyMismatch is required when the currencies differ and both are in the nomenclature");
        }
        return discount;
    }
}
