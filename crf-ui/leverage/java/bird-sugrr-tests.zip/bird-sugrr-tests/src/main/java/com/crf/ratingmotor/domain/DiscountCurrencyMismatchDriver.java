package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;

import java.util.Objects;

public final class DiscountCurrencyMismatchDriver extends GenericDriver {

    public static final String NAME = "DISCOUNT_CURRENCY_MISMATCH";

    private static final RoundedValue DEFAULT_DISCOUNT = RoundedValue.of("0.4087");

    private final CurrencyCode guaranteeCurrency;
    private final CurrencyCode facilityCurrency;
    private final CurrencyMismatchIndicator indicator;
    private final CurrencyMismatchNomenclature nomenclature;

    public DiscountCurrencyMismatchDriver(CurrencyCode guaranteeCurrency, CurrencyCode facilityCurrency,
                                          CurrencyMismatchNomenclature nomenclature) {
        super(NAME);
        this.guaranteeCurrency = Objects.requireNonNull(guaranteeCurrency, "guaranteeCurrency");
        this.facilityCurrency = Objects.requireNonNull(facilityCurrency, "facilityCurrency");
        this.nomenclature = Objects.requireNonNull(nomenclature, "nomenclature");
        this.indicator = CurrencyMismatchIndicator.between(guaranteeCurrency, facilityCurrency);
        this.estimateValue = discountFor(indicator, nomenclature);
    }

    private static RoundedValue discountFor(CurrencyMismatchIndicator indicator, CurrencyMismatchNomenclature n) {
        if (indicator == CurrencyMismatchIndicator.NO_MISMATCH) {
            return RoundedValue.ZERO;
        }
        return n.coversBothCurrencies() ? n.requiredDiscount() : DEFAULT_DISCOUNT;
    }

    public CurrencyMismatchIndicator indicator() { return indicator; }
    public CurrencyCode guaranteeCurrency()      { return guaranteeCurrency; }
    public CurrencyCode facilityCurrency()       { return facilityCurrency; }
    public CurrencyMismatchNomenclature nomenclature() { return nomenclature; }
}
