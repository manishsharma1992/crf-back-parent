-- Test data for GuaranteeRecoveryComputeManagementServiceIT (PostgreSQL).
-- Runs inside the test transaction and is rolled back after each test.
-- Every cell is unique, so a swapped axis, a wrong security type or a wrong correlation shows up:
--   value = security type base + correlation base + (guarantor * 100 + obligor) / 10000
--   GUARANTEE / LOW  / guarantor 3 / obligor 5 = 0.0305
--   GUARANTEE / HIGH / guarantor 3 / obligor 5 = 0.5305
-- Adjust the table name if your entity maps to another one.

DELETE FROM rating_matrix;

INSERT INTO rating_matrix (security_type, correlation, guarantor_rating, obligor_rating, value)
SELECT st.security_type,
       c.correlation,
       g,
       o,
       st.base + c.base + (g * 100 + o) / 10000.0
FROM (VALUES ('GUARANTEE', 0), ('CREDIT_INSURER', 1), ('COLLATERAL', 2)) AS st (security_type, base)
CROSS JOIN (VALUES ('LOW', 0.0), ('HIGH', 0.5)) AS c (correlation, base)
CROSS JOIN generate_series(1, 10) AS g
CROSS JOIN generate_series(1, 10) AS o;
