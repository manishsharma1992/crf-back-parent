package com.crf.ratingmotor.infrastructure;

import com.crf.ratingmotor.domain.Correlation;
import com.crf.ratingmotor.domain.CorrelationCoefficientMatrix;
import com.crf.ratingmotor.domain.CounterpartyRating;
import com.crf.ratingmotor.domain.SecurityType;
import com.crf.ratingmotor.domain.TestMatrices;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalStateException;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class CorrelationCoefficientMatrixRepositoryImplTest {

    private CorrelationCoefficientMatrixDao dao;
    private CorrelationCoefficientMatrixRepositoryImpl repository;

    @BeforeEach
    void setUp() {
        dao = mock(CorrelationCoefficientMatrixDao.class);
        repository = new CorrelationCoefficientMatrixRepositoryImpl(dao);
    }

    /** Adapt this one method if your entity is built with a constructor or a builder instead of setters. */
    static CorrelationCoefficientEntity entity(SecurityType type, Correlation correlation,
                                               int guarantor, int obligor, BigDecimal value) {
        CorrelationCoefficientEntity e = new CorrelationCoefficientEntity();
        e.setSecurityType(type);
        e.setCorrelation(correlation);
        e.setGuarantorRating((short) guarantor);
        e.setObligorRating((short) obligor);
        e.setValue(value);
        return e;
    }

    /** All 300 rows of one correlation, with the asymmetric test values (GUARANTEE 3/5 = 0.0305). */
    static List<CorrelationCoefficientEntity> fullTable(Correlation correlation) {
        List<CorrelationCoefficientEntity> rows = new ArrayList<>();
        for (SecurityType type : SecurityType.values()) {
            for (int g = 1; g <= 10; g++) {
                for (int o = 1; o <= 10; o++) {
                    rows.add(entity(type, correlation, g, o, TestMatrices.asymmetricValue(type, g, o)));
                }
            }
        }
        return rows;
    }

    @Test
    @DisplayName("maps 300 flat rows into the matrix, keeping guarantor as row and obligor as column")
    void mapsRowsIntoMatrix() {
        when(dao.findByCorrelation(Correlation.HIGH)).thenReturn(fullTable(Correlation.HIGH));

        CorrelationCoefficientMatrix matrix = repository.findBy(Correlation.HIGH);

        assertThat(matrix.correlation()).isEqualTo(Correlation.HIGH);
        assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, new CounterpartyRating(3), new CounterpartyRating(5)), "0.0305");
        assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, new CounterpartyRating(5), new CounterpartyRating(3)), "0.0503");
        assertExactly(matrix.coefficientFor(SecurityType.COLLATERAL, new CounterpartyRating(10), new CounterpartyRating(1)), "2.1001");
        verify(dao).findByCorrelation(Correlation.HIGH);
    }

    @Test
    @DisplayName("row order in the database does not matter")
    void rowOrderIrrelevant() {
        List<CorrelationCoefficientEntity> rows = fullTable(Correlation.LOW);
        java.util.Collections.reverse(rows);
        when(dao.findByCorrelation(Correlation.LOW)).thenReturn(rows);

        assertExactly(repository.findBy(Correlation.LOW)
            .coefficientFor(SecurityType.CREDIT_INSURER, new CounterpartyRating(3), new CounterpartyRating(5)), "1.0305");
    }

    @Test
    @DisplayName("no rows at all is a server error")
    void noRows() {
        when(dao.findByCorrelation(Correlation.LOW)).thenReturn(List.of());

        assertThatIllegalStateException()
            .isThrownBy(() -> repository.findBy(Correlation.LOW))
            .withMessage("No coefficients found for correlation LOW");
    }

    @Test
    @DisplayName("one missing row is a server error that names the missing cell")
    void missingRow() {
        List<CorrelationCoefficientEntity> rows = fullTable(Correlation.LOW);
        rows.removeIf(e -> e.getSecurityType() == SecurityType.GUARANTEE
                           && e.getGuarantorRating() == 4 && e.getObligorRating() == 7);
        when(dao.findByCorrelation(Correlation.LOW)).thenReturn(rows);

        assertThatIllegalStateException()
            .isThrownBy(() -> repository.findBy(Correlation.LOW))
            .withMessage("Correlation coefficient data for LOW is incomplete")
            .withCauseInstanceOf(IllegalArgumentException.class)
            .satisfies(e -> assertThat(e.getCause())
                .hasMessage("GUARANTEE: missing coefficient at guarantor=4, obligor=7"));
    }

    @Test
    @DisplayName("a missing security type is a server error")
    void missingSecurityType() {
        List<CorrelationCoefficientEntity> rows = fullTable(Correlation.LOW);
        rows.removeIf(e -> e.getSecurityType() == SecurityType.COLLATERAL);
        when(dao.findByCorrelation(Correlation.LOW)).thenReturn(rows);

        assertThatIllegalStateException()
            .isThrownBy(() -> repository.findBy(Correlation.LOW))
            .withMessage("Correlation coefficient data for LOW is incomplete")
            .satisfies(e -> assertThat(e.getCause()).hasMessage("Missing matrix for security type COLLATERAL"));
    }

    @ParameterizedTest(name = "guarantor rating {0} in the database is rejected")
    @ValueSource(ints = {0, 11, -1})
    void guarantorRatingOutOfRange(int rating) {
        List<CorrelationCoefficientEntity> rows = fullTable(Correlation.LOW);
        rows.add(entity(SecurityType.GUARANTEE, Correlation.LOW, rating, 1, BigDecimal.ONE));
        when(dao.findByCorrelation(Correlation.LOW)).thenReturn(rows);

        assertThatIllegalStateException()
            .isThrownBy(() -> repository.findBy(Correlation.LOW))
            .withMessage("Rating out of range in database: " + rating);
    }

    @ParameterizedTest(name = "obligor rating {0} in the database is rejected")
    @ValueSource(ints = {0, 11})
    void obligorRatingOutOfRange(int rating) {
        List<CorrelationCoefficientEntity> rows = fullTable(Correlation.LOW);
        rows.add(entity(SecurityType.GUARANTEE, Correlation.LOW, 1, rating, BigDecimal.ONE));
        when(dao.findByCorrelation(Correlation.LOW)).thenReturn(rows);

        assertThatIllegalStateException()
            .isThrownBy(() -> repository.findBy(Correlation.LOW))
            .withMessage("Rating out of range in database: " + rating);
    }
}
