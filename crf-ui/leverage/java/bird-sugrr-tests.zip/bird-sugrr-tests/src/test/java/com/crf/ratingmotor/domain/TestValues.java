package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;

/** Assertion helpers for RoundedValue, so tests compare numbers and not object identity or scale. */
public final class TestValues {

    /** Tolerance for results that involve a non-terminating division (e.g. 1.75 / 3.75). */
    private static final BigDecimal TOLERANCE = new BigDecimal("1E-20");

    private TestValues() {}

    public static RoundedValue rv(String value) {
        return RoundedValue.of(value);
    }

    /** Exact numeric equality, ignoring scale: 36 equals 36.000. */
    public static void assertExactly(RoundedValue actual, String expected) {
        assertThat(actual).isNotNull();
        assertThat(actual.getValue()).isEqualByComparingTo(expected);
    }

    /** Equality within 1E-20, for results with a recurring decimal expansion. */
    public static void assertApproximately(RoundedValue actual, String expected) {
        assertThat(actual).isNotNull();
        assertThat(actual.getValue()).isCloseTo(new BigDecimal(expected), within(TOLERANCE));
    }
}
