package com.crf.ratingmotor.domain;

import java.time.LocalDate;

/**
 * Builds MaturityDates from day offsets around a fixed "today" (2026-01-01), so each scenario reads
 * as durations. Under ACT/365 Fixed, 365 days is exactly 1 year and 730 days exactly 2 years.
 */
public final class MaturityScenarios {

    public static final LocalDate TODAY = LocalDate.of(2026, 1, 1);

    private MaturityScenarios() {}

    public static LocalDate day(int offsetFromToday) {
        return TODAY.plusDays(offsetFromToday);
    }

    /** All offsets are in days relative to today; negative means in the past. */
    public static MaturityDates dates(int guaranteeImplementation, int guaranteeMaturity,
                                      int facilityImplementation, int facilityMaturity) {
        return new MaturityDates(TODAY,
            day(guaranteeImplementation), day(guaranteeMaturity),
            day(facilityImplementation), day(facilityMaturity));
    }

    public static MaturityAssessment assess(int guaranteeImplementation, int guaranteeMaturity,
                                            int facilityImplementation, int facilityMaturity) {
        return MaturityAssessment.of(
            dates(guaranteeImplementation, guaranteeMaturity, facilityImplementation, facilityMaturity),
            DayCountConvention.ACT_365_FIXED);
    }

    /** Guarantee outlives the facility: no mismatch, discount 0. */
    public static MaturityAssessment noMismatch() {
        return assess(-365, 1460, -365, 730);
    }

    /** Mismatch with t = 2 and T = 4 years: discount 1 - 1.75 / 3.75 = 0.5333... */
    public static MaturityAssessment partialMismatch() {
        return assess(-365, 730, -365, 1460);
    }

    /** Mismatch with a residual guarantee under 3 months: discount 100%. */
    public static MaturityAssessment fullMismatch() {
        return assess(-365, 30, -365, 1460);
    }

    /** Guarantee starts after the facility and has not started yet. */
    public static MaturityAssessment guaranteeNotYetStarted() {
        return assess(100, 400, -365, 1460);
    }
}
