package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.function.Function;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/** Covers PercentageDriver through its two concrete drivers. */
class PercentageDriverTest {

    @ParameterizedTest(name = "{0}% is stored as the fraction {1}")
    @CsvSource({"0, 0", "10, 0.1", "40.87, 0.4087", "50, 0.5", "100, 1", "33.333, 0.33333"})
    void storesPercentAsFraction(String percent, String fraction) {
        ProposedDiscountRateDriver proposed = new ProposedDiscountRateDriver(rv(percent));
        AllocationRateDriver allocation = new AllocationRateDriver(rv(percent));

        assertExactly(proposed.getEstimateValue(), fraction);
        assertExactly(proposed.percent(), percent);
        assertExactly(allocation.getEstimateValue(), fraction);
        assertExactly(allocation.percent(), percent);
    }

    @ParameterizedTest(name = "{0}% is rejected")
    @ValueSource(strings = {"-0.01", "-10", "100.01", "150"})
    void rejectsOutsideZeroToHundred(String percent) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new ProposedDiscountRateDriver(rv(percent)))
            .withMessageStartingWith("PROPOSED_DISCOUNT_RATE must be between 0 and 100");
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new AllocationRateDriver(rv(percent)))
            .withMessageStartingWith("ALLOCATION_RATE must be between 0 and 100");
    }

    @Test
    @DisplayName("null is rejected with the driver's name in the message")
    void rejectsNull() {
        assertThatNullPointerException()
            .isThrownBy(() -> new ProposedDiscountRateDriver(null))
            .withMessage("PROPOSED_DISCOUNT_RATE must not be null");
        assertThatNullPointerException()
            .isThrownBy(() -> new AllocationRateDriver(null))
            .withMessage("ALLOCATION_RATE must not be null");
    }

    @Test
    void namesAreDistinct() {
        assertThat(new ProposedDiscountRateDriver(RoundedValue.ZERO).getName())
            .isEqualTo("PROPOSED_DISCOUNT_RATE").isEqualTo(ProposedDiscountRateDriver.NAME);
        assertThat(new AllocationRateDriver(RoundedValue.ZERO).getName())
            .isEqualTo("ALLOCATION_RATE").isEqualTo(AllocationRateDriver.NAME);
    }

    @Test
    @DisplayName("both drivers follow the same rules, so the shared base class is exercised by each")
    void sameRulesForBoth() {
        Function<RoundedValue, PercentageDriver> proposed = ProposedDiscountRateDriver::new;
        Function<RoundedValue, PercentageDriver> allocation = AllocationRateDriver::new;

        assertThat(proposed.apply(rv("25")).getEstimateValue()).isEqualTo(allocation.apply(rv("25")).getEstimateValue());
    }
}
