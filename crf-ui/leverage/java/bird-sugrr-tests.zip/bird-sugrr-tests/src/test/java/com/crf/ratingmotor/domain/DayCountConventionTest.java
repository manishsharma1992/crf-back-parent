package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;

import java.time.LocalDate;

import static com.crf.ratingmotor.domain.TestValues.assertApproximately;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;

class DayCountConventionTest {

    @Nested
    @DisplayName("ACT/365 Fixed")
    class Act365Fixed {

        @ParameterizedTest(name = "{0} -> {1} = {2}")
        @CsvSource({
            "2023-01-01, 2024-01-01, 1",                              // 365 days
            "2026-01-01, 2028-01-01, 2",                              // 730 days
            "2024-01-01, 2025-01-01, 1.002739726027397260273972603",  // 366 / 365: leap year counts one extra day
            "2026-01-01, 2026-04-01, 0.2465753424657534246575342466", // 90 / 365
            "2026-03-15, 2026-03-15, 0",                              // same day
            "2025-01-01, 2024-01-01, -1.002739726027397260273972603"  // reversed dates give a negative fraction
        })
        void yearFraction(LocalDate from, LocalDate to, String expected) {
            assertApproximately(DayCountConvention.ACT_365_FIXED.yearFraction(from, to), expected);
        }
    }

    @Nested
    @DisplayName("ACT/ACT ISDA")
    class ActActIsda {

        @ParameterizedTest(name = "{0} -> {1} = {2}")
        @CsvSource({
            "2024-01-01, 2025-01-01, 1",                              // full leap year is exactly 1
            "2023-01-01, 2024-01-01, 1",                              // full normal year is exactly 1
            "2023-01-01, 2026-01-01, 3",                              // several whole years
            "2024-03-01, 2024-03-31, 0.08196721311475409836065573770", // 30 / 366, inside one leap year
            "2023-07-01, 2024-07-01, 1.001377348603937420465603713",   // 184/365 + 182/366, spans the leap day
            "2024-03-01, 2024-03-01, 0"                               // same day
        })
        void yearFraction(LocalDate from, LocalDate to, String expected) {
            assertApproximately(DayCountConvention.ACT_ACT_ISDA.yearFraction(from, to), expected);
        }

        @Test
        @DisplayName("reversed dates give the negative of the forward fraction")
        void reversedDates() {
            LocalDate from = LocalDate.of(2023, 7, 1);
            LocalDate to = LocalDate.of(2024, 7, 1);

            assertThat(DayCountConvention.ACT_ACT_ISDA.yearFraction(to, from))
                .isEqualTo(DayCountConvention.ACT_ACT_ISDA.yearFraction(from, to).negate());
        }
    }

    @Test
    @DisplayName("the two conventions differ only when a leap year is involved")
    void conventionsDifferOnlyForLeapYears() {
        LocalDate normalStart = LocalDate.of(2025, 1, 1);
        LocalDate normalEnd = LocalDate.of(2026, 1, 1);
        LocalDate leapStart = LocalDate.of(2028, 1, 1);
        LocalDate leapEnd = LocalDate.of(2029, 1, 1);

        assertThat(DayCountConvention.ACT_365_FIXED.yearFraction(normalStart, normalEnd))
            .isEqualTo(DayCountConvention.ACT_ACT_ISDA.yearFraction(normalStart, normalEnd));
        assertThat(DayCountConvention.ACT_365_FIXED.yearFraction(leapStart, leapEnd))
            .isNotEqualTo(DayCountConvention.ACT_ACT_ISDA.yearFraction(leapStart, leapEnd));
    }

    @ParameterizedTest
    @EnumSource(DayCountConvention.class)
    @DisplayName("a zero-length period is zero under every convention")
    void zeroLength(DayCountConvention convention) {
        LocalDate date = LocalDate.of(2028, 2, 29);
        assertExactly(convention.yearFraction(date, date), "0");
    }
}
