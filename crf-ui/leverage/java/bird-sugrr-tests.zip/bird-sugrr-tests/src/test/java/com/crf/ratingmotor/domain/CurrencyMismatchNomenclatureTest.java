package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

class CurrencyMismatchNomenclatureTest {

    @ParameterizedTest(name = "guarantee exists={0}, facility exists={1} -> covers both = {2}")
    @CsvSource({"false, false, false", "true, false, false", "false, true, false", "true, true, true"})
    void coversBothCurrencies(boolean guaranteeExists, boolean facilityExists, boolean expected) {
        assertThat(new CurrencyMismatchNomenclature(guaranteeExists, facilityExists, rv("0.1")).coversBothCurrencies())
            .isEqualTo(expected);
    }

    @Test
    @DisplayName("the discount may be absent at construction, even with both flags true (same-currency requests)")
    void discountMayBeAbsent() {
        assertThatCode(() -> new CurrencyMismatchNomenclature(true, true, null)).doesNotThrowAnyException();
    }

    @ParameterizedTest(name = "discount {0} is accepted")
    @ValueSource(strings = {"0", "0.085", "0.4087", "1"})
    void acceptsFractionsBetweenZeroAndOne(String fraction) {
        CurrencyMismatchNomenclature n = new CurrencyMismatchNomenclature(true, true, rv(fraction));

        assertThat(n.discount()).isEqualTo(rv(fraction));
        assertExactly(n.requiredDiscount(), fraction);
    }

    @Test
    @DisplayName("requiredDiscount fails with a client error when the value is needed but absent")
    void requiredDiscountMissing() {
        CurrencyMismatchNomenclature n = new CurrencyMismatchNomenclature(true, true, null);
        assertThatIllegalArgumentException()
            .isThrownBy(n::requiredDiscount)
            .withMessage("currencyMismatch is required when the currencies differ and both are in the nomenclature");
    }

    @ParameterizedTest(name = "discount {0} is rejected whatever the flags")
    @ValueSource(strings = {"-0.0001", "1.0001", "8.5", "100"})
    @DisplayName("a percentage such as 8.5 instead of 0.085 is rejected")
    void rejectsOutOfRange(String value) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new CurrencyMismatchNomenclature(true, true, rv(value)))
            .withMessageStartingWith("currencyMismatch must be a fraction between 0 and 1");
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new CurrencyMismatchNomenclature(false, false, rv(value)))
            .withMessageStartingWith("currencyMismatch must be a fraction between 0 and 1");
    }
}
