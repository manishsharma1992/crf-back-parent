package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

class CurrencyCodeTest {

    @ParameterizedTest(name = "\"{0}\" becomes {1}")
    @CsvSource(delimiter = '|', value = {
        "EUR     | EUR",
        "eur     | EUR",
        "uSd     | USD",
        "' GBP ' | GBP"
    })
    void normalisesToTrimmedUpperCase(String raw, String expected) {
        assertThat(new CurrencyCode(raw).value()).isEqualTo(expected);
    }

    @ParameterizedTest(name = "\"{0}\" is rejected")
    @NullAndEmptySource
    @ValueSource(strings = {"   ", "EU", "EURO", "E1R", "E R", "€UR", "123"})
    void rejectsInvalidCodes(String raw) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new CurrencyCode(raw))
            .withMessage("Currency must be a 3-letter code: " + raw);
    }

    @Test
    void sameCodeInDifferentCaseIsEqual() {
        assertThat(new CurrencyCode("eur")).isEqualTo(new CurrencyCode("EUR"));
    }
}
