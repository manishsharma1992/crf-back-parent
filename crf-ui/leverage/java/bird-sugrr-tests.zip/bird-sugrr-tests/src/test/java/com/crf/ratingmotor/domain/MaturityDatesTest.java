package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class MaturityDatesTest {

    private static final LocalDate D = LocalDate.of(2026, 1, 1);

    @Test
    void keepsAllFiveDates() {
        MaturityDates dates = new MaturityDates(D, D.plusDays(1), D.plusDays(2), D.plusDays(3), D.plusDays(4));

        assertThat(dates.currentDate()).isEqualTo(D);
        assertThat(dates.guaranteeImplementationDate()).isEqualTo(D.plusDays(1));
        assertThat(dates.guaranteeMaturityDate()).isEqualTo(D.plusDays(2));
        assertThat(dates.facilityImplementationDate()).isEqualTo(D.plusDays(3));
        assertThat(dates.facilityMaturityDate()).isEqualTo(D.plusDays(4));
    }

    @Test
    void rejectsNullCurrentDate() {
        assertThatNullPointerException().isThrownBy(() -> new MaturityDates(null, D, D, D, D)).withMessage("currentDate");
    }

    @Test
    void rejectsNullGuaranteeImplementationDate() {
        assertThatNullPointerException().isThrownBy(() -> new MaturityDates(D, null, D, D, D))
            .withMessage("guaranteeImplementationDate");
    }

    @Test
    void rejectsNullGuaranteeMaturityDate() {
        assertThatNullPointerException().isThrownBy(() -> new MaturityDates(D, D, null, D, D))
            .withMessage("guaranteeMaturityDate");
    }

    @Test
    void rejectsNullFacilityImplementationDate() {
        assertThatNullPointerException().isThrownBy(() -> new MaturityDates(D, D, D, null, D))
            .withMessage("facilityImplementationDate");
    }

    @Test
    void rejectsNullFacilityMaturityDate() {
        assertThatNullPointerException().isThrownBy(() -> new MaturityDates(D, D, D, D, null))
            .withMessage("facilityMaturityDate");
    }
}
