package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.BirdSugrrComputeQuery;
import com.crf.ratingmotor.application.BirdSugrrComputeResult;
import com.crf.ratingmotor.application.GuaranteeRecoveryComputeManagementService;
import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.ExchangeRates;
import com.crf.ratingmotor.domain.ExpectedRecovery;
import com.crf.ratingmotor.domain.ExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.MissingExchangeRateException;
import com.crf.ratingmotor.domain.RecoveryFactors;
import com.crf.ratingmotor.domain.UnitAmount;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.cache.Cache;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.crf.ratingmotor.domain.RecoveryFactorsBuilder.factors;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.not;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Web layer only: request binding, Bean Validation, response mapping and error handling.
 * The application service is mocked.
 *
 * <p>Spring Boot 3.4+: @MockitoBean. On an older Boot, use @MockBean
 * (org.springframework.boot.test.mock.mockito.MockBean) instead.</p>
 */
@WebMvcTest(BirdSugrrComputeController.class)
class BirdSugrrComputeControllerTest {

    /** Adjust if the controller has a class-level @RequestMapping prefix. */
    private static final String URL = "/calculate/expectedRecoveryAmount";

    /** The Swagger demo request: 10 MILLION EUR guarantee on an EUR facility. */
    private static final String VALID_REQUEST = """
        {
          "currentDate": "2026-11-10",
          "guaranteeImplementationDate": "2025-01-01",
          "guaranteeMaturityDate": "2031-01-01",
          "guarantorCounterpartyRating": "3+",
          "borrowerOrGuarantorCorrelation": "LOW",
          "nonEnforceabilityRisk": "LOW",
          "proposedDiscountRate": 10,
          "guaranteeAmount": 10,
          "guaranteeUnit": "MILLION",
          "guaranteeCurrency": "EUR",
          "allocationRate": 50,
          "facilityImplementationDate": "2025-01-01",
          "facilityMaturityDate": "2030-01-01",
          "facilityAmount": 20,
          "facilityUnit": "MILLION",
          "facilityCurrency": "EUR",
          "obligorCounterpartyRating": "5-",
          "facilityToGuaranteeCurrencyRate": 1,
          "guaranteeToFacilityCurrencyRate": 1,
          "guaranteeCurrencyExistingFlag": true,
          "facilityCurrencyExistingFlag": true,
          "currencyMismatch": 0.085
        }
        """;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private GuaranteeRecoveryComputeManagementService computeService;

    private ResultActions postJson(String body) throws Exception {
        return mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(body));
    }

    /** The valid request with one field replaced (or removed when value is null and remove is true). */
    private String requestWith(String field, Object value, boolean remove) throws Exception {
        Map<String, Object> body = objectMapper.readValue(VALID_REQUEST, new TypeReference<LinkedHashMap<String, Object>>() {});
        if (remove) {
            body.remove(field);
        } else {
            body.put(field, value);
        }
        return objectMapper.writeValueAsString(body);
    }

    /** The same-currency worked example: RecupE = 3,600,000 EUR. */
    private static BirdSugrrComputeResult workedExample() {
        RecoveryFactors f = factors().proposedDiscountPercent("10").correlationCoefficient("0.8").allocationPercent("50").build();
        ExpectedRecovery r = new ExpectedRecoveryCalculatorDomainService()
            .calculate(new UnitAmount(rv("10"), Unit.MILLION), new ExchangeRates(null, null), f);
        return new BirdSugrrComputeResult(r, f.asList());
    }

    @Nested
    @DisplayName("200 OK")
    class Success {

        @Test
        @DisplayName("returns the four recovery figures, rounded, with currencies and drivers")
        void returnsResponse() throws Exception {
            when(computeService.compute(any())).thenReturn(workedExample());

            postJson(VALID_REQUEST)
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.expectedRecovery.amount").value(3600000.00))
                .andExpect(jsonPath("$.expectedRecovery.currency").value("EUR"))
                .andExpect(jsonPath("$.recoveryRatePercent").value(36.0))
                .andExpect(jsonPath("$.recoveryInGuaranteeCurrency.amount").value(3600000.00))
                .andExpect(jsonPath("$.recoveryInGuaranteeCurrency.currency").value("EUR"))
                .andExpect(jsonPath("$.recoveryInFacilityCurrency.amount").value(3600000.00))
                .andExpect(jsonPath("$.recoveryInFacilityCurrency.currency").value("EUR"))
                .andExpect(jsonPath("$.drivers.length()").value(5))
                .andExpect(jsonPath("$.drivers[0].name").value("CORRELATION_COEFFICIENT"))
                .andExpect(jsonPath("$.drivers[0].value").value(0.8))
                .andExpect(jsonPath("$.drivers[4].name").value("ALLOCATION_RATE"))
                .andExpect(jsonPath("$.drivers[4].value").value(0.5));
        }

        @Test
        @DisplayName("binds every JSON field into the query, including ISO dates")
        void bindsQuery() throws Exception {
            when(computeService.compute(any())).thenReturn(workedExample());

            postJson(VALID_REQUEST).andExpect(status().isOk());

            ArgumentCaptor<BirdSugrrComputeQuery> captor = ArgumentCaptor.forClass(BirdSugrrComputeQuery.class);
            verify(computeService).compute(captor.capture());
            BirdSugrrComputeQuery q = captor.getValue();
            assertThat(q.currentDate()).isEqualTo(LocalDate.of(2026, 11, 10));
            assertThat(q.guaranteeMaturityDate()).isEqualTo(LocalDate.of(2031, 1, 1));
            assertThat(q.guarantorCounterpartyRating()).isEqualTo("3+");
            assertThat(q.obligorCounterpartyRating()).isEqualTo("5-");
            assertThat(q.guaranteeAmount()).isEqualByComparingTo("10");
            assertThat(q.guaranteeUnit()).isEqualTo("MILLION");
            assertThat(q.guaranteeCurrencyExistingFlag()).isTrue();
            assertThat(q.facilityCurrencyExistingFlag()).isTrue();
            assertThat(q.currencyMismatch()).isEqualByComparingTo("0.085");
        }

        @ParameterizedTest(name = "optional field {0} may be omitted")
        @CsvSource({"nonEnforceabilityRisk", "facilityAmount", "facilityUnit",
                    "facilityToGuaranteeCurrencyRate", "guaranteeToFacilityCurrencyRate", "currencyMismatch"})
        void optionalFields(String field) throws Exception {
            when(computeService.compute(any())).thenReturn(workedExample());

            postJson(requestWith(field, null, true)).andExpect(status().isOk());
        }

        @ParameterizedTest(name = "{0} = {1} is accepted")
        @CsvSource({
            "borrowerOrGuarantorCorrelation, high",
            "guarantorCounterpartyRating, 10-",
            "obligorCounterpartyRating, 1",
            "guaranteeUnit, unit",
            "guaranteeCurrency, usd",
            "proposedDiscountRate, 0",
            "allocationRate, 100",
            "currencyMismatch, 1"
        })
        void boundaryValuesAccepted(String field, String value) throws Exception {
            when(computeService.compute(any())).thenReturn(workedExample());

            postJson(requestWith(field, value, false)).andExpect(status().isOk());
        }
    }

    @Nested
    @DisplayName("400 Bad Request from Bean Validation; the service is never called")
    class ValidationErrors {

        @ParameterizedTest(name = "missing {0}")
        @CsvSource({
            "currentDate", "guaranteeImplementationDate", "guaranteeMaturityDate",
            "facilityImplementationDate", "facilityMaturityDate",
            "guarantorCounterpartyRating", "obligorCounterpartyRating", "borrowerOrGuarantorCorrelation",
            "proposedDiscountRate", "guaranteeAmount", "guaranteeUnit", "guaranteeCurrency",
            "allocationRate", "facilityCurrency", "guaranteeCurrencyExistingFlag", "facilityCurrencyExistingFlag"
        })
        void missingRequiredField(String field) throws Exception {
            postJson(requestWith(field, null, true))
                .andExpect(status().isBadRequest())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.errors[*].field", hasItem(field)));

            verify(computeService, never()).compute(any());
        }

        @ParameterizedTest(name = "{0} = {1} is rejected")
        @CsvSource({
            "guarantorCounterpartyRating,    11",
            "guarantorCounterpartyRating,    0",
            "guarantorCounterpartyRating,    +5",
            "obligorCounterpartyRating,      5++",
            "obligorCounterpartyRating,      A",
            "borrowerOrGuarantorCorrelation, MEDIUM",
            "guaranteeUnit,                  HUNDRED",
            "guaranteeCurrency,              EURO",
            "facilityCurrency,               E1R",
            "proposedDiscountRate,           -1",
            "proposedDiscountRate,           100.01",
            "allocationRate,                 101",
            "guaranteeAmount,                0",
            "guaranteeAmount,                -5",
            "facilityToGuaranteeCurrencyRate, 0",
            "guaranteeToFacilityCurrencyRate, -1",
            "currencyMismatch,               8.5",
            "currencyMismatch,               -0.1"
        })
        void invalidValue(String field, String value) throws Exception {
            postJson(requestWith(field, value, false))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[*].field", hasItem(field)));

            verify(computeService, never()).compute(any());
        }

        @Test
        @DisplayName("several errors are all reported at once")
        void severalErrors() throws Exception {
            Map<String, Object> body = objectMapper.readValue(VALID_REQUEST, new TypeReference<LinkedHashMap<String, Object>>() {});
            body.remove("guaranteeAmount");
            body.put("guaranteeCurrency", "EURO");

            postJson(objectMapper.writeValueAsString(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.length()").value(2));
        }
    }

    @Nested
    @DisplayName("other client errors")
    class OtherClientErrors {

        @Test
        @DisplayName("an invalid date is a 400, not a 500")
        void invalidDate() throws Exception {
            postJson(requestWith("currentDate", "2026-13-45", false))
                .andExpect(status().isBadRequest());
            verify(computeService, never()).compute(any());
        }

        @Test
        @DisplayName("a date in another format is a 400")
        void wrongDateFormat() throws Exception {
            postJson(requestWith("currentDate", "10/11/2026", false))
                .andExpect(status().isBadRequest());
        }

        @Test
        void malformedJson() throws Exception {
            postJson("{\"currentDate\": ").andExpect(status().isBadRequest());
        }

        @Test
        void emptyBody() throws Exception {
            postJson("").andExpect(status().isBadRequest());
        }

        @Test
        void wrongContentType() throws Exception {
            mockMvc.perform(post(URL).contentType(MediaType.TEXT_PLAIN).content(VALID_REQUEST))
                .andExpect(status().isUnsupportedMediaType());
        }

        @Test
        @DisplayName("a domain rule violation from the service is a 400 with its message")
        void domainRuleViolation() throws Exception {
            when(computeService.compute(any()))
                .thenThrow(new IllegalArgumentException("Guarantee amount must be greater than zero"));

            postJson(VALID_REQUEST)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.detail").value("Guarantee amount must be greater than zero"));
        }

        @Test
        @DisplayName("a missing FX rate on a currency mismatch is a 400")
        void missingExchangeRate() throws Exception {
            when(computeService.compute(any()))
                .thenThrow(new MissingExchangeRateException("guaranteeToFacilityCurrencyRate"));

            postJson(VALID_REQUEST)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail")
                    .value("guaranteeToFacilityCurrencyRate is required when the guarantee and facility currencies differ"));
        }
    }

    @Nested
    @DisplayName("500 Internal Server Error, without leaking internals")
    class ServerErrors {

        @Test
        void unexpectedException() throws Exception {
            when(computeService.compute(any())).thenThrow(new RuntimeException("connection to db-host:5432 refused"));

            postJson(VALID_REQUEST)
                .andExpect(status().isInternalServerError())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.detail").value("Internal error while computing expected recovery"))
                .andExpect(content().string(not(containsString("db-host"))));
        }

        @Test
        @DisplayName("incomplete matrix data in the database, surfaced through the cache, is a 500")
        void incompleteReferenceData() throws Exception {
            when(computeService.compute(any())).thenThrow(new Cache.ValueRetrievalException(
                "LOW", () -> null, new IllegalStateException("Correlation coefficient data for LOW is incomplete")));

            postJson(VALID_REQUEST)
                .andExpect(status().isInternalServerError())
                .andExpect(content().string(not(containsString("incomplete"))));
        }

        @Test
        @DisplayName("an IllegalStateException is a 500, not a 400")
        void illegalState() throws Exception {
            when(computeService.compute(any())).thenThrow(new IllegalStateException("No coefficients found for correlation LOW"));

            postJson(VALID_REQUEST).andExpect(status().isInternalServerError());
        }
    }
}
