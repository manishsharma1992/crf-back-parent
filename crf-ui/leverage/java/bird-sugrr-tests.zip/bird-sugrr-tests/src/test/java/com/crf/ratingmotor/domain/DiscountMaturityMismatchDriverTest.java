package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static com.crf.ratingmotor.domain.MaturityScenarios.assess;
import static com.crf.ratingmotor.domain.TestValues.assertApproximately;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Calculation 5 (Dmm). Offsets are days from "today" under ACT/365 Fixed. Argument order of assess(...):
 * guarantee implementation, guarantee maturity, facility implementation, facility maturity.
 * Expected values were worked out by hand, independently of the production formula.
 */
class DiscountMaturityMismatchDriverTest {

    private static DiscountMaturityMismatchDriver driver(MaturityAssessment assessment) {
        return new DiscountMaturityMismatchDriver(assessment);
    }

    @Test
    void nameAndAssessmentAreExposed() {
        MaturityAssessment assessment = MaturityScenarios.noMismatch();
        DiscountMaturityMismatchDriver driver = driver(assessment);

        assertThat(driver.getName()).isEqualTo("DISCOUNT_MATURITY_MISMATCH").isEqualTo(DiscountMaturityMismatchDriver.NAME);
        assertThat(driver.assessment()).isSameAs(assessment);
    }

    @Nested
    @DisplayName("indicator 0: discount 0%")
    class NoMismatch {

        @Test
        void guaranteeOutlivesFacility() {
            assertExactly(driver(MaturityScenarios.noMismatch()).getEstimateValue(), "0");
        }

        @Test
        @DisplayName("a short guarantee that has not started yet gets 0%, not 100%")
        void guaranteeNotYetStarted() {
            assertExactly(driver(assess(100, 120, -365, 1460)).getEstimateValue(), "0");
        }
    }

    @Nested
    @DisplayName("indicator 1 with residual guarantee < 3 months OR initial guarantee < 1 year: 100%")
    class FullDiscount {

        // Exactly 0.25 years cannot occur: it would be 91.25 days (ACT/365) or 91.5 days (ACT/ACT, leap year).
        // So 91 and 92 days are the closest boundary cases there are.
        @Test
        @DisplayName("residual guarantee of 91 days (0.2493 years) is under 3 months")
        void residualJustUnderThreeMonths() {
            assertExactly(driver(assess(-365, 91, -365, 1460)).getEstimateValue(), "1");
        }

        @Test
        @DisplayName("initial guarantee of 364 days is under 1 year even with a long enough residual")
        void initialJustUnderOneYear() {
            assertExactly(driver(assess(0, 364, 0, 1460)).getEstimateValue(), "1");
        }

        @Test
        @DisplayName("negative residuals (both already matured) give 100%")
        void bothMatured() {
            assertExactly(driver(assess(-1000, -200, -1000, -100)).getEstimateValue(), "1");
        }
    }

    @Nested
    @DisplayName("indicator 1 otherwise: 1 - MIN(1; (t - 0.25) / (T - 0.25))")
    class Formula {

        @Test
        @DisplayName("residual guarantee of 92 days (0.2521 years) is over 3 months, so the formula applies")
        void residualJustOverThreeMonths() {
            // t = 92/365, T = 1460/365 = 4  ->  1 - (92/365 - 0.25) / 3.75 = 0.99945205479452054794520547945...
            assertApproximately(driver(assess(-365, 92, -365, 1460)).getEstimateValue(),
                "0.9994520547945205479452054795");
        }

        @Test
        @DisplayName("initial guarantee of exactly 1 year is not under 1 year, so the formula applies")
        void initialExactlyOneYear() {
            // t = 1, T = 1000/365  ->  1 - 0.75 / (1000/365 - 0.25) = 635 / 908.75
            assertApproximately(driver(assess(0, 365, 0, 1000)).getEstimateValue(),
                "0.6987620357634112792297111417");
        }

        @Test
        @DisplayName("t = 2, T = 4, neither capped")
        void neitherCapped() {
            // 1 - 1.75 / 3.75
            assertApproximately(driver(MaturityScenarios.partialMismatch()).getEstimateValue(),
                "0.5333333333333333333333333333");
        }

        @Test
        @DisplayName("t = 2, T = 6 capped to 5")
        void facilityCapped() {
            // 1 - 1.75 / 4.75
            assertApproximately(driver(assess(-365, 730, -365, 2190)).getEstimateValue(),
                "0.6315789473684210526315789474");
        }

        @Test
        @DisplayName("t = 6 and T = 7, both capped to 5: discount 0")
        void bothCapped() {
            assertExactly(driver(assess(-365, 2190, -365, 2555)).getEstimateValue(), "0");
        }

        @Test
        @DisplayName("exactly 5 years residual guarantee is not capped further")
        void guaranteeExactlyFiveYears() {
            // t = 5, T = 6 capped to 5  ->  1 - 4.75 / 4.75 = 0
            assertExactly(driver(assess(-365, 1825, -365, 2190)).getEstimateValue(), "0");
        }
    }
}
