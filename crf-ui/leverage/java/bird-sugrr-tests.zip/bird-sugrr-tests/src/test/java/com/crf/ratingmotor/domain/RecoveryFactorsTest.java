package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static com.crf.ratingmotor.domain.RecoveryFactorsBuilder.factors;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class RecoveryFactorsTest {

    private final RecoveryFactors valid = factors().build();

    @Test
    @DisplayName("asList returns the five drivers in a fixed order")
    void asListOrder() {
        assertThat(valid.asList())
            .extracting(Driver::getName)
            .containsExactly("CORRELATION_COEFFICIENT", "DISCOUNT_MATURITY_MISMATCH", "DISCOUNT_CURRENCY_MISMATCH",
                             "PROPOSED_DISCOUNT_RATE", "ALLOCATION_RATE");
        assertThat(valid.asList())
            .containsExactly(valid.correlation(), valid.maturity(), valid.currency(),
                             valid.proposedDiscount(), valid.allocation());
    }

    @Test
    void currenciesDiffer() {
        assertThat(factors().currencies("EUR", "EUR").build().currenciesDiffer()).isFalse();
        assertThat(factors().currencies("USD", "EUR").build().currenciesDiffer()).isTrue();
    }

    @Test
    void guaranteeNotYetStarted() {
        assertThat(factors().maturity(MaturityScenarios.noMismatch()).build().guaranteeNotYetStarted()).isFalse();
        assertThat(factors().maturity(MaturityScenarios.guaranteeNotYetStarted()).build().guaranteeNotYetStarted()).isTrue();
    }

    @Test
    void rejectsNullCorrelation() {
        assertThatNullPointerException()
            .isThrownBy(() -> new RecoveryFactors(null, valid.maturity(), valid.currency(),
                                                  valid.proposedDiscount(), valid.allocation()))
            .withMessage("correlation");
    }

    @Test
    void rejectsNullMaturity() {
        assertThatNullPointerException()
            .isThrownBy(() -> new RecoveryFactors(valid.correlation(), null, valid.currency(),
                                                  valid.proposedDiscount(), valid.allocation()))
            .withMessage("maturity");
    }

    @Test
    void rejectsNullCurrency() {
        assertThatNullPointerException()
            .isThrownBy(() -> new RecoveryFactors(valid.correlation(), valid.maturity(), null,
                                                  valid.proposedDiscount(), valid.allocation()))
            .withMessage("currency");
    }

    @Test
    void rejectsNullProposedDiscount() {
        assertThatNullPointerException()
            .isThrownBy(() -> new RecoveryFactors(valid.correlation(), valid.maturity(), valid.currency(),
                                                  null, valid.allocation()))
            .withMessage("proposedDiscount");
    }

    @Test
    void rejectsNullAllocation() {
        assertThatNullPointerException()
            .isThrownBy(() -> new RecoveryFactors(valid.correlation(), valid.maturity(), valid.currency(),
                                                  valid.proposedDiscount(), null))
            .withMessage("allocation");
    }
}
