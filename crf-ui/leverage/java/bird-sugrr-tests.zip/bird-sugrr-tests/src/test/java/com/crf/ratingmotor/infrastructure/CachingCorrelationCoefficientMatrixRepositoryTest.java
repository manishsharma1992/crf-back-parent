package com.crf.ratingmotor.infrastructure;

import com.crf.ratingmotor.domain.Correlation;
import com.crf.ratingmotor.domain.CorrelationCoefficientMatrix;
import com.crf.ratingmotor.domain.CorrelationCoefficientMatrixRepository;
import com.crf.ratingmotor.domain.TestMatrices;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;

import java.util.EnumMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Uses Spring's in-memory ConcurrentMapCacheManager in place of Caffeine: the decorator only depends on
 * the CacheManager and Cache interfaces, so the caching behaviour under test is the same.
 */
class CachingCorrelationCoefficientMatrixRepositoryTest {

    /** Counts how often each correlation is loaded and can be told to fail. */
    private static final class CountingRepository implements CorrelationCoefficientMatrixRepository {
        final Map<Correlation, Integer> loads = new EnumMap<>(Correlation.class);
        boolean fail;

        @Override
        public CorrelationCoefficientMatrix findBy(Correlation correlation) {
            loads.merge(correlation, 1, Integer::sum);
            if (fail) {
                throw new IllegalStateException("database down");
            }
            return TestMatrices.asymmetric(correlation);
        }

        int loadsOf(Correlation correlation) {
            return loads.getOrDefault(correlation, 0);
        }
    }

    private CountingRepository delegate;
    private CacheManager cacheManager;
    private CachingCorrelationCoefficientMatrixRepository repository;

    @BeforeEach
    void setUp() {
        delegate = new CountingRepository();
        cacheManager = new ConcurrentMapCacheManager(
            CacheNames.HLC.getCacheName(), CacheNames.HRC.getCacheName(),
            CacheNames.CORRELATION_MATRIX_LOW.getCacheName(), CacheNames.CORRELATION_MATRIX_HIGH.getCacheName());
        repository = new CachingCorrelationCoefficientMatrixRepository(delegate, cacheManager);
    }

    @Test
    @DisplayName("the second lookup is served from the cache")
    void cachesAfterFirstLoad() {
        CorrelationCoefficientMatrix first = repository.findBy(Correlation.LOW);
        CorrelationCoefficientMatrix second = repository.findBy(Correlation.LOW);

        assertThat(second).isSameAs(first);
        assertThat(delegate.loadsOf(Correlation.LOW)).isEqualTo(1);
    }

    @Test
    @DisplayName("LOW and HIGH are cached separately")
    void separateCachesPerCorrelation() {
        CorrelationCoefficientMatrix low = repository.findBy(Correlation.LOW);
        CorrelationCoefficientMatrix high = repository.findBy(Correlation.HIGH);
        repository.findBy(Correlation.LOW);
        repository.findBy(Correlation.HIGH);

        assertThat(low.correlation()).isEqualTo(Correlation.LOW);
        assertThat(high.correlation()).isEqualTo(Correlation.HIGH);
        assertThat(delegate.loadsOf(Correlation.LOW)).isEqualTo(1);
        assertThat(delegate.loadsOf(Correlation.HIGH)).isEqualTo(1);
    }

    @Test
    @DisplayName("each correlation is stored in its own named cache")
    void usesTheNamedCaches() {
        repository.findBy(Correlation.LOW);

        Cache lowCache = cacheManager.getCache(CacheNames.CORRELATION_MATRIX_LOW.getCacheName());
        Cache highCache = cacheManager.getCache(CacheNames.CORRELATION_MATRIX_HIGH.getCacheName());
        Object inLowCache = lowCache.get(Correlation.LOW, () -> null);
        Object inHighCache = highCache.get(Correlation.LOW, () -> "not cached here");
        assertThat(inLowCache).isInstanceOf(CorrelationCoefficientMatrix.class);
        assertThat(inHighCache).isEqualTo("not cached here");
    }

    @Test
    @DisplayName("evictAll clears both caches, so the next lookups reload")
    void evictAllReloads() {
        repository.findBy(Correlation.LOW);
        repository.findBy(Correlation.HIGH);

        repository.evictAll();
        repository.findBy(Correlation.LOW);
        repository.findBy(Correlation.HIGH);

        assertThat(delegate.loadsOf(Correlation.LOW)).isEqualTo(2);
        assertThat(delegate.loadsOf(Correlation.HIGH)).isEqualTo(2);
    }

    @Test
    @DisplayName("a failed load is not cached: the error surfaces and the next call tries again")
    void failuresAreNotCached() {
        delegate.fail = true;

        assertThatThrownBy(() -> repository.findBy(Correlation.LOW))
            .isInstanceOf(Cache.ValueRetrievalException.class)
            .hasCauseInstanceOf(IllegalStateException.class);

        delegate.fail = false;
        assertThat(repository.findBy(Correlation.LOW)).isNotNull();
        assertThat(delegate.loadsOf(Correlation.LOW)).isEqualTo(2);
    }

    @Test
    void cacheNamesAreStable() {
        assertThat(CacheNames.CORRELATION_MATRIX_LOW.getCacheName()).isEqualTo("correlationMatrixLow");
        assertThat(CacheNames.CORRELATION_MATRIX_HIGH.getCacheName()).isEqualTo("correlationMatrixHigh");
        assertThat(CacheNames.HLC.getCacheName()).isEqualTo("hlc");
        assertThat(CacheNames.HRC.getCacheName()).isEqualTo("hrc");
    }
}
