package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

class CounterpartyRatingTest {

    @ParameterizedTest(name = "\"{0}\" parses to {1}")
    @CsvSource(delimiter = '|', value = {
        "1   | 1",
        "1+  | 1",
        "1-  | 1",
        "5   | 5",
        "10  | 10",
        "10+ | 10",
        "10- | 10",
        "' 5+ ' | 5"
    })
    @DisplayName("parse strips the trailing sign and surrounding spaces")
    void parsesValidRatings(String raw, int expected) {
        assertThat(CounterpartyRating.parse(raw).value()).isEqualTo(expected);
    }

    @ParameterizedTest(name = "\"{0}\" is rejected")
    @NullAndEmptySource
    @ValueSource(strings = {"   ", "\t"})
    void rejectsNullOrBlank(String raw) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> CounterpartyRating.parse(raw))
            .withMessage("Rating must not be null or blank");
    }

    @ParameterizedTest(name = "\"{0}\" has an invalid format")
    @ValueSource(strings = {"+5", "-5", "5++", "5+-", "5 +", "A", "5A", "100", "1.5", "five"})
    void rejectsInvalidFormat(String raw) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> CounterpartyRating.parse(raw))
            .withMessageContaining("Invalid rating '" + raw + "'");
    }

    @ParameterizedTest(name = "\"{0}\" is out of range")
    @ValueSource(strings = {"0", "0+", "11", "11-", "99"})
    void rejectsOutOfRangeAfterParsing(String raw) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> CounterpartyRating.parse(raw))
            .withMessageStartingWith("Rating must be 1..10");
    }

    @ParameterizedTest(name = "constructor rejects {0}")
    @ValueSource(ints = {Integer.MIN_VALUE, -1, 0, 11, Integer.MAX_VALUE})
    void constructorRejectsOutOfRange(int value) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new CounterpartyRating(value))
            .withMessage("Rating must be 1..10: " + value);
    }

    @Test
    @DisplayName("index is zero based: rating 1 is index 0, rating 10 is index 9")
    void indexIsZeroBased() {
        assertThat(new CounterpartyRating(1).index()).isZero();
        assertThat(new CounterpartyRating(10).index()).isEqualTo(9);
    }

    @Test
    @DisplayName("ratings that differ only by sign are equal")
    void signsAreDropped() {
        assertThat(CounterpartyRating.parse("4+")).isEqualTo(CounterpartyRating.parse("4-"));
    }
}
