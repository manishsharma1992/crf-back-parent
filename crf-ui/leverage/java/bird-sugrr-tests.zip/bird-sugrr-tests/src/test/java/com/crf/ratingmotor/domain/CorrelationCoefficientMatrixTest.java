package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

import java.util.Map;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class CorrelationCoefficientMatrixTest {

    private static final CounterpartyRating ONE = new CounterpartyRating(1);
    private static final CounterpartyRating THREE = new CounterpartyRating(3);
    private static final CounterpartyRating FIVE = new CounterpartyRating(5);
    private static final CounterpartyRating TEN = new CounterpartyRating(10);

    @Nested
    @DisplayName("lookup")
    class Lookup {

        private final CorrelationCoefficientMatrix matrix = TestMatrices.asymmetric(Correlation.LOW);

        @Test
        @DisplayName("guarantor rating selects the row and obligor rating selects the column")
        void axisOrientation() {
            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, THREE, FIVE), "0.0305");
            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, FIVE, THREE), "0.0503");
        }

        @Test
        @DisplayName("each security type has its own grid")
        void securityTypeSelectsGrid() {
            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, THREE, FIVE), "0.0305");
            assertExactly(matrix.coefficientFor(SecurityType.CREDIT_INSURER, THREE, FIVE), "1.0305");
            assertExactly(matrix.coefficientFor(SecurityType.COLLATERAL, THREE, FIVE), "2.0305");
        }

        @Test
        @DisplayName("first and last cells are reachable")
        void corners() {
            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, ONE, ONE), "0.0101");
            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, TEN, TEN), "0.1010");
            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, ONE, TEN), "0.0110");
            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, TEN, ONE), "0.1001");
        }

        @ParameterizedTest
        @EnumSource(Correlation.class)
        void exposesItsCorrelation(Correlation correlation) {
            assertThat(TestMatrices.asymmetric(correlation).correlation()).isEqualTo(correlation);
        }
    }

    @Nested
    @DisplayName("validation")
    class Validation {

        @Test
        void rejectsNullCorrelation() {
            Map<SecurityType, RoundedValue[][]> grids = TestMatrices.asymmetricGrids();
            assertThatNullPointerException()
                .isThrownBy(() -> new CorrelationCoefficientMatrix(null, grids))
                .withMessage("correlation");
        }

        @Test
        void rejectsNullGrids() {
            assertThatNullPointerException()
                .isThrownBy(() -> new CorrelationCoefficientMatrix(Correlation.LOW, null))
                .withMessage("grids");
        }

        @ParameterizedTest
        @EnumSource(SecurityType.class)
        void rejectsMissingSecurityType(SecurityType missing) {
            Map<SecurityType, RoundedValue[][]> grids = TestMatrices.asymmetricGrids();
            grids.remove(missing);
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new CorrelationCoefficientMatrix(Correlation.LOW, grids))
                .withMessage("Missing matrix for security type " + missing);
        }

        @Test
        void rejectsWrongRowCount() {
            Map<SecurityType, RoundedValue[][]> grids = TestMatrices.asymmetricGrids();
            grids.put(SecurityType.COLLATERAL, new RoundedValue[9][10]);
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new CorrelationCoefficientMatrix(Correlation.LOW, grids))
                .withMessage("COLLATERAL: expected 10 rows but got 9");
        }

        @Test
        void rejectsNullRow() {
            Map<SecurityType, RoundedValue[][]> grids = TestMatrices.asymmetricGrids();
            grids.get(SecurityType.GUARANTEE)[2] = null;
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new CorrelationCoefficientMatrix(Correlation.LOW, grids))
                .withMessage("GUARANTEE: row 3 must have 10 columns");
        }

        @Test
        void rejectsWrongColumnCount() {
            Map<SecurityType, RoundedValue[][]> grids = TestMatrices.asymmetricGrids();
            grids.get(SecurityType.CREDIT_INSURER)[9] = new RoundedValue[11];
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new CorrelationCoefficientMatrix(Correlation.LOW, grids))
                .withMessage("CREDIT_INSURER: row 10 must have 10 columns");
        }

        @Test
        @DisplayName("a missing cell is reported with its guarantor and obligor ratings")
        void rejectsNullCell() {
            Map<SecurityType, RoundedValue[][]> grids = TestMatrices.asymmetricGrids();
            grids.get(SecurityType.GUARANTEE)[3][6] = null;
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new CorrelationCoefficientMatrix(Correlation.LOW, grids))
                .withMessage("GUARANTEE: missing coefficient at guarantor=4, obligor=7");
        }
    }

    @Nested
    @DisplayName("immutability")
    class Immutability {

        @Test
        @DisplayName("changing a cell of the source array after construction does not change the matrix")
        void cellChangeDoesNotLeak() {
            Map<SecurityType, RoundedValue[][]> grids = TestMatrices.asymmetricGrids();
            CorrelationCoefficientMatrix matrix = new CorrelationCoefficientMatrix(Correlation.LOW, grids);

            grids.get(SecurityType.GUARANTEE)[2][4] = RoundedValue.of("99");

            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, THREE, FIVE), "0.0305");
        }

        @Test
        @DisplayName("replacing a row or a grid in the source after construction does not change the matrix")
        void rowAndGridChangeDoesNotLeak() {
            Map<SecurityType, RoundedValue[][]> grids = TestMatrices.asymmetricGrids();
            CorrelationCoefficientMatrix matrix = new CorrelationCoefficientMatrix(Correlation.LOW, grids);

            grids.get(SecurityType.GUARANTEE)[2] = TestMatrices.uniformGrids("99").get(SecurityType.GUARANTEE)[0];
            grids.put(SecurityType.COLLATERAL, TestMatrices.uniformGrids("99").get(SecurityType.COLLATERAL));

            assertExactly(matrix.coefficientFor(SecurityType.GUARANTEE, THREE, FIVE), "0.0305");
            assertExactly(matrix.coefficientFor(SecurityType.COLLATERAL, THREE, FIVE), "2.0305");
        }
    }
}
