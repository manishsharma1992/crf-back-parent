package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;

class CorrelationCoefficientDriverTest {

    @ParameterizedTest(name = "{0}, {1}, guarantor {2}, obligor {3} -> {4}")
    @CsvSource({
        "LOW,  GUARANTEE,      3+, 5-, 0.0305",
        "LOW,  GUARANTEE,      5,  3,  0.0503",
        "HIGH, CREDIT_INSURER, 1-, 10, 1.0110",
        "HIGH, COLLATERAL,     10, 1+, 2.1001"
    })
    @DisplayName("estimate value is the matrix cell for the security type and the two ratings")
    void picksTheMatrixCell(Correlation correlation, SecurityType type,
                            String guarantor, String obligor, String expected) {
        CorrelationCoefficientDriver driver = new CorrelationCoefficientDriver(
            TestMatrices.asymmetric(correlation), type,
            CounterpartyRating.parse(guarantor), CounterpartyRating.parse(obligor));

        assertExactly(driver.getEstimateValue(), expected);
    }

    @Test
    @DisplayName("keeps its inputs for the audit trail")
    void exposesInputs() {
        CorrelationCoefficientDriver driver = new CorrelationCoefficientDriver(
            TestMatrices.asymmetric(Correlation.HIGH), SecurityType.GUARANTEE,
            new CounterpartyRating(3), new CounterpartyRating(5));

        assertThat(driver.getName()).isEqualTo("CORRELATION_COEFFICIENT").isEqualTo(CorrelationCoefficientDriver.NAME);
        assertThat(driver.correlation()).isEqualTo(Correlation.HIGH);
        assertThat(driver.securityType()).isEqualTo(SecurityType.GUARANTEE);
        assertThat(driver.guarantorRating()).isEqualTo(new CounterpartyRating(3));
        assertThat(driver.obligorRating()).isEqualTo(new CounterpartyRating(5));
    }
}
