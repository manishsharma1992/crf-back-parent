package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static com.crf.ratingmotor.domain.MaturityScenarios.assess;
import static com.crf.ratingmotor.domain.MaturityScenarios.dates;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/**
 * Calculations 1 to 4 of the maturity mismatch. Offsets are days from "today" (2026-01-01) under
 * ACT/365 Fixed, so 730 days is exactly 2 years. Argument order of assess(...):
 * guarantee implementation, guarantee maturity, facility implementation, facility maturity.
 */
class MaturityAssessmentTest {

    @Nested
    @DisplayName("Calculation 1: residual maturity of the facility")
    class ResidualFacility {

        @Test
        @DisplayName("counts from today when the facility has already started")
        void fromToday() {
            assertExactly(assess(-365, 2000, -365, 730).residualFacility(), "2");
        }

        @Test
        @DisplayName("counts from the facility implementation date when it is in the future")
        void fromFacilityImplementation() {
            assertExactly(assess(-365, 2000, 365, 1095).residualFacility(), "2");
        }
    }

    @Nested
    @DisplayName("Calculation 2: residual maturity of the guarantee")
    class ResidualGuarantee {

        @Test
        @DisplayName("counts from today when today is the latest of the three dates")
        void fromToday() {
            assertExactly(assess(-365, 730, -730, 2000).residualGuarantee(), "2");
        }

        @Test
        @DisplayName("counts from the guarantee implementation date when it is the latest")
        void fromGuaranteeImplementation() {
            assertExactly(assess(365, 1095, -365, 2000).residualGuarantee(), "2");
        }

        @Test
        @DisplayName("counts from the facility implementation date when it is the latest")
        void fromFacilityImplementation() {
            assertExactly(assess(-365, 1095, 365, 2000).residualGuarantee(), "2");
        }
    }

    @Nested
    @DisplayName("Calculation 3: initial maturity of the guarantee")
    class InitialGuarantee {

        @Test
        @DisplayName("counts from the guarantee implementation date when it is the later one, ignoring today")
        void fromGuaranteeImplementation() {
            assertExactly(assess(-365, 730, -730, 2000).initialGuarantee(), "3");
        }

        @Test
        @DisplayName("counts from the facility implementation date when it is the later one, ignoring today")
        void fromFacilityImplementation() {
            assertExactly(assess(-730, 730, -365, 2000).initialGuarantee(), "3");
        }
    }

    @Nested
    @DisplayName("Calculation 4: maturity mismatch indicator")
    class Indicator {

        @Test
        @DisplayName("0 when the guarantee outlives the facility")
        void guaranteeOutlivesFacility() {
            MaturityAssessment a = assess(-365, 1460, -365, 730);
            assertThat(a.indicator()).isEqualTo(MaturityMismatchIndicator.NO_MISMATCH);
            assertThat(a.guaranteeNotYetStarted()).isFalse();
        }

        @Test
        @DisplayName("0 when both mature on the same day")
        void sameMaturity() {
            assertThat(assess(-365, 730, -365, 730).indicator()).isEqualTo(MaturityMismatchIndicator.NO_MISMATCH);
        }

        @Test
        @DisplayName("1 when the guarantee matures one day before the facility")
        void oneDayShort() {
            assertThat(assess(-365, 729, -365, 730).indicator()).isEqualTo(MaturityMismatchIndicator.MISMATCH);
        }

        @Test
        @DisplayName("0 when the guarantee starts after the facility and has not started yet, even if it is shorter")
        void guaranteeNotYetStarted() {
            MaturityAssessment a = assess(100, 400, -365, 1460);
            assertThat(a.residualGuarantee().isLessThan(a.residualFacility())).isTrue();
            assertThat(a.guaranteeNotYetStarted()).isTrue();
            assertThat(a.indicator()).isEqualTo(MaturityMismatchIndicator.NO_MISMATCH);
        }

        @Test
        @DisplayName("1 when the guarantee started after the facility but has already started")
        void guaranteeStartedAfterFacilityButAlreadyRunning() {
            MaturityAssessment a = assess(-100, 400, -365, 1460);
            assertThat(a.guaranteeNotYetStarted()).isFalse();
            assertThat(a.indicator()).isEqualTo(MaturityMismatchIndicator.MISMATCH);
        }

        @Test
        @DisplayName("1 when the guarantee starts today: starting today counts as started")
        void guaranteeStartsToday() {
            MaturityAssessment a = assess(0, 400, -365, 1460);
            assertThat(a.guaranteeNotYetStarted()).isFalse();
            assertThat(a.indicator()).isEqualTo(MaturityMismatchIndicator.MISMATCH);
        }

        @Test
        @DisplayName("1 when the guarantee is in the future but starts on the same day as the facility")
        void futureGuaranteeStartingWithFacility() {
            MaturityAssessment a = assess(100, 400, 100, 1460);
            assertThat(a.guaranteeNotYetStarted()).isFalse();
            assertThat(a.indicator()).isEqualTo(MaturityMismatchIndicator.MISMATCH);
        }

        @Test
        @DisplayName("indicator values are 0 and 1 as in the specification")
        void indicatorValues() {
            assertThat(MaturityMismatchIndicator.NO_MISMATCH.getValue()).isZero();
            assertThat(MaturityMismatchIndicator.MISMATCH.getValue()).isEqualTo(1);
        }
    }

    @Test
    @DisplayName("the day-count convention changes the result when a leap year is involved")
    void conventionIsApplied() {
        MaturityDates leapYearDates = new MaturityDates(
            LocalDate.of(2028, 1, 1),
            LocalDate.of(2027, 1, 1), LocalDate.of(2029, 1, 1),
            LocalDate.of(2027, 1, 1), LocalDate.of(2029, 1, 1));

        assertExactly(MaturityAssessment.of(leapYearDates, DayCountConvention.ACT_ACT_ISDA).residualFacility(), "1");
        assertThat(MaturityAssessment.of(leapYearDates, DayCountConvention.ACT_365_FIXED).residualFacility()
            .isGreaterThan(MaturityAssessment.of(leapYearDates, DayCountConvention.ACT_ACT_ISDA).residualFacility()))
            .isTrue();
    }

    @Test
    void rejectsNullDates() {
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityAssessment.of(null, DayCountConvention.ACT_365_FIXED))
            .withMessage("dates");
    }

    @Test
    void rejectsNullConvention() {
        MaturityDates d = dates(-365, 730, -365, 730);
        assertThatNullPointerException()
            .isThrownBy(() -> MaturityAssessment.of(d, null))
            .withMessage("convention");
    }
}
