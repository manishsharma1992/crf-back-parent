package com.crf.ratingmotor.application;

import com.crf.ratingmotor.domain.Correlation;
import com.crf.ratingmotor.domain.CorrelationCoefficientDriver;
import com.crf.ratingmotor.domain.CorrelationCoefficientMatrix;
import com.crf.ratingmotor.domain.CorrelationCoefficientMatrixRepository;
import com.crf.ratingmotor.domain.CounterpartyRating;
import com.crf.ratingmotor.domain.CurrencyCode;
import com.crf.ratingmotor.domain.DayCountConvention;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.Driver;
import com.crf.ratingmotor.domain.ExpectedRecovery;
import com.crf.ratingmotor.domain.ExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.MissingExchangeRateException;
import com.crf.ratingmotor.domain.SecurityType;
import com.crf.ratingmotor.domain.TestMatrices;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

import static com.crf.ratingmotor.application.BirdSugrrComputeQueryBuilder.query;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/**
 * Unit test of the application service with the real domain service and a fake repository: no Spring
 * context, no database. LOW returns a matrix where every cell is 0.8, HIGH one where every cell is 0.3.
 */
class GuaranteeRecoveryComputeManagementServiceTest {

    /** Returns a uniform matrix per correlation and records what was asked for. */
    private static final class FakeRepository implements CorrelationCoefficientMatrixRepository {
        final List<Correlation> requested = new ArrayList<>();
        CorrelationCoefficientMatrix override;

        @Override
        public CorrelationCoefficientMatrix findBy(Correlation correlation) {
            requested.add(correlation);
            if (override != null) {
                return override;
            }
            return TestMatrices.uniform(correlation, correlation == Correlation.LOW ? "0.8" : "0.3");
        }
    }

    private FakeRepository repository;
    private GuaranteeRecoveryComputeManagementService service;

    @BeforeEach
    void setUp() {
        repository = new FakeRepository();
        service = new GuaranteeRecoveryComputeManagementService(
            repository, DayCountConvention.ACT_365_FIXED, new ExpectedRecoveryCalculatorDomainService());
    }

    @Nested
    @DisplayName("end-to-end through the domain")
    class HappyPath {

        @Test
        @DisplayName("same currency worked example: RecupE = 3,600,000")
        void sameCurrency() {
            BirdSugrrComputeResult result = service.compute(query().build());
            ExpectedRecovery r = result.recovery();

            assertExactly(r.expectedRecovery(), "3600000");
            assertExactly(r.recoveryRatePercent(), "36");
            assertExactly(r.recoveryInGuaranteeCurrency(), "3600000");
            assertExactly(r.recoveryInFacilityCurrency(), "3600000");
            assertThat(r.guaranteeCurrency()).isEqualTo(new CurrencyCode("EUR"));
            assertThat(r.facilityCurrency()).isEqualTo(new CurrencyCode("EUR"));
        }

        @Test
        @DisplayName("currency mismatch, HIGH correlation (0.3): RecupE = 177,390 USD, RecupE_F = 354,780 EUR")
        void currencyMismatch() {
            BirdSugrrComputeResult result = service.compute(query().usdGuaranteeOnEurFacility()
                .guaranteeAmount("1").proposedDiscountRate("0").allocationRate("100")
                .borrowerOrGuarantorCorrelation("HIGH").build());

            // 1,000,000 x 0.5 x 2 x (1 - 0.4087) x 0.3 x 1 = 177,390
            assertExactly(result.recovery().expectedRecovery(), "177390");
            assertExactly(result.recovery().recoveryRatePercent(), "17.739");
            assertExactly(result.recovery().recoveryInFacilityCurrency(), "354780");
        }

        @Test
        @DisplayName("returns the five drivers in order with their values")
        void returnsDrivers() {
            List<Driver> drivers = service.compute(query().build()).drivers();

            assertThat(drivers).extracting(Driver::getName).containsExactly(
                "CORRELATION_COEFFICIENT", "DISCOUNT_MATURITY_MISMATCH", "DISCOUNT_CURRENCY_MISMATCH",
                "PROPOSED_DISCOUNT_RATE", "ALLOCATION_RATE");
            assertExactly(drivers.get(0).getEstimateValue(), "0.8");
            assertExactly(drivers.get(1).getEstimateValue(), "0");
            assertExactly(drivers.get(2).getEstimateValue(), "0");
            assertExactly(drivers.get(3).getEstimateValue(), "0.1");
            assertExactly(drivers.get(4).getEstimateValue(), "0.5");
        }

        @Test
        @DisplayName("same currency with both flags true and no currencyMismatch value is valid")
        void sameCurrencyWithoutNomenclatureValue() {
            BirdSugrrComputeResult result = service.compute(query()
                .guaranteeCurrencyExistingFlag(true).facilityCurrencyExistingFlag(true).currencyMismatch(null).build());

            assertExactly(result.recovery().expectedRecovery(), "3600000");
        }

        @Test
        @DisplayName("currency mismatch covered by the nomenclature uses currencyMismatch")
        void nomenclatureValueUsed() {
            BirdSugrrComputeResult result = service.compute(query().usdGuaranteeOnEurFacility()
                .guaranteeCurrencyExistingFlag(true).facilityCurrencyExistingFlag(true).currencyMismatch("0.085").build());

            assertExactly(result.drivers().get(2).getEstimateValue(), "0.085");
        }
    }

    @Nested
    @DisplayName("mapping the query into the domain")
    class Mapping {

        @ParameterizedTest(name = "correlation \"{0}\" -> {1}")
        @MethodSource("com.crf.ratingmotor.application.GuaranteeRecoveryComputeManagementServiceTest#correlations")
        @DisplayName("correlation is parsed case-insensitively and trimmed, then looked up")
        void correlationParsing(String raw, Correlation expected) {
            service.compute(query().borrowerOrGuarantorCorrelation(raw).build());

            assertThat(repository.requested).containsExactly(expected);
        }

        @Test
        @DisplayName("the GUARANTEE grid is used, with signs stripped from both ratings")
        void securityTypeAndRatings() {
            repository.override = TestMatrices.asymmetric(Correlation.LOW);

            CorrelationCoefficientDriver driver = (CorrelationCoefficientDriver)
                service.compute(query().guarantorCounterpartyRating("3+").obligorCounterpartyRating("5-").build())
                    .drivers().get(0);

            assertThat(driver.securityType()).isEqualTo(SecurityType.GUARANTEE);
            assertThat(driver.guarantorRating()).isEqualTo(new CounterpartyRating(3));
            assertThat(driver.obligorRating()).isEqualTo(new CounterpartyRating(5));
            assertExactly(driver.getEstimateValue(), "0.0305");
        }

        @Test
        @DisplayName("the injected day-count convention is used for the maturity calculations")
        void dayCountConventionIsUsed() {
            BirdSugrrComputeQuery leapYear = query()
                .currentDate(LocalDate.of(2028, 1, 1))
                .facilityImplementationDate(LocalDate.of(2027, 1, 1)).facilityMaturityDate(LocalDate.of(2029, 1, 1))
                .guaranteeImplementationDate(LocalDate.of(2027, 1, 1)).guaranteeMaturityDate(LocalDate.of(2030, 1, 1))
                .build();
            GuaranteeRecoveryComputeManagementService actAct = new GuaranteeRecoveryComputeManagementService(
                repository, DayCountConvention.ACT_ACT_ISDA, new ExpectedRecoveryCalculatorDomainService());

            DiscountMaturityMismatchDriver act365 = (DiscountMaturityMismatchDriver) service.compute(leapYear).drivers().get(1);
            DiscountMaturityMismatchDriver actActDriver = (DiscountMaturityMismatchDriver) actAct.compute(leapYear).drivers().get(1);

            assertExactly(actActDriver.assessment().residualFacility(), "1");
            assertThat(act365.assessment().residualFacility().isGreaterThan(actActDriver.assessment().residualFacility()))
                .isTrue();
        }

        @Test
        @DisplayName("FX rates are optional when the currencies are the same")
        void ratesOptionalForSameCurrency() {
            BirdSugrrComputeQuery noRates = query().facilityToGuaranteeCurrencyRate(null).guaranteeToFacilityCurrencyRate(null).build();
            assertExactly(service.compute(noRates).recovery().expectedRecovery(), "3600000");
        }
    }

    static Stream<Arguments> correlations() {
        return Stream.of(
            Arguments.of("LOW", Correlation.LOW),
            Arguments.of("low", Correlation.LOW),
            Arguments.of(" High ", Correlation.HIGH),
            Arguments.of("HIGH", Correlation.HIGH));
    }

    @Nested
    @DisplayName("invalid input is rejected as a client error (IllegalArgumentException)")
    class InvalidInput {

        @ParameterizedTest(name = "correlation \"{0}\"")
        @ValueSource(strings = {"", "  "})
        void blankCorrelation(String raw) {
            BirdSugrrComputeQuery q = query().borrowerOrGuarantorCorrelation(raw).build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q))
                .withMessage("borrowerOrGuarantorCorrelation must not be null or blank");
        }

        @Test
        void nullCorrelation() {
            BirdSugrrComputeQuery q = query().borrowerOrGuarantorCorrelation(null).build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q))
                .withMessage("borrowerOrGuarantorCorrelation must not be null or blank");
        }

        @Test
        void unknownCorrelation() {
            BirdSugrrComputeQuery q = query().borrowerOrGuarantorCorrelation("MEDIUM").build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q))
                .withMessage("Invalid borrowerOrGuarantorCorrelation: MEDIUM")
                .withCauseInstanceOf(IllegalArgumentException.class);
            assertThat(repository.requested).isEmpty();
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("com.crf.ratingmotor.application.GuaranteeRecoveryComputeManagementServiceTest#missingRequiredFields")
        void missingRequiredField(String field, UnaryOperator<BirdSugrrComputeQueryBuilder> blank) {
            BirdSugrrComputeQuery q = blank.apply(query()).build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q))
                .withMessage(field + " must not be null");
        }

        @Test
        void unknownUnit() {
            BirdSugrrComputeQuery q = query().guaranteeUnit("HUNDRED").build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q)).withMessage("Unknown Unit: HUNDRED");
        }

        @Test
        void invalidRating() {
            BirdSugrrComputeQuery q = query().obligorCounterpartyRating("11").build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q)).withMessageStartingWith("Rating must be 1..10");
        }

        @Test
        void invalidCurrency() {
            BirdSugrrComputeQuery q = query().guaranteeCurrency("EURO").build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q))
                .withMessageStartingWith("Currency must be a 3-letter code");
        }

        @Test
        void percentageOutOfRange() {
            BirdSugrrComputeQuery q = query().allocationRate("120").build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q))
                .withMessageStartingWith("ALLOCATION_RATE must be between 0 and 100");
        }

        @Test
        void missingRateOnCurrencyMismatch() {
            BirdSugrrComputeQuery q = query().usdGuaranteeOnEurFacility().guaranteeToFacilityCurrencyRate(null).build();
            assertThatExceptionOfType(MissingExchangeRateException.class).isThrownBy(() -> service.compute(q));
        }

        @Test
        void zeroGuaranteeAmount() {
            BirdSugrrComputeQuery q = query().guaranteeAmount("0").build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(q))
                .withMessage("Guarantee amount must be greater than zero");
        }
    }

    static Stream<Arguments> missingRequiredFields() {
        return Stream.of(
            Arguments.of("proposedDiscountRate", (UnaryOperator<BirdSugrrComputeQueryBuilder>) b -> b.proposedDiscountRate(null)),
            Arguments.of("allocationRate", (UnaryOperator<BirdSugrrComputeQueryBuilder>) b -> b.allocationRate(null)),
            Arguments.of("guaranteeAmount", (UnaryOperator<BirdSugrrComputeQueryBuilder>) b -> b.guaranteeAmount(null)),
            Arguments.of("guaranteeCurrencyExistingFlag", (UnaryOperator<BirdSugrrComputeQueryBuilder>) b -> b.guaranteeCurrencyExistingFlag(null)),
            Arguments.of("facilityCurrencyExistingFlag", (UnaryOperator<BirdSugrrComputeQueryBuilder>) b -> b.facilityCurrencyExistingFlag(null)));
    }

    @Test
    void rejectsNullQuery() {
        assertThatNullPointerException().isThrownBy(() -> service.compute(null)).withMessage("query");
    }

    @Test
    @DisplayName("a missing date is a NullPointerException here; the API rejects it earlier with @NotNull")
    void missingDate() {
        BirdSugrrComputeQuery q = query().currentDate(null).build();
        assertThatNullPointerException().isThrownBy(() -> service.compute(q)).withMessage("currentDate");
    }
}
