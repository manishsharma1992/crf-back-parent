package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.BirdSugrrComputeResult;
import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.ExpectedRecovery;
import com.crf.ratingmotor.domain.ExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.ExchangeRates;
import com.crf.ratingmotor.domain.MaturityScenarios;
import com.crf.ratingmotor.domain.RecoveryFactors;
import com.crf.ratingmotor.domain.UnitAmount;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static com.crf.ratingmotor.domain.RecoveryFactorsBuilder.factors;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThat;

/** Rounding happens only here: amounts to 2 decimals, rates and driver values to 6, HALF_UP. */
class ExpectedRecoveryResponseTest {

    private static BirdSugrrComputeResult compute(UnitAmount guarantee, ExchangeRates rates, RecoveryFactors factors) {
        ExpectedRecovery recovery = new ExpectedRecoveryCalculatorDomainService().calculate(guarantee, rates, factors);
        return new BirdSugrrComputeResult(recovery, factors.asList());
    }

    @Test
    @DisplayName("amounts carry their currency and are rounded to 2 decimals")
    void amountsAndCurrencies() {
        ExpectedRecoveryResponse response = ExpectedRecoveryResponse.from(compute(
            new UnitAmount(rv("1"), Unit.MILLION), new ExchangeRates(rv("0.5"), rv("2")),
            factors().currencies("USD", "EUR").build()));

        assertThat(response.expectedRecovery())
            .isEqualTo(new ExpectedRecoveryResponse.AmountWithCurrency(new BigDecimal("591300.00"), "USD"));
        assertThat(response.recoveryInGuaranteeCurrency())
            .isEqualTo(new ExpectedRecoveryResponse.AmountWithCurrency(new BigDecimal("591300.00"), "USD"));
        assertThat(response.recoveryInFacilityCurrency())
            .isEqualTo(new ExpectedRecoveryResponse.AmountWithCurrency(new BigDecimal("1182600.00"), "EUR"));
        assertThat(response.recoveryRatePercent()).isEqualTo(new BigDecimal("59.130000"));
    }

    @Test
    @DisplayName("recurring decimals are rounded HALF_UP: 466.666... -> 466.67 and 46.666... -> 46.666667")
    void roundingHalfUp() {
        ExpectedRecoveryResponse response = ExpectedRecoveryResponse.from(compute(
            new UnitAmount(rv("1000"), Unit.UNIT), new ExchangeRates(null, null),
            factors().maturity(MaturityScenarios.partialMismatch()).build()));

        assertThat(response.expectedRecovery().amount()).isEqualTo(new BigDecimal("466.67"));
        assertThat(response.recoveryRatePercent()).isEqualTo(new BigDecimal("46.666667"));
    }

    @Test
    @DisplayName("drivers keep their order, names, and fractions rounded to 6 decimals")
    void drivers() {
        ExpectedRecoveryResponse response = ExpectedRecoveryResponse.from(compute(
            new UnitAmount(rv("1000"), Unit.UNIT), new ExchangeRates(null, null),
            factors().maturity(MaturityScenarios.partialMismatch()).correlationCoefficient("0.0305")
                .proposedDiscountPercent("10").allocationPercent("50").build()));

        assertThat(response.drivers()).containsExactly(
            new ExpectedRecoveryResponse.DriverValue("CORRELATION_COEFFICIENT", new BigDecimal("0.030500")),
            new ExpectedRecoveryResponse.DriverValue("DISCOUNT_MATURITY_MISMATCH", new BigDecimal("0.533333")),
            new ExpectedRecoveryResponse.DriverValue("DISCOUNT_CURRENCY_MISMATCH", new BigDecimal("0.000000")),
            new ExpectedRecoveryResponse.DriverValue("PROPOSED_DISCOUNT_RATE", new BigDecimal("0.100000")),
            new ExpectedRecoveryResponse.DriverValue("ALLOCATION_RATE", new BigDecimal("0.500000")));
    }
}
