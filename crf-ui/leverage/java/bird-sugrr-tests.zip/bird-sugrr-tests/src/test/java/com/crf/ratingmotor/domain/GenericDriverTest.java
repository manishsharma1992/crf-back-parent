package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

class GenericDriverTest {

    private static final class TestDriver extends GenericDriver {
        TestDriver(String name) {
            super(name);
        }
    }

    @ParameterizedTest(name = "name \"{0}\" is rejected")
    @NullAndEmptySource
    @ValueSource(strings = {" ", "\t\n"})
    void rejectsNullOrBlankName(String name) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new TestDriver(name))
            .withMessage("Driver name must not be null or blank");
    }

    @Test
    void keepsItsName() {
        assertThat(new TestDriver("SOME_DRIVER").getName()).isEqualTo("SOME_DRIVER");
    }

    @Test
    void estimateValueIsUnsetUntilASubclassAssignsIt() {
        assertThat(new TestDriver("SOME_DRIVER").getEstimateValue()).isNull();
    }
}
