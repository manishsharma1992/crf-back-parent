package com.crf.ratingmotor.application;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Test builder for BirdSugrrComputeQuery. The defaults are the same-currency worked example:
 * 10 MILLION EUR guarantee on an EUR facility, no maturity mismatch, proposed discount 10%,
 * allocation 50%, correlation LOW, ratings 3+ / 5-. With a correlation coefficient of 0.8 this gives
 * RecupE = 3,600,000.
 */
public final class BirdSugrrComputeQueryBuilder {

    private LocalDate currentDate = LocalDate.of(2026, 11, 10);
    private LocalDate guaranteeImplementationDate = LocalDate.of(2025, 1, 1);
    private LocalDate guaranteeMaturityDate = LocalDate.of(2031, 1, 1);
    private String guarantorCounterpartyRating = "3+";
    private String borrowerOrGuarantorCorrelation = "LOW";
    private String nonEnforceabilityRisk = "LOW";
    private BigDecimal proposedDiscountRate = new BigDecimal("10");
    private BigDecimal guaranteeAmount = new BigDecimal("10");
    private String guaranteeUnit = "MILLION";
    private String guaranteeCurrency = "EUR";
    private BigDecimal allocationRate = new BigDecimal("50");
    private LocalDate facilityImplementationDate = LocalDate.of(2025, 1, 1);
    private LocalDate facilityMaturityDate = LocalDate.of(2030, 1, 1);
    private BigDecimal facilityAmount = new BigDecimal("20");
    private String facilityUnit = "MILLION";
    private String facilityCurrency = "EUR";
    private String obligorCounterpartyRating = "5-";
    private BigDecimal facilityToGuaranteeCurrencyRate = null;
    private BigDecimal guaranteeToFacilityCurrencyRate = null;
    private Boolean guaranteeCurrencyExistingFlag = true;
    private Boolean facilityCurrencyExistingFlag = true;
    private BigDecimal currencyMismatch = null;

    public static BirdSugrrComputeQueryBuilder query() {
        return new BirdSugrrComputeQueryBuilder();
    }

    public BirdSugrrComputeQueryBuilder currentDate(LocalDate v) { currentDate = v; return this; }
    public BirdSugrrComputeQueryBuilder guaranteeImplementationDate(LocalDate v) { guaranteeImplementationDate = v; return this; }
    public BirdSugrrComputeQueryBuilder guaranteeMaturityDate(LocalDate v) { guaranteeMaturityDate = v; return this; }
    public BirdSugrrComputeQueryBuilder guarantorCounterpartyRating(String v) { guarantorCounterpartyRating = v; return this; }
    public BirdSugrrComputeQueryBuilder borrowerOrGuarantorCorrelation(String v) { borrowerOrGuarantorCorrelation = v; return this; }
    public BirdSugrrComputeQueryBuilder proposedDiscountRate(String v) { proposedDiscountRate = decimal(v); return this; }
    public BirdSugrrComputeQueryBuilder guaranteeAmount(String v) { guaranteeAmount = decimal(v); return this; }
    public BirdSugrrComputeQueryBuilder guaranteeUnit(String v) { guaranteeUnit = v; return this; }
    public BirdSugrrComputeQueryBuilder guaranteeCurrency(String v) { guaranteeCurrency = v; return this; }
    public BirdSugrrComputeQueryBuilder allocationRate(String v) { allocationRate = decimal(v); return this; }
    public BirdSugrrComputeQueryBuilder facilityImplementationDate(LocalDate v) { facilityImplementationDate = v; return this; }
    public BirdSugrrComputeQueryBuilder facilityMaturityDate(LocalDate v) { facilityMaturityDate = v; return this; }
    public BirdSugrrComputeQueryBuilder facilityCurrency(String v) { facilityCurrency = v; return this; }
    public BirdSugrrComputeQueryBuilder obligorCounterpartyRating(String v) { obligorCounterpartyRating = v; return this; }
    public BirdSugrrComputeQueryBuilder facilityToGuaranteeCurrencyRate(String v) { facilityToGuaranteeCurrencyRate = decimal(v); return this; }
    public BirdSugrrComputeQueryBuilder guaranteeToFacilityCurrencyRate(String v) { guaranteeToFacilityCurrencyRate = decimal(v); return this; }
    public BirdSugrrComputeQueryBuilder guaranteeCurrencyExistingFlag(Boolean v) { guaranteeCurrencyExistingFlag = v; return this; }
    public BirdSugrrComputeQueryBuilder facilityCurrencyExistingFlag(Boolean v) { facilityCurrencyExistingFlag = v; return this; }
    public BirdSugrrComputeQueryBuilder currencyMismatch(String v) { currencyMismatch = decimal(v); return this; }

    /** USD guarantee on an EUR facility, not in the nomenclature (40.87%), rates 0.5 and 2. */
    public BirdSugrrComputeQueryBuilder usdGuaranteeOnEurFacility() {
        return guaranteeCurrency("USD").facilityCurrency("EUR")
            .facilityToGuaranteeCurrencyRate("0.5").guaranteeToFacilityCurrencyRate("2")
            .guaranteeCurrencyExistingFlag(false).facilityCurrencyExistingFlag(false);
    }

    public BirdSugrrComputeQuery build() {
        return new BirdSugrrComputeQuery(currentDate, guaranteeImplementationDate, guaranteeMaturityDate,
            guarantorCounterpartyRating, borrowerOrGuarantorCorrelation, nonEnforceabilityRisk,
            proposedDiscountRate, guaranteeAmount, guaranteeUnit, guaranteeCurrency, allocationRate,
            facilityImplementationDate, facilityMaturityDate, facilityAmount, facilityUnit, facilityCurrency,
            obligorCounterpartyRating, facilityToGuaranteeCurrencyRate, guaranteeToFacilityCurrencyRate,
            guaranteeCurrencyExistingFlag, facilityCurrencyExistingFlag, currencyMismatch);
    }

    private static BigDecimal decimal(String v) {
        return v == null ? null : new BigDecimal(v);
    }
}
