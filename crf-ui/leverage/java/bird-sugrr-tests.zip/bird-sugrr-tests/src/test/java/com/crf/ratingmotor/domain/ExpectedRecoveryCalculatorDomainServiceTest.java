package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.Unit;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static com.crf.ratingmotor.domain.RecoveryFactorsBuilder.factors;
import static com.crf.ratingmotor.domain.TestValues.assertApproximately;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/**
 * Expected recovery: RecupE, RecupT, RecupE_G, RecupE_F. Every expected value below was worked out by hand
 * from the specification, independently of the production code.
 */
class ExpectedRecoveryCalculatorDomainServiceTest {

    private static final ExchangeRates NO_RATES = new ExchangeRates(null, null);

    private final ExpectedRecoveryCalculatorDomainService calculator = new ExpectedRecoveryCalculatorDomainService();

    private static UnitAmount amount(String value, Unit unit) {
        return new UnitAmount(rv(value), unit);
    }

    @Nested
    @DisplayName("same currency")
    class SameCurrency {

        @Test
        @DisplayName("10 MILLION, proposed discount 10%, correlation 0.8, allocation 50%")
        void workedExample() {
            // RecupE = 10,000,000 x (1 - 0) x (1 - 0) x (1 - 0.10) x 0.8 x 0.50 = 3,600,000
            ExpectedRecovery r = calculator.calculate(amount("10", Unit.MILLION), NO_RATES,
                factors().proposedDiscountPercent("10").correlationCoefficient("0.8").allocationPercent("50").build());

            assertExactly(r.expectedRecovery(), "3600000");
            assertExactly(r.recoveryRatePercent(), "36");
            assertExactly(r.recoveryInGuaranteeCurrency(), "3600000");
            assertExactly(r.recoveryInFacilityCurrency(), "3600000");
            assertThat(r.guaranteeCurrency()).isEqualTo(new CurrencyCode("EUR"));
            assertThat(r.facilityCurrency()).isEqualTo(new CurrencyCode("EUR"));
        }

        @Test
        @DisplayName("FX rates are ignored when the currencies are the same")
        void ratesIgnored() {
            ExpectedRecovery r = calculator.calculate(amount("1000", Unit.UNIT), new ExchangeRates(rv("3"), rv("7")),
                factors().build());

            assertExactly(r.expectedRecovery(), "1000");
            assertExactly(r.recoveryInFacilityCurrency(), "1000");
        }

        @Test
        @DisplayName("maturity discount is applied: t = 2, T = 4 gives Dmm = 0.5333...")
        void maturityDiscountApplied() {
            // RecupE = 1000 x (1 - 0.5333...) = 466.666...
            ExpectedRecovery r = calculator.calculate(amount("1000", Unit.UNIT), NO_RATES,
                factors().maturity(MaturityScenarios.partialMismatch()).build());

            assertApproximately(r.expectedRecovery(), "466.6666666666666666666666667");
            assertApproximately(r.recoveryRatePercent(), "46.66666666666666666666666667");
        }

        @Test
        @DisplayName("100% maturity discount gives zero recovery through the formula")
        void fullMaturityDiscount() {
            ExpectedRecovery r = calculator.calculate(amount("5", Unit.MILLION), NO_RATES,
                factors().maturity(MaturityScenarios.fullMismatch()).build());

            assertExactly(r.expectedRecovery(), "0");
            assertExactly(r.recoveryRatePercent(), "0");
            assertExactly(r.recoveryInFacilityCurrency(), "0");
        }

        @Test
        @DisplayName("0% allocation gives zero recovery")
        void zeroAllocation() {
            ExpectedRecovery r = calculator.calculate(amount("1", Unit.BILLION), NO_RATES,
                factors().allocationPercent("0").build());

            assertExactly(r.expectedRecovery(), "0");
            assertExactly(r.recoveryRatePercent(), "0");
        }
    }

    @Nested
    @DisplayName("currency mismatch")
    class CurrencyMismatch {

        @Test
        @DisplayName("USD guarantee, EUR facility, default 40.87% discount")
        void workedExampleWithDefaultDiscount() {
            // RecupE   = 1,000,000 x 0.5 x 2 x (1 - 0.4087) = 591,300
            // RecupT   = 591,300 / 1,000,000 x 100 = 59.13
            // RecupE_G = 1,000,000 x 59.13 / 100 = 591,300 (USD)
            // RecupE_F = 591,300 x 2 = 1,182,600 (EUR)
            ExpectedRecovery r = calculator.calculate(amount("1", Unit.MILLION), new ExchangeRates(rv("0.5"), rv("2")),
                factors().currencies("USD", "EUR").build());

            assertExactly(r.expectedRecovery(), "591300");
            assertExactly(r.recoveryRatePercent(), "59.13");
            assertExactly(r.recoveryInGuaranteeCurrency(), "591300");
            assertThat(r.guaranteeCurrency()).isEqualTo(new CurrencyCode("USD"));
            assertExactly(r.recoveryInFacilityCurrency(), "1182600");
            assertThat(r.facilityCurrency()).isEqualTo(new CurrencyCode("EUR"));
        }

        @Test
        @DisplayName("nomenclature discount 10% with near-inverse rates 0.9 and 1.1")
        void nomenclatureDiscount() {
            // RecupE = 1000 x 0.9 x 1.1 x (1 - 0.10) = 891;  RecupT = 89.1;  RecupE_F = 891 x 1.1 = 980.1
            ExpectedRecovery r = calculator.calculate(amount("1000", Unit.UNIT), new ExchangeRates(rv("0.9"), rv("1.1")),
                factors().currencies("GBP", "EUR").nomenclatureDiscount("0.10").build());

            assertExactly(r.expectedRecovery(), "891");
            assertExactly(r.recoveryRatePercent(), "89.1");
            assertExactly(r.recoveryInGuaranteeCurrency(), "891");
            assertExactly(r.recoveryInFacilityCurrency(), "980.1");
        }

        @Test
        @DisplayName("every factor is applied once and with the right sense")
        void allFactorsCombined() {
            // RecupE = 2000 x 1 x 1 x (1 - 0) x (1 - 0.20) x (1 - 0.25) x 0.6 x 0.40 = 288
            // Using a complement where the value is meant (or the reverse) gives a different number,
            // e.g. allocation as (1 - 0.40) would give 432.
            ExpectedRecovery r = calculator.calculate(amount("2", Unit.THOUSAND), new ExchangeRates(rv("1"), rv("1")),
                factors().currencies("CHF", "EUR").nomenclatureDiscount("0.20")
                    .proposedDiscountPercent("25").correlationCoefficient("0.6").allocationPercent("40").build());

            assertExactly(r.expectedRecovery(), "288");
            assertExactly(r.recoveryRatePercent(), "14.4");
            assertExactly(r.recoveryInFacilityCurrency(), "288");
        }

        @Test
        void missingFacilityToGuaranteeRate() {
            RecoveryFactors mismatch = factors().currencies("USD", "EUR").build();
            ExchangeRates rates = new ExchangeRates(null, rv("2"));
            UnitAmount guarantee = amount("1", Unit.MILLION);

            assertThatExceptionOfType(MissingExchangeRateException.class)
                .isThrownBy(() -> calculator.calculate(guarantee, rates, mismatch))
                .withMessageStartingWith("facilityToGuaranteeCurrencyRate");
        }

        @Test
        void missingGuaranteeToFacilityRate() {
            RecoveryFactors mismatch = factors().currencies("USD", "EUR").build();
            ExchangeRates rates = new ExchangeRates(rv("0.5"), null);
            UnitAmount guarantee = amount("1", Unit.MILLION);

            assertThatExceptionOfType(MissingExchangeRateException.class)
                .isThrownBy(() -> calculator.calculate(guarantee, rates, mismatch))
                .withMessageStartingWith("guaranteeToFacilityCurrencyRate");
        }
    }

    @Nested
    @DisplayName("guarantee not yet started")
    class NotYetStarted {

        @Test
        @DisplayName("everything is 0, and this rule wins over the currency mismatch formula")
        void allZero() {
            ExpectedRecovery r = calculator.calculate(amount("1", Unit.MILLION), new ExchangeRates(rv("0.5"), rv("2")),
                factors().maturity(MaturityScenarios.guaranteeNotYetStarted()).currencies("USD", "EUR").build());

            assertExactly(r.expectedRecovery(), "0");
            assertExactly(r.recoveryRatePercent(), "0");
            assertExactly(r.recoveryInGuaranteeCurrency(), "0");
            assertExactly(r.recoveryInFacilityCurrency(), "0");
        }

        @Test
        @DisplayName("same currency: everything is 0")
        void allZeroSameCurrency() {
            ExpectedRecovery r = calculator.calculate(amount("1", Unit.MILLION), NO_RATES,
                factors().maturity(MaturityScenarios.guaranteeNotYetStarted()).build());

            assertExactly(r.expectedRecovery(), "0");
            assertExactly(r.recoveryInFacilityCurrency(), "0");
        }

        @Test
        @DisplayName("currently still needs the guarantee-to-facility rate on a mismatch, for RecupE_F = 0 x rate")
        void stillRequiresRateForFacilityCurrency() {
            // Pins today's behaviour: see the note in the delivery. Change this test if the BA decides otherwise.
            RecoveryFactors notStarted = factors()
                .maturity(MaturityScenarios.guaranteeNotYetStarted()).currencies("USD", "EUR").build();
            UnitAmount guarantee = amount("1", Unit.MILLION);

            assertThatExceptionOfType(MissingExchangeRateException.class)
                .isThrownBy(() -> calculator.calculate(guarantee, NO_RATES, notStarted));
        }
    }

    @ParameterizedTest(name = "{0}")
    @MethodSource("scenarios")
    @DisplayName("RecupE_G always equals RecupE (confirmed by the BA)")
    void recoveryInGuaranteeCurrencyEqualsExpectedRecovery(String description, UnitAmount guarantee,
                                                          ExchangeRates rates, RecoveryFactors factors) {
        ExpectedRecovery r = calculator.calculate(guarantee, rates, factors);
        assertApproximately(r.recoveryInGuaranteeCurrency(), r.expectedRecovery().getValue().toPlainString());
    }

    static Stream<Arguments> scenarios() {
        return Stream.of(
            Arguments.of("same currency", amount("10", Unit.MILLION), NO_RATES,
                factors().proposedDiscountPercent("10").correlationCoefficient("0.8").allocationPercent("50").build()),
            Arguments.of("partial maturity mismatch", amount("1000", Unit.UNIT), NO_RATES,
                factors().maturity(MaturityScenarios.partialMismatch()).build()),
            Arguments.of("currency mismatch", amount("3.7", Unit.BILLION), new ExchangeRates(rv("0.913"), rv("1.0952")),
                factors().currencies("USD", "EUR").correlationCoefficient("0.37").allocationPercent("33.3").build()),
            Arguments.of("not yet started", amount("1", Unit.MILLION), NO_RATES,
                factors().maturity(MaturityScenarios.guaranteeNotYetStarted()).build()));
    }

    @Nested
    @DisplayName("invalid input")
    class InvalidInput {

        @Test
        @DisplayName("a zero guarantee amount is rejected, because RecupT divides by it")
        void zeroGuaranteeAmount() {
            RecoveryFactors f = factors().build();
            UnitAmount zero = amount("0", Unit.MILLION);

            assertThatIllegalArgumentException()
                .isThrownBy(() -> calculator.calculate(zero, NO_RATES, f))
                .withMessage("Guarantee amount must be greater than zero");
        }

        @Test
        void nullGuarantee() {
            RecoveryFactors f = factors().build();
            assertThatNullPointerException().isThrownBy(() -> calculator.calculate(null, NO_RATES, f)).withMessage("guarantee");
        }

        @Test
        void nullRates() {
            RecoveryFactors f = factors().build();
            UnitAmount g = amount("1", Unit.UNIT);
            assertThatNullPointerException().isThrownBy(() -> calculator.calculate(g, null, f)).withMessage("rates");
        }

        @Test
        void nullFactors() {
            UnitAmount g = amount("1", Unit.UNIT);
            assertThatNullPointerException().isThrownBy(() -> calculator.calculate(g, NO_RATES, null)).withMessage("factors");
        }
    }
}
