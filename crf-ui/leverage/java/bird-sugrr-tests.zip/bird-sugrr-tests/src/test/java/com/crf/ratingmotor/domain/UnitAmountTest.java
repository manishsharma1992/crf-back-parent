package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.Unit;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/** Also covers Unit.toBase, the method added to the existing Unit enum. */
class UnitAmountTest {

    @ParameterizedTest(name = "2.5 {0} = {1}")
    @CsvSource({
        "UNIT,     2.5",
        "THOUSAND, 2500",
        "MILLION,  2500000",
        "BILLION,  2500000000",
        "TRILLION, 2500000000000"
    })
    void baseAmountAppliesTheUnit(Unit unit, String expected) {
        assertExactly(new UnitAmount(rv("2.5"), unit).baseAmount(), expected);
        assertExactly(unit.toBase(rv("2.5")), expected);
    }

    @Test
    void zeroIsAllowedHere() {
        assertExactly(new UnitAmount(rv("0"), Unit.MILLION).baseAmount(), "0");
    }

    @Test
    void rejectsNegativeAmount() {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new UnitAmount(rv("-0.01"), Unit.UNIT))
            .withMessageStartingWith("Amount must not be negative");
    }

    @Test
    void rejectsNullAmount() {
        assertThatNullPointerException().isThrownBy(() -> new UnitAmount(null, Unit.UNIT)).withMessage("amount");
    }

    @Test
    void rejectsNullUnit() {
        assertThatNullPointerException().isThrownBy(() -> new UnitAmount(rv("1"), null)).withMessage("unit");
    }
}
