package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;

/**
 * Builds RecoveryFactors with neutral defaults, so each test changes only what it is about.
 *
 * <p>Defaults: correlation coefficient 1, no maturity mismatch, EUR/EUR (no currency mismatch),
 * proposed discount 0%, allocation 100%. With these defaults RecupE equals the guarantee base amount.</p>
 */
public final class RecoveryFactorsBuilder {

    private String correlationCoefficient = "1";
    private MaturityAssessment maturity = MaturityScenarios.noMismatch();
    private String guaranteeCurrency = "EUR";
    private String facilityCurrency = "EUR";
    private CurrencyMismatchNomenclature nomenclature = new CurrencyMismatchNomenclature(false, false, null);
    private String proposedDiscountPercent = "0";
    private String allocationPercent = "100";

    public static RecoveryFactorsBuilder factors() {
        return new RecoveryFactorsBuilder();
    }

    public RecoveryFactorsBuilder correlationCoefficient(String value) {
        this.correlationCoefficient = value;
        return this;
    }

    public RecoveryFactorsBuilder maturity(MaturityAssessment assessment) {
        this.maturity = assessment;
        return this;
    }

    public RecoveryFactorsBuilder currencies(String guarantee, String facility) {
        this.guaranteeCurrency = guarantee;
        this.facilityCurrency = facility;
        return this;
    }

    /** Both currencies in the nomenclature, with the given discount as a fraction. */
    public RecoveryFactorsBuilder nomenclatureDiscount(String fraction) {
        this.nomenclature = new CurrencyMismatchNomenclature(true, true, RoundedValue.of(fraction));
        return this;
    }

    public RecoveryFactorsBuilder proposedDiscountPercent(String percent) {
        this.proposedDiscountPercent = percent;
        return this;
    }

    public RecoveryFactorsBuilder allocationPercent(String percent) {
        this.allocationPercent = percent;
        return this;
    }

    public RecoveryFactors build() {
        return new RecoveryFactors(
            new CorrelationCoefficientDriver(
                TestMatrices.uniform(Correlation.LOW, correlationCoefficient), SecurityType.GUARANTEE,
                new CounterpartyRating(3), new CounterpartyRating(5)),
            new DiscountMaturityMismatchDriver(maturity),
            new DiscountCurrencyMismatchDriver(
                new CurrencyCode(guaranteeCurrency), new CurrencyCode(facilityCurrency), nomenclature),
            new ProposedDiscountRateDriver(RoundedValue.of(proposedDiscountPercent)),
            new AllocationRateDriver(RoundedValue.of(allocationPercent)));
    }
}
