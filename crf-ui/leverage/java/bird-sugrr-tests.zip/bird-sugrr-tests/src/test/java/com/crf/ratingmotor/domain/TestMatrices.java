package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;

import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.Map;

/**
 * Builds correlation coefficient grids for tests.
 *
 * <p>The asymmetric grid makes every cell unique, so a swapped axis or a wrong security type is caught:
 * value = securityType.ordinal() + (guarantor * 100 + obligor) / 10000.
 * GUARANTEE, guarantor 3, obligor 5 is 0.0305; guarantor 5, obligor 3 is 0.0503;
 * CREDIT_INSURER, guarantor 3, obligor 5 is 1.0305.</p>
 */
public final class TestMatrices {

    private static final int SIZE = CorrelationCoefficientMatrix.SIZE;

    private TestMatrices() {}

    public static BigDecimal asymmetricValue(SecurityType type, int guarantor, int obligor) {
        return BigDecimal.valueOf(type.ordinal())
            .add(BigDecimal.valueOf(guarantor * 100L + obligor).movePointLeft(4));
    }

    public static Map<SecurityType, RoundedValue[][]> asymmetricGrids() {
        Map<SecurityType, RoundedValue[][]> grids = new EnumMap<>(SecurityType.class);
        for (SecurityType type : SecurityType.values()) {
            RoundedValue[][] grid = new RoundedValue[SIZE][SIZE];
            for (int g = 1; g <= SIZE; g++) {
                for (int o = 1; o <= SIZE; o++) {
                    grid[g - 1][o - 1] = RoundedValue.of(asymmetricValue(type, g, o));
                }
            }
            grids.put(type, grid);
        }
        return grids;
    }

    public static Map<SecurityType, RoundedValue[][]> uniformGrids(String value) {
        Map<SecurityType, RoundedValue[][]> grids = new EnumMap<>(SecurityType.class);
        for (SecurityType type : SecurityType.values()) {
            RoundedValue[][] grid = new RoundedValue[SIZE][SIZE];
            for (RoundedValue[] row : grid) {
                java.util.Arrays.fill(row, RoundedValue.of(value));
            }
            grids.put(type, grid);
        }
        return grids;
    }

    public static CorrelationCoefficientMatrix asymmetric(Correlation correlation) {
        return new CorrelationCoefficientMatrix(correlation, asymmetricGrids());
    }

    public static CorrelationCoefficientMatrix uniform(Correlation correlation, String value) {
        return new CorrelationCoefficientMatrix(correlation, uniformGrids(value));
    }
}
