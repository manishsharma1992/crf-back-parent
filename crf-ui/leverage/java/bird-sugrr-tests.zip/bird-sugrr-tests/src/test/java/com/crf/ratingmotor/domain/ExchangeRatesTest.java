package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatCode;

class ExchangeRatesTest {

    @Test
    @DisplayName("both rates may be absent: they are only needed when the currencies differ")
    void ratesAreOptional() {
        assertThatCode(() -> new ExchangeRates(null, null)).doesNotThrowAnyException();
    }

    @Test
    void requiredRatesAreReturnedWhenPresent() {
        ExchangeRates rates = new ExchangeRates(rv("0.5"), rv("2"));

        assertExactly(rates.requiredFacilityToGuarantee(), "0.5");
        assertExactly(rates.requiredGuaranteeToFacility(), "2");
    }

    @Test
    void missingFacilityToGuaranteeRate() {
        ExchangeRates rates = new ExchangeRates(null, rv("2"));
        assertThatExceptionOfType(MissingExchangeRateException.class)
            .isThrownBy(rates::requiredFacilityToGuarantee)
            .withMessage("facilityToGuaranteeCurrencyRate is required when the guarantee and facility currencies differ");
    }

    @Test
    void missingGuaranteeToFacilityRate() {
        ExchangeRates rates = new ExchangeRates(rv("0.5"), null);
        assertThatExceptionOfType(MissingExchangeRateException.class)
            .isThrownBy(rates::requiredGuaranteeToFacility)
            .withMessage("guaranteeToFacilityCurrencyRate is required when the guarantee and facility currencies differ");
    }

    @Test
    @DisplayName("a missing rate is a client error: MissingExchangeRateException is an IllegalArgumentException")
    void missingRateMapsToBadRequest() {
        ExchangeRates rates = new ExchangeRates(null, null);
        assertThatIllegalArgumentException().isThrownBy(rates::requiredFacilityToGuarantee);
    }

    @ParameterizedTest(name = "facility-to-guarantee rate {0} is rejected")
    @ValueSource(strings = {"0", "-0.0001", "-1"})
    void rejectsNonPositiveFacilityToGuarantee(String rate) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new ExchangeRates(rv(rate), rv("1")))
            .withMessageStartingWith("facilityToGuaranteeCurrencyRate must be positive");
    }

    @ParameterizedTest(name = "guarantee-to-facility rate {0} is rejected")
    @ValueSource(strings = {"0", "-0.0001", "-1"})
    void rejectsNonPositiveGuaranteeToFacility(String rate) {
        assertThatIllegalArgumentException()
            .isThrownBy(() -> new ExchangeRates(rv("1"), rv(rate)))
            .withMessageStartingWith("guaranteeToFacilityCurrencyRate must be positive");
    }
}
