package com.crf.ratingmotor;

import com.crf.ratingmotor.application.BirdSugrrComputeResult;
import com.crf.ratingmotor.application.GuaranteeRecoveryComputeManagementService;
import com.crf.ratingmotor.domain.DayCountConvention;
import com.crf.ratingmotor.infrastructure.CacheNames;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cache.CacheManager;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.stream.Stream;

import static com.crf.ratingmotor.application.BirdSugrrComputeQueryBuilder.query;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Integration test: HTTP -> controller -> application service -> domain -> cache -> JPA -> PostgreSQL.
 *
 * <p>Each test seeds the rating_matrix table inside its own transaction, which is rolled back afterwards,
 * so no reference data is changed. Uses the datasource of your integration-test profile; add
 * {@code @ActiveProfiles("...")} if your ITs need one. Expected values are worked out by hand from the
 * seeded data (GUARANTEE / LOW / 3 / 5 = 0.0305, GUARANTEE / HIGH / 3 / 5 = 0.5305).</p>
 */
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@Sql("/sql/correlation-matrix-seed.sql")
class GuaranteeRecoveryComputeManagementServiceIT {

    private static final String URL = "/calculate/expectedRecoveryAmount";

    private static final String SAME_CURRENCY_REQUEST = """
        {
          "currentDate": "2026-11-10",
          "guaranteeImplementationDate": "2025-01-01",
          "guaranteeMaturityDate": "2031-01-01",
          "guarantorCounterpartyRating": "3+",
          "borrowerOrGuarantorCorrelation": "LOW",
          "proposedDiscountRate": 10,
          "guaranteeAmount": 10,
          "guaranteeUnit": "MILLION",
          "guaranteeCurrency": "EUR",
          "allocationRate": 50,
          "facilityImplementationDate": "2025-01-01",
          "facilityMaturityDate": "2030-01-01",
          "facilityCurrency": "EUR",
          "obligorCounterpartyRating": "5-",
          "guaranteeCurrencyExistingFlag": true,
          "facilityCurrencyExistingFlag": true
        }
        """;

    private static final String CURRENCY_MISMATCH_REQUEST = """
        {
          "currentDate": "2026-11-10",
          "guaranteeImplementationDate": "2025-01-01",
          "guaranteeMaturityDate": "2031-01-01",
          "guarantorCounterpartyRating": "3",
          "borrowerOrGuarantorCorrelation": "LOW",
          "proposedDiscountRate": 10,
          "guaranteeAmount": 10,
          "guaranteeUnit": "MILLION",
          "guaranteeCurrency": "USD",
          "allocationRate": 50,
          "facilityImplementationDate": "2025-01-01",
          "facilityMaturityDate": "2030-01-01",
          "facilityCurrency": "EUR",
          "obligorCounterpartyRating": "5",
          "facilityToGuaranteeCurrencyRate": 0.5,
          "guaranteeToFacilityCurrencyRate": 2,
          "guaranteeCurrencyExistingFlag": false,
          "facilityCurrencyExistingFlag": false
        }
        """;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private GuaranteeRecoveryComputeManagementService service;

    @Autowired
    private DayCountConvention dayCountConvention;

    @Autowired
    private CacheManager cacheManager;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /** Matrices cached by one test were built from that test's rolled-back data, so never share them. */
    @BeforeEach
    void clearCachesBefore() {
        clearMatrixCaches();
    }

    @AfterEach
    void clearCachesAfter() {
        clearMatrixCaches();
    }

    private void clearMatrixCaches() {
        Stream.of(CacheNames.CORRELATION_MATRIX_LOW, CacheNames.CORRELATION_MATRIX_HIGH)
            .map(name -> cacheManager.getCache(name.getCacheName()))
            .filter(Objects::nonNull)
            .forEach(org.springframework.cache.Cache::clear);
    }

    private ResultActions postJson(String body) throws Exception {
        return mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(body));
    }

    @Test
    @DisplayName("the application runs with ACT/365 Fixed, as confirmed by the BA")
    void dayCountConventionIsAct365Fixed() {
        assertThat(dayCountConvention).isEqualTo(DayCountConvention.ACT_365_FIXED);
    }

    @Test
    @DisplayName("both matrix caches are registered")
    void matrixCachesExist() {
        assertThat(cacheManager.getCache(CacheNames.CORRELATION_MATRIX_LOW.getCacheName())).isNotNull();
        assertThat(cacheManager.getCache(CacheNames.CORRELATION_MATRIX_HIGH.getCacheName())).isNotNull();
    }

    @Test
    @DisplayName("service, LOW correlation: coefficient 0.0305 read from the database")
    void serviceLowCorrelation() {
        // RecupE = 10,000,000 x (1 - 0.10) x 0.0305 x 0.50 = 137,250
        BirdSugrrComputeResult result = service.compute(query().build());

        assertExactly(result.drivers().get(0).getEstimateValue(), "0.0305");
        assertExactly(result.recovery().expectedRecovery(), "137250");
        assertExactly(result.recovery().recoveryRatePercent(), "1.3725");
        assertExactly(result.recovery().recoveryInFacilityCurrency(), "137250");
    }

    @Test
    @DisplayName("service, HIGH correlation: coefficient 0.5305 from the HIGH rows")
    void serviceHighCorrelation() {
        // RecupE = 10,000,000 x 0.9 x 0.5305 x 0.5 = 2,387,250
        BirdSugrrComputeResult result = service.compute(query().borrowerOrGuarantorCorrelation("HIGH").build());

        assertExactly(result.drivers().get(0).getEstimateValue(), "0.5305");
        assertExactly(result.recovery().expectedRecovery(), "2387250");
    }

    @Test
    @DisplayName("HTTP, same currency: 200 with RecupE = 137,250.00 EUR")
    void httpSameCurrency() throws Exception {
        postJson(SAME_CURRENCY_REQUEST)
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.expectedRecovery.amount").value(137250.00))
            .andExpect(jsonPath("$.expectedRecovery.currency").value("EUR"))
            .andExpect(jsonPath("$.recoveryRatePercent").value(1.3725))
            .andExpect(jsonPath("$.recoveryInFacilityCurrency.amount").value(137250.00))
            .andExpect(jsonPath("$.recoveryInFacilityCurrency.currency").value("EUR"))
            .andExpect(jsonPath("$.drivers[0].name").value("CORRELATION_COEFFICIENT"))
            .andExpect(jsonPath("$.drivers[0].value").value(0.0305));
    }

    @Test
    @DisplayName("HTTP, currency mismatch with the 40.87% default discount")
    void httpCurrencyMismatch() throws Exception {
        // RecupE   = 10,000,000 x 0.5 x 2 x (1 - 0.4087) x (1 - 0.10) x 0.0305 x 0.50 = 81,155.925 -> 81,155.93 USD
        // RecupT   = 0.81155925 %
        // RecupE_F = 81,155.925 x 2 = 162,311.85 EUR
        postJson(CURRENCY_MISMATCH_REQUEST)
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.expectedRecovery.amount").value(81155.93))
            .andExpect(jsonPath("$.expectedRecovery.currency").value("USD"))
            .andExpect(jsonPath("$.recoveryRatePercent").value(0.811559))
            .andExpect(jsonPath("$.recoveryInGuaranteeCurrency.amount").value(81155.93))
            .andExpect(jsonPath("$.recoveryInFacilityCurrency.amount").value(162311.85))
            .andExpect(jsonPath("$.recoveryInFacilityCurrency.currency").value("EUR"))
            .andExpect(jsonPath("$.drivers[2].value").value(0.4087));
    }

    @Test
    @DisplayName("HTTP, invalid request: 400 before anything is read from the database")
    void httpValidationError() throws Exception {
        postJson(SAME_CURRENCY_REQUEST.replace("\"3+\"", "\"12\""))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.errors[0].field").value("guarantorCounterpartyRating"));
    }

    @Test
    @DisplayName("the matrix is cached: once loaded, it is served even if the table is emptied")
    void matrixIsCached() throws Exception {
        postJson(SAME_CURRENCY_REQUEST).andExpect(status().isOk());

        jdbcTemplate.update("DELETE FROM rating_matrix");

        postJson(SAME_CURRENCY_REQUEST)
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.expectedRecovery.amount").value(137250.00));
    }

    @Test
    @DisplayName("empty table and empty cache: 500 without internal details")
    void missingReferenceData() throws Exception {
        jdbcTemplate.update("DELETE FROM rating_matrix");

        postJson(SAME_CURRENCY_REQUEST)
            .andExpect(status().isInternalServerError())
            .andExpect(jsonPath("$.detail").value("Internal error while computing expected recovery"));
    }

    @Test
    @DisplayName("one missing cell in the table: 500, even for a request that needs another cell")
    void incompleteReferenceData() throws Exception {
        jdbcTemplate.update("DELETE FROM rating_matrix WHERE security_type = 'COLLATERAL' "
                            + "AND correlation = 'LOW' AND guarantor_rating = 10 AND obligor_rating = 10");

        postJson(SAME_CURRENCY_REQUEST).andExpect(status().isInternalServerError());
    }
}
