package com.crf.ratingmotor.domain;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class DiscountCurrencyMismatchDriverTest {

    private static final CurrencyCode EUR = new CurrencyCode("EUR");
    private static final CurrencyCode USD = new CurrencyCode("USD");
    private static final CurrencyMismatchNomenclature COVERED = new CurrencyMismatchNomenclature(true, true, rv("0.085"));
    private static final CurrencyMismatchNomenclature NOT_COVERED = new CurrencyMismatchNomenclature(false, false, null);

    @Nested
    @DisplayName("Calculation 1: currency mismatch indicator")
    class Indicator {

        @Test
        void sameCurrencyIsNoMismatch() {
            assertThat(CurrencyMismatchIndicator.between(EUR, new CurrencyCode("EUR")))
                .isEqualTo(CurrencyMismatchIndicator.NO_MISMATCH);
        }

        @Test
        void sameCurrencyInDifferentCaseIsNoMismatch() {
            assertThat(CurrencyMismatchIndicator.between(new CurrencyCode("eur"), EUR))
                .isEqualTo(CurrencyMismatchIndicator.NO_MISMATCH);
        }

        @Test
        void differentCurrencyIsMismatch() {
            assertThat(CurrencyMismatchIndicator.between(USD, EUR)).isEqualTo(CurrencyMismatchIndicator.MISMATCH);
        }

        @Test
        void indicatorValuesAreZeroAndOne() {
            assertThat(CurrencyMismatchIndicator.NO_MISMATCH.getValue()).isZero();
            assertThat(CurrencyMismatchIndicator.MISMATCH.getValue()).isEqualTo(1);
        }
    }

    @Nested
    @DisplayName("Calculation 2: discount")
    class Discount {

        @Test
        @DisplayName("0% when the currencies are the same, even if the nomenclature has a value")
        void noMismatchWinsOverNomenclature() {
            DiscountCurrencyMismatchDriver driver = new DiscountCurrencyMismatchDriver(EUR, EUR, COVERED);
            assertExactly(driver.getEstimateValue(), "0");
            assertThat(driver.indicator()).isEqualTo(CurrencyMismatchIndicator.NO_MISMATCH);
        }

        @Test
        @DisplayName("the nomenclature value when both currencies are in it")
        void nomenclatureValue() {
            DiscountCurrencyMismatchDriver driver = new DiscountCurrencyMismatchDriver(USD, EUR, COVERED);
            assertExactly(driver.getEstimateValue(), "0.085");
            assertThat(driver.indicator()).isEqualTo(CurrencyMismatchIndicator.MISMATCH);
        }

        @Test
        @DisplayName("0% for the same currency with both flags true and no currencyMismatch value")
        void sameCurrencyNeedsNoNomenclatureValue() {
            DiscountCurrencyMismatchDriver driver = new DiscountCurrencyMismatchDriver(
                EUR, EUR, new CurrencyMismatchNomenclature(true, true, null));
            assertExactly(driver.getEstimateValue(), "0");
        }

        @Test
        @DisplayName("a mismatch covered by the nomenclature but without a value is rejected as a client error")
        void mismatchWithoutNomenclatureValue() {
            CurrencyMismatchNomenclature noValue = new CurrencyMismatchNomenclature(true, true, null);
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new DiscountCurrencyMismatchDriver(USD, EUR, noValue))
                .withMessageStartingWith("currencyMismatch is required");
        }

        @ParameterizedTest(name = "guarantee exists={0}, facility exists={1}: 40.87%")
        @CsvSource({"false, false", "true, false", "false, true"})
        @DisplayName("40.87% when the currencies are not both in the nomenclature")
        void defaultDiscount(boolean guaranteeExists, boolean facilityExists) {
            DiscountCurrencyMismatchDriver driver = new DiscountCurrencyMismatchDriver(
                USD, EUR, new CurrencyMismatchNomenclature(guaranteeExists, facilityExists, null));
            assertExactly(driver.getEstimateValue(), "0.4087");
        }
    }

    @Test
    void exposesNameAndInputs() {
        DiscountCurrencyMismatchDriver driver = new DiscountCurrencyMismatchDriver(USD, EUR, COVERED);

        assertThat(driver.getName()).isEqualTo("DISCOUNT_CURRENCY_MISMATCH").isEqualTo(DiscountCurrencyMismatchDriver.NAME);
        assertThat(driver.guaranteeCurrency()).isEqualTo(USD);
        assertThat(driver.facilityCurrency()).isEqualTo(EUR);
        assertThat(driver.nomenclature()).isSameAs(COVERED);
    }

    @Test
    void rejectsNullGuaranteeCurrency() {
        assertThatNullPointerException()
            .isThrownBy(() -> new DiscountCurrencyMismatchDriver(null, EUR, NOT_COVERED))
            .withMessage("guaranteeCurrency");
    }

    @Test
    void rejectsNullFacilityCurrency() {
        assertThatNullPointerException()
            .isThrownBy(() -> new DiscountCurrencyMismatchDriver(USD, null, NOT_COVERED))
            .withMessage("facilityCurrency");
    }

    @Test
    void rejectsNullNomenclature() {
        assertThatNullPointerException()
            .isThrownBy(() -> new DiscountCurrencyMismatchDriver(USD, EUR, null))
            .withMessage("nomenclature");
    }
}
