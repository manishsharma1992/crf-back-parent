# BIRD SUGRR expected recovery: test suite

## What is in this package

```
src/test/java/com/crf/ratingmotor/
  domain/                      unit tests, plain Java, no Spring
    TestValues, TestMatrices, MaturityScenarios, RecoveryFactorsBuilder   (shared fixtures)
    CounterpartyRatingTest, CorrelationCoefficientMatrixTest, CorrelationCoefficientDriverTest,
    GenericDriverTest, DayCountConventionTest, MaturityDatesTest, MaturityAssessmentTest,
    DiscountMaturityMismatchDriverTest, CurrencyCodeTest, CurrencyMismatchNomenclatureTest,
    DiscountCurrencyMismatchDriverTest, PercentageDriverTest, UnitAmountTest, ExchangeRatesTest,
    RecoveryFactorsTest, ExpectedRecoveryCalculatorDomainServiceTest
  infrastructure/              unit tests, Mockito + Spring's in-memory cache manager
    CorrelationCoefficientMatrixRepositoryImplTest, CachingCorrelationCoefficientMatrixRepositoryTest
  application/                 unit test, real domain + fake repository, no Spring context
    BirdSugrrComputeQueryBuilder (fixture), GuaranteeRecoveryComputeManagementServiceTest
  exposition/
    ExpectedRecoveryResponseTest                 plain unit test of rounding and mapping
    BirdSugrrComputeControllerTest               @WebMvcTest slice: binding, validation, errors
  GuaranteeRecoveryComputeManagementServiceIT    @SpringBootTest + PostgreSQL, end to end
src/test/resources/sql/correlation-matrix-seed.sql

src/main/java/.../domain/CurrencyMismatchNomenclature.java    production fix, see below
src/main/java/.../domain/DiscountCurrencyMismatchDriver.java  production fix, see below
```

## Before you run them

1. **Packages.** Everything uses `com.crf.ratingmotor.*` as a placeholder. Replace it with your packages.
   The domain tests must sit in the same package as the domain classes, because they use
   package-private methods (`CounterpartyRating.index()`, `RecoveryFactors.currenciesDiffer()`, ...).
2. **Entity construction.** `CorrelationCoefficientMatrixRepositoryImplTest.entity(...)` builds the entity
   with setters. If yours uses a constructor or a builder, change that one method.
3. **URL.** Both web tests post to `/calculate/expectedRecoveryAmount`. Adjust `URL` if the controller has a
   class-level `@RequestMapping` prefix.
4. **Spring Boot version.** The controller test uses `@MockitoBean` (Boot 3.4+). On an older Boot, use `@MockBean`.
5. **Integration test.**
   - It must be in (or under) the package of your `@SpringBootApplication` class.
   - It uses the datasource of your IT setup; add `@ActiveProfiles(...)` if needed.
   - The seed script assumes the table is `rating_matrix`. It deletes and re-inserts inside the test
     transaction, which is rolled back, so reference data is never changed.
   - Name check: `GuaranteeRecoveryComputeManagementServiceIT` matches your `*ManagementService*` pattern.
     So does the unit test `GuaranteeRecoveryComputeManagementServiceTest`; check that Surefire still runs it
     as a unit test and Failsafe does not pick it up twice.

## What was verified, and what was not

The sandbox could not download Spring Boot, so the classes were recreated from our conversation and the
tests run with JUnit 5, AssertJ, Mockito and JaCoCo:

| Layer | Tests run | Line coverage | Branch coverage |
|---|---|---|---|
| domain | yes | 262/262 (100%) | 98/98 (100%) |
| application | yes | 53/53 (100%) | 10/10 (100%) |
| infrastructure (adapter + cache decorator) | yes | 46/48 (two unused entity getters) | 6/6 (100%) |
| exposition (response mapping) | yes | 14/14 (100%) | n/a |
| controller slice, integration test | **written, not run** | | |

266 tests, all passing. The entity's `getId()` and `getCorrelation()` are not called; with Lombok, add
`lombok.addLombokGeneratedAnnotation = true` to `lombok.config` so JaCoCo ignores generated code.

The controller test and the integration test need the real Spring jars and a database, so run them on
your side first.

Coverage was also checked with deliberate bugs (swapped matrix axes, min/max swapped, allocation used as
`1 - x`, a dropped FX rate, `&&` turned into `||`, a dropped date in the residual guarantee, an off-by-one in
ACT/ACT). Every one made tests fail. The only change not caught is `< 0.25` versus `<= 0.25` for the
3-month rule, because exactly 0.25 years cannot occur with whole days (91.25 or 91.5 days).

## Enforce 100% on the domain in the build

```xml
<execution>
  <id>check-domain-coverage</id>
  <goals><goal>check</goal></goals>
  <configuration>
    <rules>
      <rule>
        <element>PACKAGE</element>
        <includes><include>com.crf.ratingmotor.domain*</include></includes>
        <limits>
          <limit><counter>LINE</counter><value>COVEREDRATIO</value><minimum>1.00</minimum></limit>
          <limit><counter>BRANCH</counter><value>COVEREDRATIO</value><minimum>1.00</minimum></limit>
        </limits>
      </rule>
    </rules>
  </configuration>
</execution>
```

Add this to your existing `jacoco-maven-plugin` executions.
