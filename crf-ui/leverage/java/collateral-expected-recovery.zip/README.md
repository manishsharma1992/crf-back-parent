# Collateral expected recovery

Packages use the `com.crf.ratingmotor` placeholder: replace them with yours. This zip replaces
`collateral-driver-1.zip` and `collateral-driver-2.zip` and holds everything for collateral so far. It also
includes the credit insurer change made today, the removal of `pctOfBnppCoveredByCreditInsurer`.

## Files

| File | Layer | Purpose |
|---|---|---|
| `domain/MaturityDates.java` | Domain (changed) | Adds `forCollateral(...)`, and `forCreditInsurance` now uses the same private helper |
| `domain/MissingExchangeRateException.java` | Domain (changed) | New constructor `(rateName, protection)`. The guarantee message is unchanged |
| `domain/collateral/ProposedRecoveryRateDriver.java` | Domain | proposedRecoveryRateOnCollateral as a fraction. Applied, but not reported |
| `domain/collateral/CollateralExchangeRates.java` | Domain | The two renamed rates, each required only when the currencies differ |
| `domain/collateral/CollateralRecoveryFactors.java` | Domain | Dmm, Dmd, proposed recovery rate and allocation rate. Reports Dmm and Dmd |
| `domain/collateral/CollateralExpectedRecovery.java` | Domain | RecupEc, RecupTc, RecupEc_G (collateral currency), RecupEc_F (facility currency) |
| `domain/collateral/CollateralExpectedRecoveryCalculatorDomainService.java` | Domain service | Calculations 1 to 4 |
| `application/collateral/CollateralComputeQuery.java` | Application | The request, with the renamed rates and `facilityCurrencyExistFlag` |
| `application/collateral/CollateralRecoveryComputeResult.java` | Application | The result and its drivers |
| `application/collateral/CollateralRecoveryComputeManagementService.java` | Application | The use case. It builds Driver #1 and Driver #2 |
| `exposition/CollateralExpectedRecoveryResponse.java` | Exposition | Amounts with their currency, rounded to 2 decimals. The rate and the drivers are rounded to 6 |
| `exposition/CollateralComputeController.java` | Exposition | `POST calculate/collateralExpectedRecoveryAmount` |
| `application/creditinsurer/CreditInsurerComputeQuery.java` | Application (changed) | `pctOfBnppCoveredByCreditInsurer` removed |
| `docs/credit-insurer-*.md` | Docs (changed) | `pctOfBnppCoveredByCreditInsurer` removed |

Collateral has no correlation table, so it needs no repository, cache, entity or SQL.

## Changes to existing files

1. In `RatingMotorConfig`, register the domain service as a bean:
   ```java
   @Bean
   CollateralExpectedRecoveryCalculatorDomainService collateralExpectedRecoveryCalculatorDomainService() {
       return new CollateralExpectedRecoveryCalculatorDomainService();
   }
   ```
2. In the exception handler, add the new controller to the scope. Without it, errors from this endpoint do not come back as `problem+json`, and the controller test fails:
   ```java
   @RestControllerAdvice(assignableTypes = {GuaranteeRecoveryComputeController.class,
                                            CreditInsurerComputeController.class,
                                            CollateralComputeController.class})
   ```
3. crf-back must send `facilityToCurrentEconomicValueCurrencyRate` and `currentEconomicValueToFacilityCurrencyRate`.
   The old names are ignored, so every cross-currency request would fail with a 400 for a missing rate.

## The BA sample

The sample is 66 THOUSAND USD of collateral on an EUR facility, with a 30% proposed recovery rate and 100% allocation. The discounts are Dmm 0% and Dmd 17.4%, and the rates are 1.16 and 0.86.

| Output | Exact | Response |
|---|---|---|
| RecupEc | 66,000 x 1.16 x 0.86 x 0.30 x 1 x 0.826 x 1 = 16,315.54848 | 16,315.55 USD |
| RecupTc | 16,315.54848 / 66,000 x 100 = 24.720528 | 24.720528 |
| RecupEc_G | 66,000 x 24.720528 / 100 = 16,315.54848 | 16,315.55 USD |
| RecupEc_F | 16,315.54848 x 0.86 = 14,031.3716928 | 14,031.37 EUR |

## Tests

- **Domain:**
  - `CollateralMaturityMismatchTest`: Driver #1
  - `CollateralCurrencyMismatchTest`: Driver #2
  - `CollateralExpectedRecoveryCalculatorDomainServiceTest`
  - `CollateralRecoveryValuesTest`
- **Application:** `CollateralRecoveryComputeManagementServiceTest`
- **Exposition:**
  - `CollateralExpectedRecoveryResponseTest`
  - `CollateralComputeControllerTest`: a `@WebMvcTest` with `@MockBean` (Boot 3.0.6) and `addFilters = false`
- **Fixtures:** `CollateralFactorsBuilder`, `CollateralComputeQueryBuilder` (the defaults are the BA sample)

`CollateralComputeControllerTest.oldRateNamesIgnored` relies on Spring Boot's default
`FAIL_ON_UNKNOWN_PROPERTIES = false`. If your ObjectMapper is configured to reject unknown properties, change
that test to expect a 400.
