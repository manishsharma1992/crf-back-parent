package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.CurrencyCode;
import com.crf.ratingmotor.domain.MaturityScenarios;
import com.crf.ratingmotor.domain.MissingExchangeRateException;
import com.crf.ratingmotor.domain.UnitAmount;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.crf.ratingmotor.domain.TestValues.assertApproximately;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static com.crf.ratingmotor.domain.collateral.CollateralFactorsBuilder.factors;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/**
 * Calculations 1 to 4 of the collateral expected recovery. Expected values are worked out by hand (exact
 * fractions) from the specification; the BA sample is the first test.
 */
class CollateralExpectedRecoveryCalculatorDomainServiceTest {

    private final CollateralExpectedRecoveryCalculatorDomainService service =
        new CollateralExpectedRecoveryCalculatorDomainService();

    private static final CollateralExchangeRates SAMPLE_RATES = new CollateralExchangeRates(rv("1.16"), rv("0.86"));

    private static UnitAmount value(String amount, Unit unit) {
        return new UnitAmount(rv(amount), unit);
    }

    /** BA sample: 66 THOUSAND USD collateral, EUR facility, Dmm 0%, Dmd 17.4%, 30% proposed, 100% allocated. */
    private static CollateralRecoveryFactors sampleFactors() {
        return factors().currencies("USD", "EUR").nomenclatureDiscount("0.174").proposedRecoveryPercent("30").build();
    }

    @Nested
    @DisplayName("BA sample")
    class Sample {

        @Test
        @DisplayName("RecupEc = 66,000 x 1.16 x 0.86 x 30% x (1 - 0%) x (1 - 17.4%) x 100% = 16,315.54848 USD")
        void sample() {
            CollateralExpectedRecovery r = service.calculate(value("66", Unit.THOUSAND), SAMPLE_RATES, sampleFactors());

            assertExactly(r.expectedRecoveryOnCollateral(), "16315.54848");
            assertExactly(r.recoveryRateOnCollateralPercent(), "24.720528");
            assertExactly(r.expectedRecoveryInCollateralCurrency(), "16315.54848");
            assertThat(r.collateralCurrency()).isEqualTo(new CurrencyCode("USD"));
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "14031.3716928");
            assertThat(r.facilityCurrency()).isEqualTo(new CurrencyCode("EUR"));
        }

        @Test
        @DisplayName("RecupEc_G equals RecupEc: V x (RecupEc / V x 100) / 100")
        void recoveryInCollateralCurrencyEqualsRecupEc() {
            CollateralExpectedRecovery r = service.calculate(value("66", Unit.THOUSAND), SAMPLE_RATES, sampleFactors());
            assertThat(r.expectedRecoveryInCollateralCurrency().getValue())
                .isEqualByComparingTo(r.expectedRecoveryOnCollateral().getValue());
        }
    }

    @Nested
    @DisplayName("Calculation 1: RecupEc")
    class ExpectedRecoveryOnCollateral {

        @Test
        @DisplayName("same currency: no exchange rate is applied, and none is needed")
        void sameCurrency() {
            CollateralExpectedRecovery r = service.calculate(value("66", Unit.THOUSAND), CollateralExchangeRates.none(),
                factors().currencies("EUR", "eur").proposedRecoveryPercent("30").build());

            assertExactly(r.expectedRecoveryOnCollateral(), "19800");
            assertExactly(r.recoveryRateOnCollateralPercent(), "30");
            assertExactly(r.expectedRecoveryInCollateralCurrency(), "19800");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "19800");
            assertThat(r.collateralCurrency()).isEqualTo(r.facilityCurrency());
        }

        @Test
        @DisplayName("same currency: rates that are sent anyway are ignored")
        void sameCurrencyIgnoresRates() {
            CollateralExpectedRecovery r = service.calculate(value("66", Unit.THOUSAND), SAMPLE_RATES,
                factors().proposedRecoveryPercent("30").build());

            assertExactly(r.expectedRecoveryOnCollateral(), "19800");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "19800");
        }

        @Test
        @DisplayName("neutral factors: RecupEc is the collateral value, in base units")
        void neutralFactors() {
            CollateralExpectedRecovery r = service.calculate(value("1.5", Unit.TRILLION), CollateralExchangeRates.none(),
                factors().build());

            assertExactly(r.expectedRecoveryOnCollateral(), "1500000000000");
            assertExactly(r.recoveryRateOnCollateralPercent(), "100");
        }

        @ParameterizedTest(name = "{0} {1} = {2}")
        @CsvSource({
            "250, UNIT,     250",
            "2.5, THOUSAND, 2500",
            "2.5, MILLION,  2500000",
            "2.5, BILLION,  2500000000"
        })
        @DisplayName("currentEconomicValueUnit multiplies the value")
        void units(String amount, Unit unit, String expected) {
            CollateralExpectedRecovery r = service.calculate(value(amount, unit), CollateralExchangeRates.none(),
                factors().build());
            assertExactly(r.expectedRecoveryOnCollateral(), expected);
        }

        @Test
        @DisplayName("every factor is applied once: Dmm 8/15, Dmd 17.4%, FX, 30% proposed, 50% allocated")
        void allFactors() {
            CollateralExpectedRecovery r = service.calculate(value("66", Unit.THOUSAND), SAMPLE_RATES,
                factors().maturity(MaturityScenarios.partialMismatch())
                         .currencies("USD", "EUR").nomenclatureDiscount("0.174")
                         .proposedRecoveryPercent("30").allocationPercent("50").build());

            assertApproximately(r.expectedRecoveryOnCollateral(), "3806.961312");
            assertApproximately(r.recoveryRateOnCollateralPercent(), "5.7681232");
            assertApproximately(r.expectedRecoveryInCollateralCurrency(), "3806.961312");
            assertApproximately(r.expectedRecoveryInFacilityCurrency(), "3273.98672832");
        }

        @Test
        @DisplayName("currencies differ and not both in the nomenclature: Dmd is 40.87%")
        void defaultCurrencyDiscount() {
            CollateralExpectedRecovery r = service.calculate(value("1000", Unit.UNIT), new CollateralExchangeRates(rv("1"), rv("1")),
                factors().currencies("INR", "EUR").nomenclatureFlags(true, false).build());

            assertExactly(r.expectedRecoveryOnCollateral(), "591.3");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "591.3");
        }

        @Test
        @DisplayName("maturity mismatch of 100%: everything is 0")
        void fullMaturityMismatch() {
            CollateralExpectedRecovery r = service.calculate(value("66", Unit.THOUSAND), SAMPLE_RATES,
                factors().maturity(MaturityScenarios.fullMismatch()).currencies("USD", "EUR").build());

            assertExactly(r.expectedRecoveryOnCollateral(), "0");
            assertExactly(r.recoveryRateOnCollateralPercent(), "0");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "0");
        }

        @ParameterizedTest(name = "proposed {0}%, allocation {1}%")
        @CsvSource({"0, 100", "100, 0"})
        @DisplayName("a proposed recovery rate or an allocation rate of 0% gives 0")
        void zeroRates(String proposed, String allocation) {
            CollateralExpectedRecovery r = service.calculate(value("10", Unit.MILLION), CollateralExchangeRates.none(),
                factors().proposedRecoveryPercent(proposed).allocationPercent(allocation).build());

            assertExactly(r.expectedRecoveryOnCollateral(), "0");
            assertExactly(r.recoveryRateOnCollateralPercent(), "0");
        }
    }

    @Nested
    @DisplayName("Collateral not yet started (starts after the facility, and later than today)")
    class NotYetStarted {

        @Test
        @DisplayName("RecupEc, RecupTc, RecupEc_G and RecupEc_F are all 0")
        void allZero() {
            CollateralExpectedRecovery r = service.calculate(value("66", Unit.THOUSAND), SAMPLE_RATES,
                factors().maturity(MaturityScenarios.guaranteeNotYetStarted())
                         .currencies("USD", "EUR").nomenclatureDiscount("0.174").proposedRecoveryPercent("30").build());

            assertExactly(r.expectedRecoveryOnCollateral(), "0");
            assertExactly(r.recoveryRateOnCollateralPercent(), "0");
            assertExactly(r.expectedRecoveryInCollateralCurrency(), "0");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "0");
            assertThat(r.collateralCurrency()).isEqualTo(new CurrencyCode("USD"));
            assertThat(r.facilityCurrency()).isEqualTo(new CurrencyCode("EUR"));
        }

        @Test
        @DisplayName("same currency: also 0")
        void sameCurrency() {
            CollateralExpectedRecovery r = service.calculate(value("66", Unit.THOUSAND), CollateralExchangeRates.none(),
                factors().maturity(MaturityScenarios.guaranteeNotYetStarted()).build());

            assertExactly(r.expectedRecoveryOnCollateral(), "0");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "0");
        }
    }

    @Nested
    @DisplayName("Calculation 2: RecupTc with a collateral value of 0")
    class ZeroValue {

        @Test
        @DisplayName("RecupTc is 0 instead of a division by zero (assumption in the change log)")
        void zeroCollateralValue() {
            CollateralExpectedRecovery r = service.calculate(value("0", Unit.MILLION), SAMPLE_RATES, sampleFactors());

            assertExactly(r.expectedRecoveryOnCollateral(), "0");
            assertExactly(r.recoveryRateOnCollateralPercent(), "0");
            assertExactly(r.expectedRecoveryInCollateralCurrency(), "0");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "0");
        }
    }

    @Nested
    @DisplayName("Missing exchange rates when the currencies differ: 400")
    class MissingRates {

        @Test
        void facilityToCurrentEconomicValueMissing() {
            CollateralExchangeRates rates = new CollateralExchangeRates(null, rv("0.86"));
            assertThatExceptionOfType(MissingExchangeRateException.class)
                .isThrownBy(() -> service.calculate(value("66", Unit.THOUSAND), rates, sampleFactors()))
                .withMessage("facilityToCurrentEconomicValueCurrencyRate is required when the collateral and "
                             + "facility currencies differ");
        }

        @Test
        void currentEconomicValueToFacilityMissing() {
            CollateralExchangeRates rates = new CollateralExchangeRates(rv("1.16"), null);
            assertThatExceptionOfType(MissingExchangeRateException.class)
                .isThrownBy(() -> service.calculate(value("66", Unit.THOUSAND), rates, sampleFactors()))
                .withMessage("currentEconomicValueToFacilityCurrencyRate is required when the collateral and "
                             + "facility currencies differ");
        }
    }

    @Nested
    @DisplayName("Null arguments")
    class NullArguments {

        @Test
        void nullValue() {
            assertThatNullPointerException()
                .isThrownBy(() -> service.calculate(null, SAMPLE_RATES, sampleFactors()))
                .withMessage("currentEconomicValue");
        }

        @Test
        void nullRates() {
            assertThatNullPointerException()
                .isThrownBy(() -> service.calculate(value("1", Unit.UNIT), null, sampleFactors()))
                .withMessage("rates");
        }

        @Test
        void nullFactors() {
            assertThatNullPointerException()
                .isThrownBy(() -> service.calculate(value("1", Unit.UNIT), SAMPLE_RATES, null))
                .withMessage("factors");
        }
    }
}
