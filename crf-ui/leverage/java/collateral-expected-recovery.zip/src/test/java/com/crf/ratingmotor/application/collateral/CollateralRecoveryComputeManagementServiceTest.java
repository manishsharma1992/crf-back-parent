package com.crf.ratingmotor.application.collateral;

import com.crf.ratingmotor.domain.DayCountConvention;
import com.crf.ratingmotor.domain.Driver;
import com.crf.ratingmotor.domain.MissingExchangeRateException;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecovery;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecoveryCalculatorDomainService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;

import java.time.LocalDate;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

import static com.crf.ratingmotor.application.collateral.CollateralComputeQueryBuilder.collateralQuery;
import static com.crf.ratingmotor.domain.TestValues.assertApproximately;
import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/** Real domain service and day-count convention; no Spring context, nothing to mock (collateral has no table). */
class CollateralRecoveryComputeManagementServiceTest {

    private CollateralRecoveryComputeManagementService service;

    @BeforeEach
    void setUp() {
        service = new CollateralRecoveryComputeManagementService(
            DayCountConvention.ACT_365_FIXED, new CollateralExpectedRecoveryCalculatorDomainService());
    }

    private CollateralExpectedRecovery recovery(CollateralComputeQueryBuilder query) {
        return service.compute(query.build()).recovery();
    }

    @Nested
    @DisplayName("end-to-end through the domain")
    class HappyPath {

        @Test
        @DisplayName("BA sample: RecupEc = 16,315.54848 USD, RecupTc = 24.720528%, RecupEc_F = 14,031.3716928 EUR")
        void sample() {
            CollateralExpectedRecovery r = recovery(collateralQuery());

            assertExactly(r.expectedRecoveryOnCollateral(), "16315.54848");
            assertExactly(r.recoveryRateOnCollateralPercent(), "24.720528");
            assertExactly(r.expectedRecoveryInCollateralCurrency(), "16315.54848");
            assertThat(r.collateralCurrency().value()).isEqualTo("USD");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "14031.3716928");
            assertThat(r.facilityCurrency().value()).isEqualTo("EUR");
        }

        @Test
        @DisplayName("returns Driver #1 (Dmm) and Driver #2 (Dmd) with their values")
        void drivers() {
            List<Driver> drivers = service.compute(collateralQuery().build()).drivers();

            assertThat(drivers).extracting(Driver::getName)
                .containsExactly("DISCOUNT_MATURITY_MISMATCH", "DISCOUNT_CURRENCY_MISMATCH");
            assertExactly(drivers.get(0).getEstimateValue(), "0");
            assertExactly(drivers.get(1).getEstimateValue(), "0.174");
        }

        @Test
        @DisplayName("collateral dates drive the maturity mismatch: 2 years left on a 4-year facility, Dmm = 8/15")
        void collateralDatesUsed() {
            CollateralComputeQueryBuilder q = collateralQuery()
                .currentDate(LocalDate.of(2026, 1, 1))
                .collateralImplementationDate(LocalDate.of(2025, 1, 1)).collateralMaturityDate(LocalDate.of(2028, 1, 1))
                .facilityImplementationDate(LocalDate.of(2025, 1, 1)).facilityMaturityDate(LocalDate.of(2029, 12, 31));

            assertApproximately(service.compute(q.build()).drivers().get(0).getEstimateValue(), "0.5333333333333333333333333333");
            assertApproximately(recovery(q).expectedRecoveryOnCollateral(), "7613.922624");
        }

        @Test
        @DisplayName("collateral not yet started: everything is 0")
        void notYetStarted() {
            CollateralExpectedRecovery r = recovery(collateralQuery()
                .currentDate(LocalDate.of(2026, 11, 26))
                .collateralImplementationDate(LocalDate.of(2027, 1, 1)).collateralMaturityDate(LocalDate.of(2031, 1, 1)));

            assertExactly(r.expectedRecoveryOnCollateral(), "0");
            assertExactly(r.recoveryRateOnCollateralPercent(), "0");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "0");
        }

        @Test
        @DisplayName("same currency, in another case: no FX, Dmd 0%, the rates may be left out")
        void sameCurrency() {
            CollateralExpectedRecovery r = recovery(collateralQuery()
                .currentEconomicValueCurrency("eur").facilityCurrency("EUR")
                .facilityToCurrentEconomicValueCurrencyRate(null).currentEconomicValueToFacilityCurrencyRate(null)
                .currencyMismatch(null));

            assertExactly(r.expectedRecoveryOnCollateral(), "19800");
            assertExactly(r.expectedRecoveryInFacilityCurrency(), "19800");
            assertThat(r.collateralCurrency().value()).isEqualTo("EUR");
        }

        @ParameterizedTest(name = "currentEconomicCurrencyExistFlag {0}, facilityCurrencyExistFlag {1}: Dmd 40.87%")
        @CsvSource({"false, true", "true, false", "false, false"})
        @DisplayName("each nomenclature flag is mapped to its own side")
        void flagsMapped(boolean collateralFlag, boolean facilityFlag) {
            List<Driver> drivers = service.compute(collateralQuery()
                .currentEconomicCurrencyExistFlag(collateralFlag).facilityCurrencyExistFlag(facilityFlag).build()).drivers();

            assertExactly(drivers.get(1).getEstimateValue(), "0.4087");
        }

        @Test
        @DisplayName("facilityAmount and facilityUnit do not change the result")
        void facilityAmountUnused() {
            CollateralExpectedRecovery r = recovery(collateralQuery().facilityAmount("0").facilityUnit("UNIT"));
            assertExactly(r.expectedRecoveryOnCollateral(), "16315.54848");
        }

        @Test
        @DisplayName("a collateral value of 0 gives 0 everywhere, including RecupTc")
        void zeroValue() {
            CollateralExpectedRecovery r = recovery(collateralQuery().currentEconomicValue("0"));
            assertExactly(r.expectedRecoveryOnCollateral(), "0");
            assertExactly(r.recoveryRateOnCollateralPercent(), "0");
        }
    }

    @Nested
    @DisplayName("invalid requests are IllegalArgumentException (400) with the field name")
    class InvalidRequests {

        static Stream<Arguments> invalid() {
            return Stream.of(
                Arguments.of("proposedRecoveryRateOnCollateral must not be null", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.proposedRecoveryRateOnCollateral(null)),
                Arguments.of("PROPOSED_RECOVERY_RATE must be between 0 and 100", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.proposedRecoveryRateOnCollateral("101")),
                Arguments.of("allocationRate must not be null", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.allocationRate(null)),
                Arguments.of("ALLOCATION_RATE must be between 0 and 100", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.allocationRate("-1")),
                Arguments.of("currentEconomicValue must not be null", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.currentEconomicValue(null)),
                Arguments.of("Amount must not be negative", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.currentEconomicValue("-1")),
                Arguments.of("Unknown Unit", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.currentEconomicValueUnit("HUNDRED")),
                Arguments.of("Currency must be a 3-letter code", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.currentEconomicValueCurrency("EURO")),
                Arguments.of("Currency must be a 3-letter code", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.facilityCurrency(null)),
                Arguments.of("currentEconomicCurrencyExistFlag must not be null", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.currentEconomicCurrencyExistFlag(null)),
                Arguments.of("facilityCurrencyExistFlag must not be null", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.facilityCurrencyExistFlag(null)),
                Arguments.of("currencyMismatch is required", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.currencyMismatch(null)),
                Arguments.of("currencyMismatch must be a fraction between 0 and 1", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.currencyMismatch("17.4")),
                Arguments.of("facilityToCurrentEconomicValueCurrencyRate must be positive", (UnaryOperator<CollateralComputeQueryBuilder>) b -> b.facilityToCurrentEconomicValueCurrencyRate("0")));
        }

        @ParameterizedTest(name = "{0}")
        @MethodSource("invalid")
        void rejected(String message, UnaryOperator<CollateralComputeQueryBuilder> change) {
            CollateralComputeQuery query = change.apply(collateralQuery()).build();
            assertThatIllegalArgumentException().isThrownBy(() -> service.compute(query)).withMessageStartingWith(message);
        }

        @Test
        @DisplayName("currencies differ and a rate is missing: MissingExchangeRateException with the new field name")
        void missingRate() {
            CollateralComputeQuery query = collateralQuery().currentEconomicValueToFacilityCurrencyRate(null).build();
            assertThatExceptionOfType(MissingExchangeRateException.class)
                .isThrownBy(() -> service.compute(query))
                .withMessageStartingWith("currentEconomicValueToFacilityCurrencyRate is required");
        }

        @Test
        void nullQuery() {
            assertThatNullPointerException().isThrownBy(() -> service.compute(null)).withMessage("query");
        }

        @Test
        @DisplayName("a missing date names the collateral field (Bean Validation rejects it first in the API)")
        void missingDate() {
            CollateralComputeQuery query = collateralQuery().collateralMaturityDate(null).build();
            assertThatNullPointerException().isThrownBy(() -> service.compute(query)).withMessage("collateralMaturityDate");
        }
    }
}
