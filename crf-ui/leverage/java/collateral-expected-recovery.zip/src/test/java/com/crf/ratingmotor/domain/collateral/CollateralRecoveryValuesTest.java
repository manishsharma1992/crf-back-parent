package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.domain.AllocationRateDriver;
import com.crf.ratingmotor.domain.Driver;
import com.crf.ratingmotor.domain.MissingExchangeRateException;
import com.crf.ratingmotor.domain.MaturityScenarios;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static com.crf.ratingmotor.domain.collateral.CollateralFactorsBuilder.factors;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

/** The value objects around the collateral calculation: rates, the proposed recovery rate and the factors. */
class CollateralRecoveryValuesTest {

    @Nested
    @DisplayName("CollateralExchangeRates")
    class ExchangeRates {

        @Test
        void keepsBothRates() {
            CollateralExchangeRates rates = new CollateralExchangeRates(rv("1.16"), rv("0.86"));
            assertExactly(rates.requiredFacilityToCurrentEconomicValue(), "1.16");
            assertExactly(rates.requiredCurrentEconomicValueToFacility(), "0.86");
        }

        @Test
        @DisplayName("none(): both rates absent, which is valid until a rate is needed")
        void none() {
            CollateralExchangeRates rates = CollateralExchangeRates.none();
            assertThat(rates.facilityToCurrentEconomicValue()).isNull();
            assertThat(rates.currentEconomicValueToFacility()).isNull();
            assertThatExceptionOfType(MissingExchangeRateException.class)
                .isThrownBy(rates::requiredFacilityToCurrentEconomicValue);
        }

        @ParameterizedTest(name = "facilityToCurrentEconomicValueCurrencyRate = {0}")
        @CsvSource({"0", "-1"})
        void facilityToCurrentEconomicValueMustBePositive(String rate) {
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new CollateralExchangeRates(rv(rate), null))
                .withMessageStartingWith("facilityToCurrentEconomicValueCurrencyRate must be positive");
        }

        @ParameterizedTest(name = "currentEconomicValueToFacilityCurrencyRate = {0}")
        @CsvSource({"0", "-0.5"})
        void currentEconomicValueToFacilityMustBePositive(String rate) {
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new CollateralExchangeRates(null, rv(rate)))
                .withMessageStartingWith("currentEconomicValueToFacilityCurrencyRate must be positive");
        }

        @Test
        @DisplayName("a missing rate is a client error: MissingExchangeRateException is an IllegalArgumentException")
        void missingRateIsClientError() {
            assertThat(new MissingExchangeRateException("x", "collateral"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("x is required when the collateral and facility currencies differ");
        }

        @Test
        @DisplayName("the guarantee message is unchanged")
        void guaranteeMessageUnchanged() {
            assertThat(new MissingExchangeRateException("guaranteeToFacilityCurrencyRate"))
                .hasMessage("guaranteeToFacilityCurrencyRate is required when the guarantee and facility currencies differ");
        }
    }

    @Nested
    @DisplayName("ProposedRecoveryRateDriver")
    class ProposedRecoveryRate {

        @ParameterizedTest(name = "{0}% -> {1}")
        @CsvSource({"30, 0.3", "0, 0", "100, 1", "12.5, 0.125"})
        void percentBecomesFraction(String percent, String fraction) {
            ProposedRecoveryRateDriver driver = new ProposedRecoveryRateDriver(rv(percent));
            assertThat(driver.getName()).isEqualTo("PROPOSED_RECOVERY_RATE");
            assertExactly(driver.getEstimateValue(), fraction);
            assertExactly(driver.percent(), percent);
        }

        @ParameterizedTest(name = "{0}%")
        @CsvSource({"-0.01", "100.01"})
        void outOfRange(String percent) {
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new ProposedRecoveryRateDriver(rv(percent)))
                .withMessageStartingWith("PROPOSED_RECOVERY_RATE must be between 0 and 100");
        }
    }

    @Nested
    @DisplayName("CollateralRecoveryFactors")
    class Factors {

        @Test
        @DisplayName("reports Driver #1 (Dmm) and Driver #2 (Dmd) only, in that order")
        void reportedDrivers() {
            CollateralRecoveryFactors f = factors().currencies("USD", "EUR").nomenclatureDiscount("0.174")
                                                  .proposedRecoveryPercent("30").allocationPercent("50").build();

            assertThat(f.reportedDrivers()).extracting(Driver::getName)
                .containsExactly("DISCOUNT_MATURITY_MISMATCH", "DISCOUNT_CURRENCY_MISMATCH");
            assertExactly(f.reportedDrivers().get(1).getEstimateValue(), "0.174");
        }

        @Test
        void currenciesDiffer() {
            assertThat(factors().currencies("USD", "EUR").build().currenciesDiffer()).isTrue();
            assertThat(factors().currencies("EUR", "EUR").build().currenciesDiffer()).isFalse();
        }

        @Test
        void collateralNotYetStarted() {
            assertThat(factors().maturity(MaturityScenarios.guaranteeNotYetStarted()).build().collateralNotYetStarted()).isTrue();
            assertThat(factors().build().collateralNotYetStarted()).isFalse();
        }

        @Test
        void nullsAreRejected() {
            CollateralRecoveryFactors f = factors().build();
            DiscountMaturityMismatchDriver maturity = f.maturity();
            ProposedRecoveryRateDriver proposed = f.proposedRecoveryRate();
            AllocationRateDriver allocation = f.allocation();

            assertThatNullPointerException()
                .isThrownBy(() -> new CollateralRecoveryFactors(null, f.currency(), proposed, allocation)).withMessage("maturity");
            assertThatNullPointerException()
                .isThrownBy(() -> new CollateralRecoveryFactors(maturity, null, proposed, allocation)).withMessage("currency");
            assertThatNullPointerException()
                .isThrownBy(() -> new CollateralRecoveryFactors(maturity, f.currency(), null, allocation))
                .withMessage("proposedRecoveryRate");
            assertThatNullPointerException()
                .isThrownBy(() -> new CollateralRecoveryFactors(maturity, f.currency(), proposed, null)).withMessage("allocation");
        }
    }
}
