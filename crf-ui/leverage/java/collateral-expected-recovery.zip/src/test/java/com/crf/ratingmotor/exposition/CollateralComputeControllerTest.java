package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.collateral.CollateralComputeQuery;
import com.crf.ratingmotor.application.collateral.CollateralRecoveryComputeManagementService;
import com.crf.ratingmotor.application.collateral.CollateralRecoveryComputeResult;
import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.MissingExchangeRateException;
import com.crf.ratingmotor.domain.UnitAmount;
import com.crf.ratingmotor.domain.collateral.CollateralExchangeRates;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecovery;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.collateral.CollateralRecoveryFactors;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import static com.crf.ratingmotor.domain.TestValues.rv;
import static com.crf.ratingmotor.domain.collateral.CollateralFactorsBuilder.factors;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.not;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Web layer only: request binding, Bean Validation, response mapping and error handling.
 * The application service is mocked. Security filters are off, as in the guarantee slice test.
 */
@WebMvcTest(CollateralComputeController.class)
@AutoConfigureMockMvc(addFilters = false)
class CollateralComputeControllerTest {

    /** Adjust if the controller has a class-level @RequestMapping prefix. */
    private static final String URL = "/calculate/collateralExpectedRecoveryAmount";

    /** The BA sample: 66 THOUSAND USD collateral on a 125 MILLION EUR facility. */
    private static final String VALID_REQUEST = """
        {
          "currentDate": "2026-11-26",
          "collateralImplementationDate": "2025-01-01",
          "collateralMaturityDate": "2031-01-01",
          "proposedRecoveryRateOnCollateral": 30,
          "currentEconomicValue": 66,
          "currentEconomicValueUnit": "THOUSAND",
          "currentEconomicValueCurrency": "USD",
          "allocationRate": 100,
          "facilityImplementationDate": "2025-01-01",
          "facilityMaturityDate": "2030-01-01",
          "facilityAmount": 125,
          "facilityUnit": "MILLION",
          "facilityCurrency": "EUR",
          "facilityToCurrentEconomicValueCurrencyRate": 1.16,
          "currentEconomicValueToFacilityCurrencyRate": 0.86,
          "currentEconomicCurrencyExistFlag": true,
          "facilityCurrencyExistFlag": true,
          "currencyMismatch": 0.174
        }
        """;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private CollateralRecoveryComputeManagementService computeService;

    private ResultActions postJson(String body) throws Exception {
        return mockMvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content(body));
    }

    /** The valid request with one field replaced, or removed when remove is true. */
    private String requestWith(String field, Object value, boolean remove) throws Exception {
        Map<String, Object> body = objectMapper.readValue(VALID_REQUEST, new TypeReference<LinkedHashMap<String, Object>>() {});
        if (remove) {
            body.remove(field);
        } else {
            body.put(field, value);
        }
        return objectMapper.writeValueAsString(body);
    }

    /** The BA sample through the real domain service: RecupEc_F = 14,031.37 EUR. */
    private static CollateralRecoveryComputeResult sample() {
        CollateralRecoveryFactors f = factors().currencies("USD", "EUR").nomenclatureDiscount("0.174")
                                              .proposedRecoveryPercent("30").build();
        CollateralExpectedRecovery r = new CollateralExpectedRecoveryCalculatorDomainService().calculate(
            new UnitAmount(rv("66"), Unit.THOUSAND), new CollateralExchangeRates(rv("1.16"), rv("0.86")), f);
        return new CollateralRecoveryComputeResult(r, f.reportedDrivers());
    }

    @Nested
    @DisplayName("200 OK")
    class Success {

        @Test
        @DisplayName("returns the four recovery figures, rounded, with currencies and the two drivers")
        void returnsResponse() throws Exception {
            when(computeService.compute(any())).thenReturn(sample());

            postJson(VALID_REQUEST)
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.expectedRecoveryOnCollateral.amount").value(16315.55))
                .andExpect(jsonPath("$.expectedRecoveryOnCollateral.currency").value("USD"))
                .andExpect(jsonPath("$.recoveryRateOnCollateralPercent").value(24.720528))
                .andExpect(jsonPath("$.expectedRecoveryInCollateralCurrency.amount").value(16315.55))
                .andExpect(jsonPath("$.expectedRecoveryInCollateralCurrency.currency").value("USD"))
                .andExpect(jsonPath("$.expectedRecoveryInFacilityCurrency.amount").value(14031.37))
                .andExpect(jsonPath("$.expectedRecoveryInFacilityCurrency.currency").value("EUR"))
                .andExpect(jsonPath("$.drivers.length()").value(2))
                .andExpect(jsonPath("$.drivers[0].name").value("DISCOUNT_MATURITY_MISMATCH"))
                .andExpect(jsonPath("$.drivers[0].value").value(0.0))
                .andExpect(jsonPath("$.drivers[1].name").value("DISCOUNT_CURRENCY_MISMATCH"))
                .andExpect(jsonPath("$.drivers[1].value").value(0.174));
        }

        @Test
        @DisplayName("binds every JSON field into the query, including ISO dates and the renamed rates")
        void bindsQuery() throws Exception {
            when(computeService.compute(any())).thenReturn(sample());

            postJson(VALID_REQUEST).andExpect(status().isOk());

            ArgumentCaptor<CollateralComputeQuery> captor = ArgumentCaptor.forClass(CollateralComputeQuery.class);
            verify(computeService).compute(captor.capture());
            CollateralComputeQuery q = captor.getValue();
            assertThat(q.currentDate()).isEqualTo(LocalDate.of(2026, 11, 26));
            assertThat(q.collateralImplementationDate()).isEqualTo(LocalDate.of(2025, 1, 1));
            assertThat(q.collateralMaturityDate()).isEqualTo(LocalDate.of(2031, 1, 1));
            assertThat(q.facilityMaturityDate()).isEqualTo(LocalDate.of(2030, 1, 1));
            assertThat(q.currentEconomicValue()).isEqualByComparingTo("66");
            assertThat(q.currentEconomicValueUnit()).isEqualTo("THOUSAND");
            assertThat(q.currentEconomicValueCurrency()).isEqualTo("USD");
            assertThat(q.facilityToCurrentEconomicValueCurrencyRate()).isEqualByComparingTo("1.16");
            assertThat(q.currentEconomicValueToFacilityCurrencyRate()).isEqualByComparingTo("0.86");
            assertThat(q.currentEconomicCurrencyExistFlag()).isTrue();
            assertThat(q.facilityCurrencyExistFlag()).isTrue();
            assertThat(q.currencyMismatch()).isEqualByComparingTo("0.174");
        }

        @ParameterizedTest(name = "optional field {0} may be omitted")
        @CsvSource({"facilityToCurrentEconomicValueCurrencyRate", "currentEconomicValueToFacilityCurrencyRate",
                    "currencyMismatch"})
        void optionalFields(String field) throws Exception {
            when(computeService.compute(any())).thenReturn(sample());

            postJson(requestWith(field, null, true)).andExpect(status().isOk());
        }

        @ParameterizedTest(name = "{0} = {1} is accepted")
        @CsvSource({
            "currentEconomicValueUnit,         unit",
            "currentEconomicValueCurrency,     inr",
            "facilityUnit,                     TRILLION",
            "proposedRecoveryRateOnCollateral, 0",
            "proposedRecoveryRateOnCollateral, 100",
            "allocationRate,                   0",
            "currentEconomicValue,             0",
            "facilityAmount,                   0",
            "currencyMismatch,                 1"
        })
        void boundaryValuesAccepted(String field, String value) throws Exception {
            when(computeService.compute(any())).thenReturn(sample());

            postJson(requestWith(field, value, false)).andExpect(status().isOk());
        }
    }

    @Nested
    @DisplayName("400 Bad Request from Bean Validation; the service is never called")
    class ValidationErrors {

        @ParameterizedTest(name = "missing {0}")
        @CsvSource({
            "currentDate", "collateralImplementationDate", "collateralMaturityDate",
            "proposedRecoveryRateOnCollateral", "currentEconomicValue", "currentEconomicValueUnit",
            "currentEconomicValueCurrency", "allocationRate", "facilityImplementationDate", "facilityMaturityDate",
            "facilityAmount", "facilityUnit", "facilityCurrency",
            "currentEconomicCurrencyExistFlag", "facilityCurrencyExistFlag"
        })
        void missingRequiredField(String field) throws Exception {
            postJson(requestWith(field, null, true))
                .andExpect(status().isBadRequest())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.status").value(400))
                .andExpect(jsonPath("$.errors[*].field", hasItem(field)));

            verify(computeService, never()).compute(any());
        }

        @ParameterizedTest(name = "{0} = {1} is rejected")
        @CsvSource({
            "proposedRecoveryRateOnCollateral,           -1",
            "proposedRecoveryRateOnCollateral,           100.01",
            "allocationRate,                             101",
            "currentEconomicValue,                       -0.01",
            "facilityAmount,                             -5",
            "currentEconomicValueUnit,                   THOUSANDS",
            "facilityUnit,                               HUNDRED",
            "currentEconomicValueCurrency,               EURO",
            "facilityCurrency,                           E1R",
            "facilityToCurrentEconomicValueCurrencyRate, 0",
            "currentEconomicValueToFacilityCurrencyRate, -0.86",
            "currencyMismatch,                           17.4",
            "currencyMismatch,                           -0.1"
        })
        void invalidValue(String field, String value) throws Exception {
            postJson(requestWith(field, value, false))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[*].field", hasItem(field)));

            verify(computeService, never()).compute(any());
        }

        @Test
        @DisplayName("the old rate names are no longer bound")
        void oldRateNamesIgnored() throws Exception {
            when(computeService.compute(any())).thenReturn(sample());
            Map<String, Object> body = objectMapper.readValue(VALID_REQUEST, new TypeReference<LinkedHashMap<String, Object>>() {});
            body.remove("currentEconomicValueToFacilityCurrencyRate");
            body.put("collateralToFacilityCurrencyRate", 0.86);

            postJson(objectMapper.writeValueAsString(body)).andExpect(status().isOk());

            ArgumentCaptor<CollateralComputeQuery> captor = ArgumentCaptor.forClass(CollateralComputeQuery.class);
            verify(computeService).compute(captor.capture());
            assertThat(captor.getValue().currentEconomicValueToFacilityCurrencyRate()).isNull();
        }
    }

    @Nested
    @DisplayName("other client errors")
    class OtherClientErrors {

        @Test
        @DisplayName("an invalid date is a 400, not a 500")
        void invalidDate() throws Exception {
            postJson(requestWith("collateralMaturityDate", "2031-13-45", false)).andExpect(status().isBadRequest());
            verify(computeService, never()).compute(any());
        }

        @Test
        void malformedJson() throws Exception {
            postJson("{\"currentDate\": ").andExpect(status().isBadRequest());
        }

        @Test
        void wrongContentType() throws Exception {
            mockMvc.perform(post(URL).contentType(MediaType.TEXT_PLAIN).content(VALID_REQUEST))
                .andExpect(status().isUnsupportedMediaType());
        }

        @Test
        @DisplayName("a missing FX rate on a currency mismatch is a 400 with the new field name")
        void missingExchangeRate() throws Exception {
            when(computeService.compute(any()))
                .thenThrow(new MissingExchangeRateException("currentEconomicValueToFacilityCurrencyRate", "collateral"));

            postJson(VALID_REQUEST)
                .andExpect(status().isBadRequest())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(jsonPath("$.detail").value(
                    "currentEconomicValueToFacilityCurrencyRate is required when the collateral and facility currencies differ"));
        }

        @Test
        @DisplayName("a missing nomenclature value is a 400")
        void missingCurrencyMismatch() throws Exception {
            when(computeService.compute(any())).thenThrow(new IllegalArgumentException(
                "currencyMismatch is required when the currencies differ and both are in the nomenclature"));

            postJson(VALID_REQUEST)
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.detail").value(containsString("currencyMismatch is required")));
        }
    }

    @Nested
    @DisplayName("500 Internal Server Error, without leaking internals")
    class ServerErrors {

        @Test
        void unexpectedException() throws Exception {
            when(computeService.compute(any())).thenThrow(new RuntimeException("connection to db-host:5432 refused"));

            postJson(VALID_REQUEST)
                .andExpect(status().isInternalServerError())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PROBLEM_JSON))
                .andExpect(content().string(not(containsString("db-host"))));
        }

        @Test
        @DisplayName("an IllegalStateException is a 500, not a 400")
        void illegalState() throws Exception {
            when(computeService.compute(any())).thenThrow(new IllegalStateException("unexpected"));

            postJson(VALID_REQUEST).andExpect(status().isInternalServerError());
        }
    }
}
