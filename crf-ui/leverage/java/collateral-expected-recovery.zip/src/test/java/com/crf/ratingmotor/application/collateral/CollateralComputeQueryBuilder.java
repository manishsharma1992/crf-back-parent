package com.crf.ratingmotor.application.collateral;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Test builder for CollateralComputeQuery. Defaults are the BA sample: 66 THOUSAND USD collateral on a
 * 125 MILLION EUR facility, 30% proposed recovery, 100% allocated, Dmd 17.4% from the nomenclature, and dates
 * with no maturity mismatch (the collateral outlives the facility). RecupEc_F = 14,031.3716928 EUR.
 */
public final class CollateralComputeQueryBuilder {

    private LocalDate currentDate = LocalDate.of(2026, 11, 26);
    private LocalDate collateralImplementationDate = LocalDate.of(2025, 1, 1);
    private LocalDate collateralMaturityDate = LocalDate.of(2031, 1, 1);
    private BigDecimal proposedRecoveryRateOnCollateral = new BigDecimal("30");
    private BigDecimal currentEconomicValue = new BigDecimal("66");
    private String currentEconomicValueUnit = "THOUSAND";
    private String currentEconomicValueCurrency = "USD";
    private BigDecimal allocationRate = new BigDecimal("100");
    private LocalDate facilityImplementationDate = LocalDate.of(2025, 1, 1);
    private LocalDate facilityMaturityDate = LocalDate.of(2030, 1, 1);
    private BigDecimal facilityAmount = new BigDecimal("125");
    private String facilityUnit = "MILLION";
    private String facilityCurrency = "EUR";
    private BigDecimal facilityToCurrentEconomicValueCurrencyRate = new BigDecimal("1.16");
    private BigDecimal currentEconomicValueToFacilityCurrencyRate = new BigDecimal("0.86");
    private Boolean currentEconomicCurrencyExistFlag = true;
    private Boolean facilityCurrencyExistFlag = true;
    private BigDecimal currencyMismatch = new BigDecimal("0.174");

    public static CollateralComputeQueryBuilder collateralQuery() {
        return new CollateralComputeQueryBuilder();
    }

    public CollateralComputeQueryBuilder currentDate(LocalDate v) { currentDate = v; return this; }
    public CollateralComputeQueryBuilder collateralImplementationDate(LocalDate v) { collateralImplementationDate = v; return this; }
    public CollateralComputeQueryBuilder collateralMaturityDate(LocalDate v) { collateralMaturityDate = v; return this; }
    public CollateralComputeQueryBuilder proposedRecoveryRateOnCollateral(String v) { proposedRecoveryRateOnCollateral = decimal(v); return this; }
    public CollateralComputeQueryBuilder currentEconomicValue(String v) { currentEconomicValue = decimal(v); return this; }
    public CollateralComputeQueryBuilder currentEconomicValueUnit(String v) { currentEconomicValueUnit = v; return this; }
    public CollateralComputeQueryBuilder currentEconomicValueCurrency(String v) { currentEconomicValueCurrency = v; return this; }
    public CollateralComputeQueryBuilder allocationRate(String v) { allocationRate = decimal(v); return this; }
    public CollateralComputeQueryBuilder facilityImplementationDate(LocalDate v) { facilityImplementationDate = v; return this; }
    public CollateralComputeQueryBuilder facilityMaturityDate(LocalDate v) { facilityMaturityDate = v; return this; }
    public CollateralComputeQueryBuilder facilityAmount(String v) { facilityAmount = decimal(v); return this; }
    public CollateralComputeQueryBuilder facilityUnit(String v) { facilityUnit = v; return this; }
    public CollateralComputeQueryBuilder facilityCurrency(String v) { facilityCurrency = v; return this; }
    public CollateralComputeQueryBuilder facilityToCurrentEconomicValueCurrencyRate(String v) { facilityToCurrentEconomicValueCurrencyRate = decimal(v); return this; }
    public CollateralComputeQueryBuilder currentEconomicValueToFacilityCurrencyRate(String v) { currentEconomicValueToFacilityCurrencyRate = decimal(v); return this; }
    public CollateralComputeQueryBuilder currentEconomicCurrencyExistFlag(Boolean v) { currentEconomicCurrencyExistFlag = v; return this; }
    public CollateralComputeQueryBuilder facilityCurrencyExistFlag(Boolean v) { facilityCurrencyExistFlag = v; return this; }
    public CollateralComputeQueryBuilder currencyMismatch(String v) { currencyMismatch = decimal(v); return this; }

    public CollateralComputeQuery build() {
        return new CollateralComputeQuery(currentDate, collateralImplementationDate, collateralMaturityDate,
            proposedRecoveryRateOnCollateral, currentEconomicValue, currentEconomicValueUnit,
            currentEconomicValueCurrency, allocationRate, facilityImplementationDate, facilityMaturityDate,
            facilityAmount, facilityUnit, facilityCurrency, facilityToCurrentEconomicValueCurrencyRate,
            currentEconomicValueToFacilityCurrencyRate, currentEconomicCurrencyExistFlag, facilityCurrencyExistFlag,
            currencyMismatch);
    }

    private static BigDecimal decimal(String v) {
        return v == null ? null : new BigDecimal(v);
    }
}
