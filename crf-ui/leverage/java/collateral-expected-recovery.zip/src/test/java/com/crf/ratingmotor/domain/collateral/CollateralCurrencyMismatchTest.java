package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.CurrencyCode;
import com.crf.ratingmotor.domain.CurrencyMismatchIndicator;
import com.crf.ratingmotor.domain.CurrencyMismatchNomenclature;
import com.crf.ratingmotor.domain.DiscountCurrencyMismatchDriver;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static com.crf.ratingmotor.domain.TestValues.rv;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;

/**
 * Collateral driver #2, discount related to a currency mismatch (Dmd). The guarantee rule is reused unchanged:
 * the collateral's currentEconomicValueCurrency takes the place of the guarantee currency, and
 * currentEconomicCurrencyExistFlag the place of the guarantee "currency exists" flag.
 *
 * <pre>
 * indicator | currentEconomicCurrencyExistFlag | facilityCurrencyExistFlag | Dmd
 * 0         |                                  |                           | 0%
 * 1         | true                             | true                      | currencyMismatch
 * 1         | otherwise                        |                           | 40.87%
 * </pre>
 */
class CollateralCurrencyMismatchTest {

    private static DiscountCurrencyMismatchDriver driver(String currentEconomicValueCurrency, String facilityCurrency,
                                                         boolean currentEconomicCurrencyExistFlag,
                                                         boolean facilityCurrencyExistFlag,
                                                         String currencyMismatch) {
        RoundedValue discount = currencyMismatch == null ? null : rv(currencyMismatch);
        return new DiscountCurrencyMismatchDriver(
            new CurrencyCode(currentEconomicValueCurrency),
            new CurrencyCode(facilityCurrency),
            new CurrencyMismatchNomenclature(currentEconomicCurrencyExistFlag, facilityCurrencyExistFlag, discount));
    }

    @Nested
    @DisplayName("Calculation 1: currency mismatch indicator")
    class Indicator {

        @ParameterizedTest(name = "{0} vs {1} -> {2}")
        @CsvSource({
            "INR, INR, 0",
            "EUR, EUR, 0",
            "inr, INR, 0",
            "' USD ', usd, 0",
            "INR, EUR, 1",
            "EUR, USD, 1",
            "USD, INR, 1"
        })
        void comparesTheCollateralAndFacilityCurrencies(String collateral, String facility, int expected) {
            assertThat(driver(collateral, facility, false, false, null).indicator().getValue()).isEqualTo(expected);
        }

        @Test
        @DisplayName("The collateral currency is kept in the guarantee slot of the shared driver")
        void keepsBothCurrencies() {
            DiscountCurrencyMismatchDriver driver = driver("inr", "EUR", true, true, "0.085");
            assertThat(driver.guaranteeCurrency()).isEqualTo(new CurrencyCode("INR"));
            assertThat(driver.facilityCurrency()).isEqualTo(new CurrencyCode("EUR"));
            assertThat(driver.nomenclature().guaranteeCurrencyExists()).isTrue();
            assertThat(driver.nomenclature().facilityCurrencyExists()).isTrue();
        }
    }

    @Nested
    @DisplayName("Calculation 2: discount related to currency mismatch (Dmd)")
    class Discount {

        @ParameterizedTest(name = "same currency, flags {0}/{1}, currencyMismatch {2} -> 0%")
        @CsvSource(nullValues = "null", value = {
            "true,  true,  0.085",
            "true,  true,  null",
            "false, false, null",
            "true,  false, 0.5",
            "false, true,  null"
        })
        @DisplayName("Indicator 0: 0%, whatever the flags and the nomenclature value")
        void noMismatchIsZero(boolean collateralFlag, boolean facilityFlag, String currencyMismatch) {
            DiscountCurrencyMismatchDriver driver = driver("EUR", "EUR", collateralFlag, facilityFlag, currencyMismatch);
            assertExactly(driver.getEstimateValue(), "0");
            assertThat(driver.indicator()).isEqualTo(CurrencyMismatchIndicator.NO_MISMATCH);
        }

        @ParameterizedTest(name = "currencyMismatch {0}")
        @CsvSource({"0.085", "0", "1", "0.4087", "0.123456789"})
        @DisplayName("Indicator 1, both currencies in the nomenclature: currencyMismatch as sent")
        void bothFlagsTrueUsesTheNomenclatureValue(String currencyMismatch) {
            DiscountCurrencyMismatchDriver driver = driver("INR", "EUR", true, true, currencyMismatch);
            assertExactly(driver.getEstimateValue(), currencyMismatch);
            assertThat(driver.indicator()).isEqualTo(CurrencyMismatchIndicator.MISMATCH);
        }

        @ParameterizedTest(name = "flags {0}/{1}, currencyMismatch {2} -> 40.87%")
        @CsvSource(nullValues = "null", value = {
            "true,  false, null",
            "false, true,  null",
            "false, false, null",
            "true,  false, 0.085",
            "false, true,  0.085",
            "false, false, 0.085"
        })
        @DisplayName("Indicator 1, otherwise: 40.87%, and any currencyMismatch sent is ignored")
        void otherwiseDefaultDiscount(boolean collateralFlag, boolean facilityFlag, String currencyMismatch) {
            DiscountCurrencyMismatchDriver driver = driver("USD", "INR", collateralFlag, facilityFlag, currencyMismatch);
            assertExactly(driver.getEstimateValue(), "0.4087");
        }

        @Test
        @DisplayName("The driver is reported under the same name as for guarantees")
        void driverName() {
            assertThat(driver("INR", "EUR", false, false, null).getName())
                .isEqualTo(DiscountCurrencyMismatchDriver.NAME)
                .isEqualTo("DISCOUNT_CURRENCY_MISMATCH");
        }
    }

    @Nested
    @DisplayName("Invalid input")
    class InvalidInput {

        @Test
        @DisplayName("Currencies differ, both flags true, currencyMismatch missing: 400")
        void missingNomenclatureValue() {
            assertThatIllegalArgumentException()
                .isThrownBy(() -> driver("INR", "EUR", true, true, null))
                .withMessage("currencyMismatch is required when the currencies differ and both are in the nomenclature");
        }

        @ParameterizedTest(name = "currencyMismatch {0}")
        @CsvSource({"-0.0001", "1.0001", "40.87"})
        @DisplayName("currencyMismatch outside 0..1 is rejected, even when it would not be used")
        void currencyMismatchOutOfRange(String currencyMismatch) {
            assertThatIllegalArgumentException()
                .isThrownBy(() -> driver("EUR", "EUR", false, false, currencyMismatch))
                .withMessageStartingWith("currencyMismatch must be a fraction between 0 and 1");
        }

        @ParameterizedTest(name = "\"{0}\"")
        @CsvSource({"EU", "EURO", "E1R", "''"})
        @DisplayName("A currency that is not 3 letters is rejected")
        void invalidCurrency(String currency) {
            assertThatIllegalArgumentException()
                .isThrownBy(() -> driver(currency, "EUR", true, true, "0.085"))
                .withMessageStartingWith("Currency must be a 3-letter code");
        }
    }
}
