package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.domain.AllocationRateDriver;
import com.crf.ratingmotor.domain.CurrencyCode;
import com.crf.ratingmotor.domain.CurrencyMismatchNomenclature;
import com.crf.ratingmotor.domain.DiscountCurrencyMismatchDriver;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.MaturityAssessment;
import com.crf.ratingmotor.domain.MaturityScenarios;

import static com.crf.ratingmotor.domain.TestValues.rv;

/**
 * Builds CollateralRecoveryFactors with neutral defaults, so each test changes only what it is about.
 *
 * <p>Defaults: no maturity mismatch (Dmm 0%), collateral and facility both in EUR (Dmd 0%), neither currency in
 * the nomenclature (so a different currency alone gives Dmd 40.87%), proposed recovery rate 100%, allocation
 * rate 100%. With these defaults RecupEc equals the collateral value.</p>
 */
public final class CollateralFactorsBuilder {

    private MaturityAssessment maturity = MaturityScenarios.noMismatch();
    private String collateralCurrency = "EUR";
    private String facilityCurrency = "EUR";
    private boolean collateralCurrencyExists = false;
    private boolean facilityCurrencyExists = false;
    private String currencyMismatch = null;
    private String proposedRecoveryPercent = "100";
    private String allocationPercent = "100";

    public static CollateralFactorsBuilder factors() {
        return new CollateralFactorsBuilder();
    }

    public CollateralFactorsBuilder maturity(MaturityAssessment assessment) {
        this.maturity = assessment;
        return this;
    }

    public CollateralFactorsBuilder currencies(String collateral, String facility) {
        this.collateralCurrency = collateral;
        this.facilityCurrency = facility;
        return this;
    }

    /** Both currencies in the nomenclature, with this discount as a fraction. */
    public CollateralFactorsBuilder nomenclatureDiscount(String fraction) {
        this.collateralCurrencyExists = true;
        this.facilityCurrencyExists = true;
        this.currencyMismatch = fraction;
        return this;
    }

    public CollateralFactorsBuilder nomenclatureFlags(boolean collateralExists, boolean facilityExists) {
        this.collateralCurrencyExists = collateralExists;
        this.facilityCurrencyExists = facilityExists;
        return this;
    }

    public CollateralFactorsBuilder proposedRecoveryPercent(String percent) {
        this.proposedRecoveryPercent = percent;
        return this;
    }

    public CollateralFactorsBuilder allocationPercent(String percent) {
        this.allocationPercent = percent;
        return this;
    }

    public CollateralRecoveryFactors build() {
        return new CollateralRecoveryFactors(
            new DiscountMaturityMismatchDriver(maturity),
            new DiscountCurrencyMismatchDriver(
                new CurrencyCode(collateralCurrency), new CurrencyCode(facilityCurrency),
                new CurrencyMismatchNomenclature(collateralCurrencyExists, facilityCurrencyExists,
                    currencyMismatch == null ? null : rv(currencyMismatch))),
            new ProposedRecoveryRateDriver(rv(proposedRecoveryPercent)),
            new AllocationRateDriver(rv(allocationPercent)));
    }
}
