package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.collateral.CollateralRecoveryComputeResult;
import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.UnitAmount;
import com.crf.ratingmotor.domain.collateral.CollateralExchangeRates;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecovery;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.collateral.CollateralRecoveryFactors;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static com.crf.ratingmotor.domain.TestValues.rv;
import static com.crf.ratingmotor.domain.collateral.CollateralFactorsBuilder.factors;
import static org.assertj.core.api.Assertions.assertThat;

class CollateralExpectedRecoveryResponseTest {

    /** The BA sample computed by the real domain service. */
    private static CollateralRecoveryComputeResult sample() {
        CollateralRecoveryFactors f = factors().currencies("USD", "EUR").nomenclatureDiscount("0.174")
                                              .proposedRecoveryPercent("30").build();
        CollateralExpectedRecovery r = new CollateralExpectedRecoveryCalculatorDomainService().calculate(
            new UnitAmount(rv("66"), Unit.THOUSAND), new CollateralExchangeRates(rv("1.16"), rv("0.86")), f);
        return new CollateralRecoveryComputeResult(r, f.reportedDrivers());
    }

    @Test
    void amountsAreRoundedToTwoDecimalsWithTheirCurrency() {
        CollateralExpectedRecoveryResponse response = CollateralExpectedRecoveryResponse.from(sample());

        assertThat(response.expectedRecoveryOnCollateral().amount()).isEqualTo(new BigDecimal("16315.55"));
        assertThat(response.expectedRecoveryOnCollateral().currency()).isEqualTo("USD");
        assertThat(response.expectedRecoveryInCollateralCurrency().amount()).isEqualTo(new BigDecimal("16315.55"));
        assertThat(response.expectedRecoveryInCollateralCurrency().currency()).isEqualTo("USD");
        assertThat(response.expectedRecoveryInFacilityCurrency().amount()).isEqualTo(new BigDecimal("14031.37"));
        assertThat(response.expectedRecoveryInFacilityCurrency().currency()).isEqualTo("EUR");
    }

    @Test
    void rateIsRoundedToSixDecimals() {
        assertThat(CollateralExpectedRecoveryResponse.from(sample()).recoveryRateOnCollateralPercent())
            .isEqualTo(new BigDecimal("24.720528"));
    }

    @Test
    void driversAreNamedAndRoundedToSixDecimals() {
        CollateralExpectedRecoveryResponse response = CollateralExpectedRecoveryResponse.from(sample());

        assertThat(response.drivers()).hasSize(2);
        assertThat(response.drivers().get(0).name()).isEqualTo("DISCOUNT_MATURITY_MISMATCH");
        assertThat(response.drivers().get(0).value()).isEqualTo(new BigDecimal("0.000000"));
        assertThat(response.drivers().get(1).name()).isEqualTo("DISCOUNT_CURRENCY_MISMATCH");
        assertThat(response.drivers().get(1).value()).isEqualTo(new BigDecimal("0.174000"));
    }
}
