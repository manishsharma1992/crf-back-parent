package com.crf.ratingmotor.application.creditinsurer;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Test builder for CreditInsurerComputeQuery. Defaults are the worked example: 10 MILLION facility, 80% covered,
 * ECA policy with the OECD flag, 31-90 days with interest covered, credit insurer 3+ and guarantor 5-
 * (coefficient 95%), no maturity mismatch. RecupEAC = 6,771,600.
 */
public final class CreditInsurerComputeQueryBuilder {

    private LocalDate currentDate = LocalDate.of(2026, 11, 22);
    private LocalDate creditInsurerImplementationDate = LocalDate.of(2025, 1, 1);
    private LocalDate creditInsurerMaturityDate = LocalDate.of(2031, 1, 1);
    private String creditInsurerType = "Insurance policy from ECA";
    private String creditInsurerCounterpartyRating = "3+";
    private Boolean oecdFlag = true;
    private Boolean positiveRecoveryFlag = false;
    private Boolean waitingPeriodInterestCovered = true;
    private String waitingPeriod = "31-90 D";
    private BigDecimal pctOfBnppFinancingCoveredByCreditInsurer = new BigDecimal("80");
    private Boolean prorataShareOfExpectedRecovery = false;
    private BigDecimal sugrr = new BigDecimal("50");
    private LocalDate facilityImplementationDate = LocalDate.of(2025, 1, 1);
    private LocalDate facilityMaturityDate = LocalDate.of(2030, 1, 1);
    private BigDecimal facilityAmount = new BigDecimal("10");
    private String facilityUnit = "MILLION";
    private String guarantorCounterpartyRating = "5-";

    public static CreditInsurerComputeQueryBuilder creditInsurerQuery() {
        return new CreditInsurerComputeQueryBuilder();
    }

    public CreditInsurerComputeQueryBuilder currentDate(LocalDate v) { currentDate = v; return this; }
    public CreditInsurerComputeQueryBuilder creditInsurerImplementationDate(LocalDate v) { creditInsurerImplementationDate = v; return this; }
    public CreditInsurerComputeQueryBuilder creditInsurerMaturityDate(LocalDate v) { creditInsurerMaturityDate = v; return this; }
    public CreditInsurerComputeQueryBuilder creditInsurerType(String v) { creditInsurerType = v; return this; }
    public CreditInsurerComputeQueryBuilder creditInsurerCounterpartyRating(String v) { creditInsurerCounterpartyRating = v; return this; }
    public CreditInsurerComputeQueryBuilder oecdFlag(Boolean v) { oecdFlag = v; return this; }
    public CreditInsurerComputeQueryBuilder positiveRecoveryFlag(Boolean v) { positiveRecoveryFlag = v; return this; }
    public CreditInsurerComputeQueryBuilder waitingPeriodInterestCovered(Boolean v) { waitingPeriodInterestCovered = v; return this; }
    public CreditInsurerComputeQueryBuilder waitingPeriod(String v) { waitingPeriod = v; return this; }
    public CreditInsurerComputeQueryBuilder pctOfBnppFinancingCoveredByCreditInsurer(String v) { pctOfBnppFinancingCoveredByCreditInsurer = decimal(v); return this; }
    public CreditInsurerComputeQueryBuilder facilityImplementationDate(LocalDate v) { facilityImplementationDate = v; return this; }
    public CreditInsurerComputeQueryBuilder facilityMaturityDate(LocalDate v) { facilityMaturityDate = v; return this; }
    public CreditInsurerComputeQueryBuilder facilityAmount(String v) { facilityAmount = decimal(v); return this; }
    public CreditInsurerComputeQueryBuilder facilityUnit(String v) { facilityUnit = v; return this; }
    public CreditInsurerComputeQueryBuilder guarantorCounterpartyRating(String v) { guarantorCounterpartyRating = v; return this; }

    public CreditInsurerComputeQuery build() {
        return new CreditInsurerComputeQuery(currentDate, creditInsurerImplementationDate, creditInsurerMaturityDate,
            creditInsurerType, creditInsurerCounterpartyRating, oecdFlag, positiveRecoveryFlag,
            waitingPeriodInterestCovered, waitingPeriod, pctOfBnppFinancingCoveredByCreditInsurer,
            prorataShareOfExpectedRecovery, sugrr,
            facilityImplementationDate, facilityMaturityDate, facilityAmount, facilityUnit, guarantorCounterpartyRating);
    }

    private static BigDecimal decimal(String v) {
        return v == null ? null : new BigDecimal(v);
    }
}
