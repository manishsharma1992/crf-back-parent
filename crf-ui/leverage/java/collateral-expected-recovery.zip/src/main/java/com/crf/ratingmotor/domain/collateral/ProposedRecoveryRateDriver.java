package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.PercentageDriver;

/**
 * The analyst's proposed recovery rate on the collateral, sent as a percent (0..100) and used as a fraction.
 * Applied in RecupEc but, like the allocation rate, not reported as a driver.
 */
public final class ProposedRecoveryRateDriver extends PercentageDriver {
    public static final String NAME = "PROPOSED_RECOVERY_RATE";
    public ProposedRecoveryRateDriver(RoundedValue percent) { super(NAME, percent); }
}
