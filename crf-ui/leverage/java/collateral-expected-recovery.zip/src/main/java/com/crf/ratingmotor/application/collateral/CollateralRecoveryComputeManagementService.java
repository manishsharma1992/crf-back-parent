package com.crf.ratingmotor.application.collateral;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.common.Unit;
import com.crf.ratingmotor.domain.AllocationRateDriver;
import com.crf.ratingmotor.domain.CurrencyCode;
import com.crf.ratingmotor.domain.CurrencyMismatchNomenclature;
import com.crf.ratingmotor.domain.DayCountConvention;
import com.crf.ratingmotor.domain.DiscountCurrencyMismatchDriver;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.MaturityAssessment;
import com.crf.ratingmotor.domain.MaturityDates;
import com.crf.ratingmotor.domain.UnitAmount;
import com.crf.ratingmotor.domain.collateral.CollateralExchangeRates;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecoveryCalculatorDomainService;
import com.crf.ratingmotor.domain.collateral.CollateralRecoveryFactors;
import com.crf.ratingmotor.domain.collateral.ProposedRecoveryRateDriver;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Objects;

import static com.crf.ratingmotor.application.RequiredValues.required;
import static com.crf.ratingmotor.application.RequiredValues.requiredFlag;

/**
 * Application service for the collateral expected recovery: translates the request into domain types, builds
 * Driver #1 (Dmm) and Driver #2 (Dmd) and delegates to the domain service. No business rules of its own.
 *
 * <p>facilityAmount and facilityUnit are validated by the request but appear in no formula, so they are not
 * mapped into the domain (open point in the change log).</p>
 */
@Service
@RequiredArgsConstructor
public class CollateralRecoveryComputeManagementService {

    private final DayCountConvention dayCountConvention;                 // ACT_365_FIXED, shared with guarantees
    private final CollateralExpectedRecoveryCalculatorDomainService calculator;

    public CollateralRecoveryComputeResult compute(CollateralComputeQuery query) {
        Objects.requireNonNull(query, "query");

        CollateralRecoveryFactors factors = new CollateralRecoveryFactors(
            maturityDriver(query),
            currencyDriver(query),
            new ProposedRecoveryRateDriver(
                required(query.proposedRecoveryRateOnCollateral(), "proposedRecoveryRateOnCollateral")),
            new AllocationRateDriver(required(query.allocationRate(), "allocationRate")));

        UnitAmount currentEconomicValue = new UnitAmount(
            required(query.currentEconomicValue(), "currentEconomicValue"),
            Unit.from(query.currentEconomicValueUnit()));

        CollateralExchangeRates rates = new CollateralExchangeRates(
            optional(query.facilityToCurrentEconomicValueCurrencyRate()),
            optional(query.currentEconomicValueToFacilityCurrencyRate()));

        return new CollateralRecoveryComputeResult(
            calculator.calculate(currentEconomicValue, rates, factors), factors.reportedDrivers());
    }

    private DiscountMaturityMismatchDriver maturityDriver(CollateralComputeQuery query) {
        MaturityDates dates = MaturityDates.forCollateral(
            query.currentDate(),
            query.collateralImplementationDate(), query.collateralMaturityDate(),
            query.facilityImplementationDate(), query.facilityMaturityDate());
        return new DiscountMaturityMismatchDriver(MaturityAssessment.of(dates, dayCountConvention));
    }

    private static DiscountCurrencyMismatchDriver currencyDriver(CollateralComputeQuery query) {
        CurrencyMismatchNomenclature nomenclature = new CurrencyMismatchNomenclature(
            requiredFlag(query.currentEconomicCurrencyExistFlag(), "currentEconomicCurrencyExistFlag"),
            requiredFlag(query.facilityCurrencyExistFlag(), "facilityCurrencyExistFlag"),
            optional(query.currencyMismatch()));
        return new DiscountCurrencyMismatchDriver(
            new CurrencyCode(query.currentEconomicValueCurrency()),
            new CurrencyCode(query.facilityCurrency()),
            nomenclature);
    }

    private static RoundedValue optional(BigDecimal value) {
        return value == null ? null : RoundedValue.of(value);
    }
}
