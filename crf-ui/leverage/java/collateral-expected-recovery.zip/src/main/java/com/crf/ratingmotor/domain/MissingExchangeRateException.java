package com.crf.ratingmotor.domain;

/** A currency mismatch whose exchange rate was not sent: a client error (400). */
public final class MissingExchangeRateException extends IllegalArgumentException {

    /** For a guarantee: "... when the guarantee and facility currencies differ". */
    public MissingExchangeRateException(String rateName) {
        this(rateName, "guarantee");
    }

    /**
     * @param rateName   the request field that is missing
     * @param protection what the facility currency is compared with, as named in the message ("collateral")
     */
    public MissingExchangeRateException(String rateName, String protection) {
        super(rateName + " is required when the " + protection + " and facility currencies differ");
    }
}
