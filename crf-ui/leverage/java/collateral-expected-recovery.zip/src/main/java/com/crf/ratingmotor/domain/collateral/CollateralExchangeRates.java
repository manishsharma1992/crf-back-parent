package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.MissingExchangeRateException;

/**
 * The two exchange rates between the collateral currency (currentEconomicValueCurrency) and the facility
 * currency. Both are optional: they are only needed when the two currencies differ, and a missing one is
 * reported only then, with the request field name.
 *
 * @param facilityToCurrentEconomicValue  facilityToCurrentEconomicValueCurrencyRate
 * @param currentEconomicValueToFacility  currentEconomicValueToFacilityCurrencyRate
 */
public record CollateralExchangeRates(RoundedValue facilityToCurrentEconomicValue,
                                      RoundedValue currentEconomicValueToFacility) {

    static final String FACILITY_TO_CURRENT_ECONOMIC_VALUE = "facilityToCurrentEconomicValueCurrencyRate";
    static final String CURRENT_ECONOMIC_VALUE_TO_FACILITY = "currentEconomicValueToFacilityCurrencyRate";

    public CollateralExchangeRates {
        requirePositiveWhenPresent(facilityToCurrentEconomicValue, FACILITY_TO_CURRENT_ECONOMIC_VALUE);
        requirePositiveWhenPresent(currentEconomicValueToFacility, CURRENT_ECONOMIC_VALUE_TO_FACILITY);
    }

    /** No rates: for a collateral in the facility currency. */
    public static CollateralExchangeRates none() {
        return new CollateralExchangeRates(null, null);
    }

    RoundedValue requiredFacilityToCurrentEconomicValue() {
        return required(facilityToCurrentEconomicValue, FACILITY_TO_CURRENT_ECONOMIC_VALUE);
    }

    RoundedValue requiredCurrentEconomicValueToFacility() {
        return required(currentEconomicValueToFacility, CURRENT_ECONOMIC_VALUE_TO_FACILITY);
    }

    private static RoundedValue required(RoundedValue rate, String name) {
        if (rate == null) {
            throw new MissingExchangeRateException(name, "collateral");
        }
        return rate;
    }

    private static void requirePositiveWhenPresent(RoundedValue rate, String name) {
        if (rate != null && !rate.isGreaterThan(RoundedValue.ZERO)) {
            throw new IllegalArgumentException(name + " must be positive: " + rate);
        }
    }
}
