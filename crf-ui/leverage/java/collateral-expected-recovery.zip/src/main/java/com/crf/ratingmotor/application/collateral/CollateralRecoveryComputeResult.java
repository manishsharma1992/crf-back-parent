package com.crf.ratingmotor.application.collateral;

import com.crf.ratingmotor.domain.Driver;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecovery;

import java.util.List;

public record CollateralRecoveryComputeResult(CollateralExpectedRecovery recovery, List<Driver> drivers) {}
