package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.CurrencyCode;

/**
 * Results of the collateral expected recovery.
 *
 * @param expectedRecoveryOnCollateral          RecupEc
 * @param recoveryRateOnCollateralPercent       RecupTc, 0 to 100
 * @param expectedRecoveryInCollateralCurrency  RecupEc_G, in {@code collateralCurrency}
 * @param collateralCurrency                    currentEconomicValueCurrency
 * @param expectedRecoveryInFacilityCurrency    RecupEc_F, in {@code facilityCurrency}
 * @param facilityCurrency                      facilityCurrency
 */
public record CollateralExpectedRecovery(RoundedValue expectedRecoveryOnCollateral,
                                         RoundedValue recoveryRateOnCollateralPercent,
                                         RoundedValue expectedRecoveryInCollateralCurrency,
                                         CurrencyCode collateralCurrency,
                                         RoundedValue expectedRecoveryInFacilityCurrency,
                                         CurrencyCode facilityCurrency) {}
