package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.collateral.CollateralRecoveryComputeResult;
import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.CurrencyCode;
import com.crf.ratingmotor.domain.collateral.CollateralExpectedRecovery;
import com.crf.ratingmotor.exposition.ExpectedRecoveryResponse.AmountWithCurrency;
import com.crf.ratingmotor.exposition.ExpectedRecoveryResponse.DriverValue;
import io.swagger.v3.oas.annotations.media.Schema;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Schema(description = "Expected recovery on the collateral and the drivers used to compute it")
public record CollateralExpectedRecoveryResponse(
    @Schema(description = "RecupEc: expected recovery on the collateral, in the collateral currency")
    AmountWithCurrency expectedRecoveryOnCollateral,
    @Schema(description = "RecupTc: recovery rate on the collateral, percent 0..100")
    BigDecimal recoveryRateOnCollateralPercent,
    @Schema(description = "RecupEc_G: expected recovery in the collateral currency (currentEconomicValueCurrency)")
    AmountWithCurrency expectedRecoveryInCollateralCurrency,
    @Schema(description = "RecupEc_F: expected recovery in the facility currency")
    AmountWithCurrency expectedRecoveryInFacilityCurrency,
    @Schema(description = "Drivers used (DISCOUNT_MATURITY_MISMATCH, DISCOUNT_CURRENCY_MISMATCH), values as fractions")
    List<DriverValue> drivers) {

    private static final int AMOUNT_SCALE = 2;
    private static final int RATE_SCALE = 6;

    public static CollateralExpectedRecoveryResponse from(CollateralRecoveryComputeResult result) {
        CollateralExpectedRecovery r = result.recovery();
        return new CollateralExpectedRecoveryResponse(
            amount(r.expectedRecoveryOnCollateral(), r.collateralCurrency()),
            scaled(r.recoveryRateOnCollateralPercent(), RATE_SCALE),
            amount(r.expectedRecoveryInCollateralCurrency(), r.collateralCurrency()),
            amount(r.expectedRecoveryInFacilityCurrency(), r.facilityCurrency()),
            result.drivers().stream()
                  .map(d -> new DriverValue(d.getName(), scaled(d.getEstimateValue(), RATE_SCALE)))
                  .toList());
    }

    private static AmountWithCurrency amount(RoundedValue value, CurrencyCode currency) {
        return new AmountWithCurrency(scaled(value, AMOUNT_SCALE), currency.value());
    }

    private static BigDecimal scaled(RoundedValue value, int scale) {
        return value.getValue().setScale(scale, RoundingMode.HALF_UP);
    }
}
