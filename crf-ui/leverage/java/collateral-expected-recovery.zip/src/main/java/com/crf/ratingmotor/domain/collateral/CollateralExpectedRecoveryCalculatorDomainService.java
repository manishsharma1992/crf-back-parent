package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.Driver;
import com.crf.ratingmotor.domain.UnitAmount;

import java.util.Objects;

/**
 * Domain service that computes the expected recovery on a collateral.
 *
 * <p>V is the collateral value, {@code currentEconomicValue x currentEconomicValueUnit}.</p>
 * <ol>
 *   <li><b>RecupEc</b>, expected recovery on the collateral:
 *       {@code V x proposedRecoveryRate x (1 - Dmm) x (1 - Dmd) x allocationRate}. When the collateral and
 *       facility currencies differ, V is first multiplied by
 *       {@code facilityToCurrentEconomicValueCurrencyRate x currentEconomicValueToFacilityCurrencyRate},
 *       as the specification writes it (the same double conversion as for guarantees).</li>
 *   <li><b>RecupTc</b>, recovery rate on the collateral: {@code RecupEc / V x 100}.</li>
 *   <li><b>RecupEc_G</b>, expected recovery in the collateral currency: {@code V x RecupTc / 100}.</li>
 *   <li><b>RecupEc_F</b>, expected recovery in the facility currency:
 *       {@code RecupEc_G x currentEconomicValueToFacilityCurrencyRate} when the currencies differ,
 *       otherwise RecupEc_G.</li>
 * </ol>
 *
 * <p>If the collateral starts after the facility and has not started yet, RecupEc and RecupTc are 0. If V is 0,
 * RecupTc is 0, because the rate is undefined (an assumption, logged in the change log).</p>
 *
 * <p>The proposed recovery rate, the allocation rate and the drivers are fractions, so the specification's
 * {@code x / 100} and {@code (1 - x / 100)} are {@code x} and {@code (1 - x)} here.
 * Framework-free and stateless; registered as a bean in configuration.</p>
 */
public final class CollateralExpectedRecoveryCalculatorDomainService {

    private static final RoundedValue HUNDRED = RoundedValue.of(100);

    public CollateralExpectedRecovery calculate(UnitAmount currentEconomicValue, CollateralExchangeRates rates,
                                                CollateralRecoveryFactors factors) {
        Objects.requireNonNull(currentEconomicValue, "currentEconomicValue");
        Objects.requireNonNull(rates, "rates");
        Objects.requireNonNull(factors, "factors");

        RoundedValue collateralValue = currentEconomicValue.baseAmount();

        RoundedValue recupEc  = expectedRecovery(collateralValue, rates, factors);
        RoundedValue recupTc  = recoveryRatePercent(recupEc, collateralValue, factors);
        RoundedValue recupEcG = recoveryInCollateralCurrency(collateralValue, recupTc);
        RoundedValue recupEcF = recoveryInFacilityCurrency(recupEcG, rates, factors);

        return new CollateralExpectedRecovery(
            recupEc,
            recupTc,
            recupEcG, factors.currency().guaranteeCurrency(),
            recupEcF, factors.currency().facilityCurrency());
    }

    private static RoundedValue expectedRecovery(RoundedValue collateralValue, CollateralExchangeRates rates,
                                                 CollateralRecoveryFactors factors) {
        if (factors.collateralNotYetStarted()) {
            return RoundedValue.ZERO;
        }
        return exposure(collateralValue, rates, factors)
            .multiply(factors.proposedRecoveryRate().getEstimateValue())
            .multiply(complement(factors.maturity()))
            .multiply(complement(factors.currency()))
            .multiply(factors.allocation().getEstimateValue());
    }

    private static RoundedValue exposure(RoundedValue collateralValue, CollateralExchangeRates rates,
                                         CollateralRecoveryFactors factors) {
        if (!factors.currenciesDiffer()) {
            return collateralValue;
        }
        return collateralValue
            .multiply(rates.requiredFacilityToCurrentEconomicValue())
            .multiply(rates.requiredCurrentEconomicValueToFacility());
    }

    private static RoundedValue recoveryRatePercent(RoundedValue recupEc, RoundedValue collateralValue,
                                                    CollateralRecoveryFactors factors) {
        if (factors.collateralNotYetStarted() || !collateralValue.isGreaterThan(RoundedValue.ZERO)) {
            return RoundedValue.ZERO;
        }
        return recupEc.divide(collateralValue).multiply(HUNDRED);
    }

    private static RoundedValue recoveryInCollateralCurrency(RoundedValue collateralValue, RoundedValue recupTc) {
        return collateralValue.multiply(recupTc.divide(HUNDRED));
    }

    private static RoundedValue recoveryInFacilityCurrency(RoundedValue recupEcG, CollateralExchangeRates rates,
                                                           CollateralRecoveryFactors factors) {
        if (!factors.currenciesDiffer()) {
            return recupEcG;
        }
        return recupEcG.multiply(rates.requiredCurrentEconomicValueToFacility());
    }

    private static RoundedValue complement(Driver discount) {
        return RoundedValue.ONE.subtract(discount.getEstimateValue());
    }
}
