package com.crf.ratingmotor.domain.collateral;

import com.crf.ratingmotor.domain.AllocationRateDriver;
import com.crf.ratingmotor.domain.CurrencyMismatchIndicator;
import com.crf.ratingmotor.domain.DiscountCurrencyMismatchDriver;
import com.crf.ratingmotor.domain.DiscountMaturityMismatchDriver;
import com.crf.ratingmotor.domain.Driver;

import java.util.List;
import java.util.Objects;

/**
 * What scales the collateral value in RecupEc: the two drivers (Dmm, Dmd) and the two analyst inputs
 * (proposed recovery rate, allocation rate).
 */
public record CollateralRecoveryFactors(DiscountMaturityMismatchDriver maturity,
                                        DiscountCurrencyMismatchDriver currency,
                                        ProposedRecoveryRateDriver proposedRecoveryRate,
                                        AllocationRateDriver allocation) {
    public CollateralRecoveryFactors {
        Objects.requireNonNull(maturity, "maturity");
        Objects.requireNonNull(currency, "currency");
        Objects.requireNonNull(proposedRecoveryRate, "proposedRecoveryRate");
        Objects.requireNonNull(allocation, "allocation");
    }

    /**
     * The drivers returned with the result: Driver #1 (Dmm) and Driver #2 (Dmd). The proposed recovery rate and
     * the allocation rate are inputs the analyst entered, so, as for guarantees, they are applied but not reported.
     */
    public List<Driver> reportedDrivers() {
        return List.of(maturity, currency);
    }

    /** Collateral that starts after the facility and has not started yet. */
    boolean collateralNotYetStarted() {
        return maturity.assessment().guaranteeNotYetStarted();
    }

    /** currencyMismatchFlag = 1: currentEconomicValueCurrency differs from facilityCurrency. */
    boolean currenciesDiffer() {
        return currency.indicator() == CurrencyMismatchIndicator.MISMATCH;
    }
}
