package com.crf.ratingmotor.exposition;

import com.crf.ratingmotor.application.collateral.CollateralComputeQuery;
import com.crf.ratingmotor.application.collateral.CollateralRecoveryComputeManagementService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Tag(name = "BIRD SUGRR", description = "Expected recovery on guarantees, credit insurance and collateral")
public class CollateralComputeController {

    private final CollateralRecoveryComputeManagementService computeService;

    @Operation(summary = "Compute the expected recovery amount on a collateral",
               description = "Computes RecupEc, RecupTc, RecupEc_G and RecupEc_F and returns the drivers used.")
    @ApiResponse(responseCode = "200", description = "Expected recovery computed")
    @ApiResponse(responseCode = "400", description = "Invalid request",
                 content = @Content(schema = @Schema(implementation = ProblemDetail.class)))
    @ApiResponse(responseCode = "500", description = "Unexpected server error",
                 content = @Content(schema = @Schema(implementation = ProblemDetail.class)))
    @PostMapping(path = "calculate/collateralExpectedRecoveryAmount",
                 consumes = MediaType.APPLICATION_JSON_VALUE,
                 produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CollateralExpectedRecoveryResponse> calculateCollateralExpectedRecoveryAmount(
            @Valid @RequestBody CollateralComputeQuery query) {
        return ResponseEntity.ok(CollateralExpectedRecoveryResponse.from(computeService.compute(query)));
    }
}
