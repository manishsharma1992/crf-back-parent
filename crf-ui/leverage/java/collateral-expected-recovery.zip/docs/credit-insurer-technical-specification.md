# Credit insurer expected recovery: technical specification

> **How to use this page in Confluence.** Paste the text with *Insert → Markup → Markdown*. Upload the PNG files from `png/` as page attachments; each image below is referenced by its file name. The editable PlantUML source of every diagram is in `credit-insurer-diagrams.puml` (one `@startuml` block per PlantUML macro).

| | |
|---|---|
| Module | crf-rating-motor |
| Caller | crf-back |
| Endpoint | `POST calculate/creditInsurerExpectedRecoveryAmount` |
| Stack | Java 17, Spring Boot 3.0, PostgreSQL, Caffeine |
| Related | Guarantee expected recovery (same module, shares several building blocks) |

---

## 1. In plain words

When a credit insurer covers part of a loan, the bank needs to know how much it can realistically expect to recover from that insurance if the borrower defaults. The insurance rarely pays back its full face value.

The rating motor first works out how much of the loan the credit insurer covers (**Gac**). It then reduces that amount with four factors, called **drivers**:

- **Correlation coefficient:** how much of the cover counts, given the credit insurer's rating and the guarantor's rating.
- **Maturity mismatch discount (Dmm):** a discount when the credit insurance ends before the loan does.
- **Waiting period decote (Ddci):** a discount for the time the bank waits before the insurer pays.
- **Additional decote (Dfe):** a 10% discount for some types of credit insurance.

The result is the **expected recovery on the credit insurer**, the **recovery rate** as a percentage of the covered amount, and the expected recovery in the facility's currency. The four drivers are returned with it, so anyone can see why the number came out the way it did.

---

## 2. What happens to a request

![Credit insurer: what happens to a request](png/ci-01-overview.png)

crf-back sends one request. The rating motor checks every field, works out the four drivers and the covered amount, combines them, and sends the answer back. The correlation table is the only input read from the database, and it is kept in memory after the first read.

### The same request, step by step

![Credit insurer: one request, step by step](png/ci-02-sequence.png)

| Step | What happens |
|---|---|
| 1–2 | The controller receives the JSON and Bean Validation checks presence, formats and ranges. |
| 3 | Anything wrong returns 400 with the list of invalid fields, before any calculation. |
| 4–5 | The management service converts text into domain types: credit insurer type, waiting period, unit and both ratings. |
| 6–10 | The 6 × 10 correlation table is read from the cache, or once from the database and checked to be complete. |
| 11–12 | The four drivers are built. |
| 13 | The covered amount Gac is built from the facility amount, its unit and the covered percentage. |
| 14–17 | The domain service calculates the four results; the response is rounded and returned. |

---

## 3. The four drivers

All drivers are numbers between 0 and 1. The correlation coefficient says how much of the cover counts; the other three are discounts that take something away. The specification writes the formulas with percentages (`1 − x / 100`); the code stores every driver as a fraction, so the same formula is `1 − x`.

| Driver | Name in the response | Values |
|---|---|---|
| Correlation coefficient | `CORRELATION_COEFFICIENT` | From the 6 × 10 table, or 0 when the credit insurer is rated above 6 |
| Maturity mismatch | `DISCOUNT_MATURITY_MISMATCH` | 0%, 100%, or 1 − MIN(1; (t − 0.25)/(T − 0.25)) |
| Waiting period decote (Ddci) | `WAITING_PERIOD_DECOTE` | 0%, 1%, 2% or 3% |
| Additional decote (Dfe) | `ADDITIONAL_DECOTE` | 0% or 10% |

### 3.1 Driver 1: correlation coefficient

![Driver 1: correlation coefficient](png/ci-08-driver-correlation.png)

The credit insurer's rating picks the row (1 to 6) and the guarantor's rating picks the column (1 to 10). Ratings arrive as `1`, `1+`, `1-` … `10-`; the sign is dropped, so `1-` and `6+` read cell [1, 6]. A credit insurer rated 7 to 10 has no row in the table, and its coefficient is 0 (confirmed by Clara).

**Correlation table (values in %; stored as fractions, 92.0 is stored as 0.92)**

| Credit insurer \ Guarantor | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|---|---|---|---|---|---|---|---|---|---|---|
| **1** | 100 | 100 | 100 | 100 | 100 | 100 | 100 | 100 | 100 | 100 |
| **2** | 100 | 100 | 100 | 100 | 100 | 100 | 100 | 100 | 100 | 100 |
| **3** | 0 | 0 | 0 | 92.0 | 95.0 | 98.0 | 99.0 | 99.1 | 99.2 | 99.3 |
| **4** | 0 | 0 | 0 | 0 | 91.0 | 96.0 | 98.0 | 99.0 | 99.1 | 99.2 |
| **5** | 0 | 0 | 0 | 0 | 0 | 91.0 | 97.0 | 98.6 | 99.0 | 99.1 |
| **6** | 0 | 0 | 0 | 0 | 0 | 0 | 91.0 | 92.0 | 93.0 | 93.1 |
| **7 to 10** | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

The last row is not stored; it is the rule for ratings above 6.

### 3.2 Driver 2: maturity mismatch discount (Dmm)

![Driver 2: maturity mismatch discount](png/ci-09-driver-maturity.png)

This is exactly the guarantee rule, reused unchanged. `MaturityDates.forCreditInsurance(...)` puts the credit insurer's start and end dates where the guarantee's dates go, so the existing `MaturityAssessment` and `DiscountMaturityMismatchDriver` work as they are, and any later fix to the rule applies to both products.

- **Residual maturity of the facility:** how long the loan still has to run, from today or from its start date if later.
- **Residual maturity of the credit insurance:** how long the cover still has to run, from the latest of its start date, today and the loan's start date.
- **Initial maturity of the credit insurance:** how long the cover runs in total, from the later of its start date and the loan's start date.

Years are actual days divided by 365 (ACT/365 Fixed), the same setting as for guarantees.

### 3.3 Driver 3: waiting period decote (Ddci)

![Driver 3: waiting period decote](png/ci-10-driver-waiting-period.png)

| Condition | Ddci |
|---|---|
| Waiting-period interest not covered | 0% |
| Type is "Guarantee at 1rt demand SBLC" | 0% |
| Otherwise, waiting period under 31 days | 0% |
| 31 to 90 days | 1% |
| 91 to 210 days | 2% |
| More than 210 days | 3% |

Each waiting period carries its own decote in the `WaitingPeriod` enum, so the table lives in one place.

### 3.4 Driver 4: additional decote (Dfe)

![Driver 4: additional decote](png/ci-11-driver-additional.png)

| Credit insurer type | Condition | Dfe |
|---|---|---|
| Insurance policy from ECA | OECD flag or positive recovery flag is true | 10% |
| Insurance policy from ECA | both flags false | 0% |
| First demand Guarantee | always | 10% |
| Insurance policy from private insurer | always | 10% |
| Any other type | whatever the flags | 0% |

---

## 4. The recovery calculation

![The credit insurer recovery calculation](png/ci-12-recovery-calculation.png)

| Result | Name in the response | Formula |
|---|---|---|
| Gac | `facilityAmountCoveredByCreditInsurer` | facilityAmount × facilityUnit × pctOfBnppFinancingCoveredByCreditInsurer / 100 |
| RecupEAC | `expectedRecoveryOnCreditInsurer` | Gac × (1 − Dmm) × (1 − Ddci) × (1 − Dfe) × correlation coefficient |
| RecupTAC | `recoveryRateOnCreditInsurerPercent` | RecupEAC / Gac × 100 |
| RecupEAC_F | `expectedRecoveryInFacilityCurrency` | RecupEAC |

**Special cases**

- **Credit insurance not started yet** (it starts after the facility and today is before its start): RecupEAC, RecupTAC and RecupEAC_F are 0. Gac is still returned.
- **Gac is 0** (a facility amount of 0, or 0% covered): RecupTAC would be 0 / 0, so it is returned as 0.

### Worked example

| Step | Value | Why |
|---|---|---|
| Facility | 10 MILLION = 10,000,000 | Amount × unit |
| Gac | **8,000,000** | 80% covered by the credit insurer |
| Maturity mismatch | × (1 − 0) | Cover (2031) outlasts the loan (2030) |
| Waiting period decote | × (1 − 0.01) | Interest covered, 31-90 days |
| Additional decote | × (1 − 0.10) | Insurance policy from ECA with the OECD flag |
| Correlation coefficient | × 0.95 | Credit insurer 3+, guarantor 5- |
| **RecupEAC** | **6,771,600.00** | Expected recovery on the credit insurer |
| **RecupTAC** | **84.645 %** | 6,771,600 ÷ 8,000,000 × 100 |
| **RecupEAC_F** | **6,771,600.00** | Equal to RecupEAC |

---

## 5. How the code is organised

The code follows the same domain-driven design as the guarantee calculation. The business rules sit in the **domain** layer, written in plain Java with no framework, database or web code. The other layers depend on the domain, never the other way round.

### 5.1 Exposition layer

![Exposition layer](png/ci-03-layer-exposition.png)

| Class | Responsibility |
|---|---|
| `CreditInsurerComputeController` | `POST calculate/creditInsurerExpectedRecoveryAmount`; validates the body with `@Valid` and returns the response |
| `CreditInsurerExpectedRecoveryResponse` | The JSON answer; rounds amounts to 2 decimals and the rate and drivers to 6, HALF_UP |
| Exception handler (existing) | Now scoped to both controllers: 400 for validation, malformed JSON and domain rules; 500 for anything else, without internal details |

### 5.2 Application layer

![Application layer](png/ci-04-layer-application.png)

| Class | Responsibility |
|---|---|
| `CreditInsurerComputeQuery` | The request, with Bean Validation and Swagger examples |
| `CreditInsurerRecoveryComputeManagementService` | Translates the request into domain types, builds the drivers and the coverage, calls the domain service. No business rules |
| `CreditInsurerRecoveryComputeResult` | The four results and the drivers |
| `RequiredValues` (shared) | `required` and `requiredFlag`: a missing value becomes a 400 naming the field |

### 5.3 Domain layer

![Domain layer](png/ci-05-layer-domain.png)

| Class | Responsibility |
|---|---|
| `CreditInsurerCorrelationMatrix` | The 6 × 10 table; 0 for credit insurer ratings above 6 |
| `RatingGrid` (shared) | A validated, immutable table addressed by two ratings, any size up to 10 × 10 |
| `CreditInsurerCorrelationCoefficientDriver` | Driver 1 |
| `MaturityDates.forCreditInsurance`, `MaturityAssessment`, `DiscountMaturityMismatchDriver` (shared) | Driver 2, reused from guarantees |
| `WaitingPeriodDecoteDriver`, `WaitingPeriod` | Driver 3 |
| `AdditionalDecoteDriver`, `CreditInsurerType` | Driver 4 |
| `CreditInsuranceCoverage` | Gac, with the covered percentage checked to be 0..100 |
| `CreditInsurerRecoveryFactors` | The four drivers, in the order they are reported |
| `CreditInsurerExpectedRecoveryCalculatorDomainService` | RecupEAC, RecupTAC, RecupEAC_F |
| `CreditInsurerCorrelationMatrixRepository` | Port: where the table comes from |

### 5.4 Infrastructure layer

![Infrastructure layer](png/ci-06-layer-infrastructure.png)

| Class | Responsibility |
|---|---|
| `CachingCreditInsurerCorrelationMatrixRepository` | `@Primary`; serves the table from the Caffeine cache `creditInsurerCorrelationMatrix` under one fixed key |
| `CreditInsurerCorrelationMatrixRepositoryImpl` | Reads the 60 rows and builds the table. No rows, a missing cell or a rating out of range in the database is a server error (500) |
| `CreditInsurerCorrelationCoefficientDao` | Spring Data repository |
| `CreditInsurerCorrelationCoefficientEntity` | One cell of the table |

---

## 6. Data model

![Credit insurer coefficient table](png/ci-07-data-model.png)

The credit insurer table has its own database table, because its shape differs from the guarantee table (6 × 10, no LOW/HIGH split). The column is named `coefficient` rather than `value`, which is a reserved word in H2.

| Constraint | Protects against |
|---|---|
| Primary key `id` | Technical identity of each row |
| Unique (credit_insurer_rating, guarantor_rating) | Two values for the same cell |
| Credit insurer rating 1..6, guarantor rating 1..10 | Cells outside the table |
| Coefficient 0..1 | A percentage stored by mistake (92 instead of 0.92) |

The migration script creates the table and inserts the 60 values, written in percent as in the specification and divided by 100 on insert. It can be re-run: `ON CONFLICT` updates existing cells.

---

## 7. API contract

`POST calculate/creditInsurerExpectedRecoveryAmount`, JSON body, authenticated caller. Dates use `yyyy-MM-dd`.

### Request fields

| Field | Type | Rules |
|---|---|---|
| `currentDate` | date | Required |
| `creditInsurerImplementationDate`, `creditInsurerMaturityDate` | date | Required |
| `facilityImplementationDate`, `facilityMaturityDate` | date | Required |
| `creditInsurerType` | text | Required; one of the 8 labels below, or its constant name |
| `creditInsurerCounterpartyRating` | text | Required; 1..10 with optional + or -; above 6 gives a coefficient of 0 |
| `guarantorCounterpartyRating` | text | Required; 1..10 with optional + or - |
| `oecdFlag`, `positiveRecoveryFlag`, `waitingPeriodInterestCovered` | boolean | Required |
| `waitingPeriod` | text | Required; `Less than 31 D`, `31-90 D`, `91-210 D`, `More than 210 D` |
| `pctOfBnppFinancingCoveredByCreditInsurer` | number | Required; 0..100 |
| `facilityAmount` | number | Required; 0 or more (0 confirmed by Clara) |
| `facilityUnit` | text | Required; UNIT, THOUSAND, MILLION, BILLION, TRILLION |
| `prorataShareOfExpectedRecovery` | boolean | Required; not used in the calculations so far |
| `sugrr` | number | Required; 0..100; not used in the calculations so far |

**Credit insurer types:** Guarantee; Guarantee at 1rt demand SBLC; Cross guarantees; Other personal or corporate guarantee; Third party commitments; First demand Guarantee; Insurance policy from ECA; Insurance policy from private insurer.

### Response

```json
{
  "facilityAmountCoveredByCreditInsurer": 8000000.00,
  "expectedRecoveryOnCreditInsurer": 6771600.00,
  "recoveryRateOnCreditInsurerPercent": 84.645000,
  "expectedRecoveryInFacilityCurrency": 6771600.00,
  "drivers": [
    { "name": "CORRELATION_COEFFICIENT",    "value": 0.950000 },
    { "name": "DISCOUNT_MATURITY_MISMATCH", "value": 0.000000 },
    { "name": "WAITING_PERIOD_DECOTE",      "value": 0.010000 },
    { "name": "ADDITIONAL_DECOTE",          "value": 0.100000 }
  ]
}
```

### Errors

| Status | When |
|---|---|
| 400 | A field is missing or invalid (the body lists each field), malformed JSON, an unknown type or waiting period, a percentage outside 0..100 |
| 401 | The caller is not authenticated |
| 415 | The body is not JSON |
| 500 | Anything unexpected, including an incomplete correlation table; details are logged, never returned |

---

## 8. What is shared with the guarantee calculation

| Building block | How credit insurers use it |
|---|---|
| `CounterpartyRating` | Same rating parsing (sign dropped, 1..10) |
| `MaturityDates`, `MaturityAssessment`, `DiscountMaturityMismatchDriver` | Driver 2, unchanged; one new factory method |
| `DayCountConvention` bean | Same ACT/365 Fixed setting |
| `GenericDriver`, `Driver` | Base of the four drivers |
| `UnitAmount`, `Unit` | Facility amount × unit |
| `RatingGrid` | New; used by credit insurers now, available to the guarantee table later |
| `RequiredValues` | New; the guarantee service can switch to it to remove duplicate code |
| Exception handler | Scope extended to the new controller |

---

## 9. Decisions and open points

| Topic | Decision | Status |
|---|---|---|
| Separate table for credit insurers | Own table, not rows in the guarantee table, because the shape differs | Done |
| Credit insurer rated 7 to 10 | Coefficient 0 | Confirmed by Clara |
| `guarantorCounterpartyRating` | The column axis of the credit insurer table | Confirmed by Clara |
| Field types | Booleans, enums and ranges as confirmed | Confirmed by Clara |
| Facility amount of 0 | Allowed | Confirmed by Clara |
| Driver name | `CORRELATION_COEFFICIENT`, same as guarantees | Confirmed by Clara |
| Maturity mismatch | Guarantee rule reused unchanged | Done |
| Credit insurer types | The 3 story values added to the 5 earlier ones | Done |
| "First demand Guarantee" versus "Guarantee at 1rt demand SBLC" | Only the SBLC label is exempt from the waiting period decote; if they are the same, the fix is one line | Open with Clara |
| Gac of 0 | RecupTAC returned as 0 | To confirm with Clara |
| Correlation coefficient in the drivers list | Included as the first driver | To confirm with Clara |
| `sugrr`, `prorataShareOfExpectedRecovery` | Validated but not used yet | Open: later calculation? |
| Percentages as `Float` | Recommended `BigDecimal`: a Float 33.3 converts to 33.29999923706055 | Team decision |
| Endpoint path | `calculate/creditInsurerExpectedRecoveryAmount` | To confirm with crf-back |

---

## 10. Testing

Expected values were worked out by hand from the specification, not copied from the code.

| Level | What it proves |
|---|---|
| Domain unit tests | Every table cell checked against the business table; ratings above 6; each waiting period and the SBLC and interest-not-covered exemptions; the full additional decote truth table; Gac for amounts of 0 and 0%; the worked example; all factors combined; not started yet; Gac of 0. 100% of lines and branches |
| Deliberate-bug check | `||` changed to `&&` in both decote rules, the coefficient used as 1 − x, RecupEAC_F set to Gac, rating 6 treated as outside the table: each one makes tests fail |
| Infrastructure tests | 60 rows to table in any order; no rows, a missing cell and out-of-range ratings are server errors; the cache reads once, evicts and does not cache failures |
| Application tests | End-to-end through the domain with the real table; labels and constant names; every invalid input is a 400 with a field-specific message |
| Response tests | Names, order and rounding of every output |

167 credit insurer tests (436 in the module, all passing). Controller slice tests and an integration test for the new endpoint follow the guarantee ones and are the next step.

---

## 11. Glossary

| Term | Meaning |
|---|---|
| Credit insurer | The insurance company (or agency) that covers part of the loan |
| Facility | The loan or credit line the bank provides |
| ECA | Export credit agency |
| OECD flag, positive recovery flag | Flags sent by crf-back; either one triggers the additional decote on an ECA policy |
| Decote | French for discount |
| Gac | Amount of the facility covered by the credit insurer |
| Dmm | Discount related to a maturity mismatch |
| Ddci | Waiting period decote |
| Dfe | Additional decote |
| RecupEAC | Expected recovery on the credit insurer |
| RecupTAC | Recovery rate on the credit insurer, as a percentage of Gac |
| RecupEAC_F | Expected recovery in the facility currency |
