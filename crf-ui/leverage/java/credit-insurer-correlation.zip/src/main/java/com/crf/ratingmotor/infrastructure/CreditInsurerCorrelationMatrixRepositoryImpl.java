package com.crf.ratingmotor.infrastructure;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrix;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrixRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrix.CREDIT_INSURER_RATINGS;
import static com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrix.GUARANTOR_RATINGS;

/** Reads the 60 rows and assembles the 6 x 10 table. Missing or out-of-range data is a server error. */
@Repository
@RequiredArgsConstructor
class CreditInsurerCorrelationMatrixRepositoryImpl implements CreditInsurerCorrelationMatrixRepository {

    private final CreditInsurerCorrelationCoefficientDao dao;

    @Override
    @Transactional(readOnly = true)
    public CreditInsurerCorrelationMatrix load() {
        List<CreditInsurerCorrelationCoefficientEntity> rows = dao.findAll();
        if (rows.isEmpty()) {
            throw new IllegalStateException("No credit insurer correlation coefficients found");
        }
        RoundedValue[][] cells = new RoundedValue[CREDIT_INSURER_RATINGS][GUARANTOR_RATINGS];
        rows.forEach(row -> cells[toIndex(row.getCreditInsurerRating(), CREDIT_INSURER_RATINGS, "credit insurer")]
                                 [toIndex(row.getGuarantorRating(), GUARANTOR_RATINGS, "guarantor")]
                                 = RoundedValue.of(row.getCoefficient()));
        try {
            return new CreditInsurerCorrelationMatrix(cells);
        } catch (IllegalArgumentException e) {
            throw new IllegalStateException("Credit insurer correlation coefficient data is incomplete", e);
        }
    }

    private static int toIndex(int rating, int size, String axis) {
        if (rating < 1 || rating > size) {
            throw new IllegalStateException("Credit insurer table: " + axis + " rating out of range in database: " + rating);
        }
        return rating - 1;
    }
}
