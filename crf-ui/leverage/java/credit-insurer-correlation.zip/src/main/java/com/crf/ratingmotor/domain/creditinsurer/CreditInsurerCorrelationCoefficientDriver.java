package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.domain.CounterpartyRating;
import com.crf.ratingmotor.domain.GenericDriver;

import java.util.Objects;

/** Correlation coefficient between the debtor and the credit insurer, looked up in the 6 x 10 table. */
public final class CreditInsurerCorrelationCoefficientDriver extends GenericDriver {

    public static final String NAME = "CORRELATION_COEFFICIENT";

    private final CounterpartyRating creditInsurerRating;
    private final CounterpartyRating guarantorRating;

    public CreditInsurerCorrelationCoefficientDriver(CreditInsurerCorrelationMatrix matrix,
                                                     CounterpartyRating creditInsurerRating,
                                                     CounterpartyRating guarantorRating) {
        super(NAME);
        Objects.requireNonNull(matrix, "matrix");
        this.creditInsurerRating = Objects.requireNonNull(creditInsurerRating, "creditInsurerRating");
        this.guarantorRating = Objects.requireNonNull(guarantorRating, "guarantorRating");
        this.estimateValue = matrix.coefficientFor(creditInsurerRating, guarantorRating);
    }

    public CounterpartyRating creditInsurerRating() { return creditInsurerRating; }
    public CounterpartyRating guarantorRating()     { return guarantorRating; }
}
