package com.crf.ratingmotor.infrastructure;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/** One cell of the 6 x 10 credit insurer correlation table. The coefficient is a fraction (92% = 0.92). */
@Entity
@Table(name = "facility_grr_pgnnr_credit_insurer_correlation_coefficient_matrix",
       uniqueConstraints = @UniqueConstraint(name = "uq_credit_insurer_correlation_cell",
                                             columnNames = {"credit_insurer_rating", "guarantor_rating"}))
@Getter
@Setter
@NoArgsConstructor
public class CreditInsurerCorrelationCoefficientEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)   // use the same id mapping as CorrelationCoefficientEntity
    private Long id;

    @Column(name = "credit_insurer_rating", nullable = false)
    private short creditInsurerRating;

    @Column(name = "guarantor_rating", nullable = false)
    private short guarantorRating;

    @Column(name = "coefficient", nullable = false, precision = 10, scale = 6)
    private BigDecimal coefficient;
}
