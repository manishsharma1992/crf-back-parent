package com.crf.ratingmotor.infrastructure;

import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrix;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrixRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

/** Serves the credit insurer table from the cache; reads the database once until evicted. */
@Primary
@Repository
class CachingCreditInsurerCorrelationMatrixRepository implements CreditInsurerCorrelationMatrixRepository {

    /** The table has a single version, so it is cached under one fixed key. */
    static final String KEY = "CREDIT_INSURER";

    private final CreditInsurerCorrelationMatrixRepository delegate;
    private final Cache cache;

    CachingCreditInsurerCorrelationMatrixRepository(
            @Qualifier("creditInsurerCorrelationMatrixRepositoryImpl") CreditInsurerCorrelationMatrixRepository delegate,
            CacheManager cacheManager) {
        this.delegate = delegate;
        this.cache = cacheManager.getCache(CacheNames.CREDIT_INSURER_CORRELATION_MATRIX.getCacheName());
    }

    @Override
    public CreditInsurerCorrelationMatrix load() {
        return cache.get(KEY, delegate::load);
    }

    public void evict() {
        cache.clear();
    }
}
