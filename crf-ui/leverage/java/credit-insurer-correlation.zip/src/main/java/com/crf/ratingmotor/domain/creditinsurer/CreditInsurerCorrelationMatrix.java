package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.RoundedValue;
import com.crf.ratingmotor.domain.CounterpartyRating;
import com.crf.ratingmotor.domain.RatingGrid;

/**
 * Correlation coefficients between the debtor and the credit insurer.
 *
 * <p>6 x 10 table: the credit insurer's rating (1 to 6) picks the row, the guarantor's rating (1 to 10)
 * picks the column. Values are fractions: 92% is stored and used as 0.92.</p>
 */
public final class CreditInsurerCorrelationMatrix {

    public static final int CREDIT_INSURER_RATINGS = 6;
    public static final int GUARANTOR_RATINGS = 10;

    private final RatingGrid grid;

    public CreditInsurerCorrelationMatrix(RoundedValue[][] cells) {
        this.grid = new RatingGrid("Credit insurer correlation", CREDIT_INSURER_RATINGS, GUARANTOR_RATINGS, cells);
    }

    public RoundedValue coefficientFor(CounterpartyRating creditInsurerRating, CounterpartyRating guarantorRating) {
        return grid.at(creditInsurerRating, guarantorRating);
    }
}
