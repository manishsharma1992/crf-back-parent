package com.crf.ratingmotor.application.creditinsurer;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Request from crf-back for the credit insurer expected recovery.
 *
 * <p>Only the two ratings used by the first driver are validated so far. The other fields keep the
 * types given in the draft; their types and rules are added once Clara confirms them.</p>
 */
@Schema(description = "Inputs sent by crf-back to compute the expected recovery on a credit insurance")
public record CreditInsurerComputeQuery(
    LocalDate currentDate,
    LocalDate creditInsurerImplementationDate,
    LocalDate creditInsurerMaturityDate,
    String creditInsurerType,

    @Schema(description = "Credit insurer rating 1..6, optionally followed by + or -", example = "1-")
    @NotBlank @Pattern(regexp = "\\s*(10|[1-9])[+-]?\\s*", message = "must be 1..10 optionally followed by + or -")
    String creditInsurerCounterpartyRating,

    String oecdFlag,
    String positiveRecoveryFlag,
    String waitingPeriodInterestCovered,
    String waitingPeriod,
    BigDecimal pctOfBnppFinancingCoveredByCreditInsurer,
    String prorataShareOfExpectedRecovery,
    String sugrr,
    BigDecimal pctOfBnppCoveredByCreditInsurer,
    LocalDate facilityImplementationDate,
    LocalDate facilityMaturityDate,
    BigDecimal facilityAmount,

    @Schema(description = "Guarantor rating 1..10, optionally followed by + or -", example = "6+")
    @NotBlank @Pattern(regexp = "\\s*(10|[1-9])[+-]?\\s*", message = "must be 1..10 optionally followed by + or -")
    String guarantorCounterpartyRating
) {}
