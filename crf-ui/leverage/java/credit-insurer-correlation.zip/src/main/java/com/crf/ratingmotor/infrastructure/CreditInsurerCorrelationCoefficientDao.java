package com.crf.ratingmotor.infrastructure;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CreditInsurerCorrelationCoefficientDao extends JpaRepository<CreditInsurerCorrelationCoefficientEntity, Long> {
}
