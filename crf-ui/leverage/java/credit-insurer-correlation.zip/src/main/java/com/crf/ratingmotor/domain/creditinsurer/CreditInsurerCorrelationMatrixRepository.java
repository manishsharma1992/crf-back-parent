package com.crf.ratingmotor.domain.creditinsurer;

/** Domain port: where the credit insurer coefficient table comes from is an infrastructure concern. */
public interface CreditInsurerCorrelationMatrixRepository {
    CreditInsurerCorrelationMatrix load();
}
