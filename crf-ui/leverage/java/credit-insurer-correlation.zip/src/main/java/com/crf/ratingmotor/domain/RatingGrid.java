package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;

import java.util.Objects;

/**
 * An immutable, fully populated table of coefficients addressed by two counterparty ratings:
 * the row rating (y axis, top to bottom) and the column rating (x axis, left to right).
 *
 * <p>Shared building block for coefficient tables whose size differs by use case, such as the
 * 6 x 10 credit insurer table. On construction it checks the exact size and that no cell is empty,
 * and it keeps a defensive copy, so a grid can be cached and shared safely.</p>
 */
public final class RatingGrid {

    private final String name;
    private final int rows;
    private final int columns;
    private final RoundedValue[][] cells;

    public RatingGrid(String name, int rows, int columns, RoundedValue[][] cells) {
        this.name = Objects.requireNonNull(name, "name");
        if (rows < 1 || rows > 10 || columns < 1 || columns > 10) {
            throw new IllegalArgumentException(name + ": size must be between 1 and 10 ratings, got " + rows + " x " + columns);
        }
        this.rows = rows;
        this.columns = columns;
        validate(cells);
        this.cells = copy(cells);
    }

    /**
     * Coefficient at (row rating, column rating). A rating outside the table is a client error, because
     * the table does not define a coefficient for it.
     */
    public RoundedValue at(CounterpartyRating row, CounterpartyRating column) {
        Objects.requireNonNull(row, "row rating");
        Objects.requireNonNull(column, "column rating");
        requireCovered(row, rows, "row");
        requireCovered(column, columns, "column");
        return cells[row.value() - 1][column.value() - 1];
    }

    public int rows() {
        return rows;
    }

    public int columns() {
        return columns;
    }

    private void requireCovered(CounterpartyRating rating, int size, String axis) {
        if (rating.value() > size) {
            throw new IllegalArgumentException(
                name + ": no " + axis + " for rating " + rating.value() + ", the table covers ratings 1 to " + size);
        }
    }

    private void validate(RoundedValue[][] source) {
        Objects.requireNonNull(source, "cells");
        if (source.length != rows) {
            throw new IllegalArgumentException(name + ": expected " + rows + " rows but got " + source.length);
        }
        for (int row = 0; row < rows; row++) {
            validateRow(row, source[row]);
        }
    }

    private void validateRow(int row, RoundedValue[] values) {
        if (values == null || values.length != columns) {
            throw new IllegalArgumentException(name + ": row " + (row + 1) + " must have " + columns + " columns");
        }
        for (int column = 0; column < columns; column++) {
            if (values[column] == null) {
                throw new IllegalArgumentException(
                    name + ": missing coefficient at row " + (row + 1) + ", column " + (column + 1));
            }
        }
    }

    private RoundedValue[][] copy(RoundedValue[][] source) {
        RoundedValue[][] result = new RoundedValue[rows][];
        for (int row = 0; row < rows; row++) {
            result[row] = source[row].clone();   // RoundedValue is immutable, so a row clone is a deep copy
        }
        return result;
    }
}
