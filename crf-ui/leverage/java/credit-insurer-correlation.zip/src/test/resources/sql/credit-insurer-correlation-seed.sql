-- Test data for the credit insurer integration test. Portable: runs on H2 and PostgreSQL.
-- Runs inside the test transaction and is rolled back after each test.
-- id is numbered 1..60 because the H2 test schema has no default for it.

DELETE FROM facility_grr_pgnnr_credit_insurer_correlation_coefficient_matrix;

INSERT INTO facility_grr_pgnnr_credit_insurer_correlation_coefficient_matrix
    (id, credit_insurer_rating, guarantor_rating, coefficient)
SELECT ROW_NUMBER() OVER (ORDER BY m.credit_insurer_rating, g.guarantor_rating),
       m.credit_insurer_rating,
       g.guarantor_rating,
       CASE g.guarantor_rating
           WHEN 1 THEN m.g1  WHEN 2 THEN m.g2  WHEN 3 THEN m.g3  WHEN 4 THEN m.g4  WHEN 5 THEN m.g5
           WHEN 6 THEN m.g6  WHEN 7 THEN m.g7  WHEN 8 THEN m.g8  WHEN 9 THEN m.g9  ELSE m.g10
       END / 100.0
FROM (VALUES
    --  guarantor:  1      2      3      4      5      6      7      8      9     10
    (1,          100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0),
    (2,          100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0),
    (3,            0.0,   0.0,   0.0,  92.0,  95.0,  98.0,  99.0,  99.1,  99.2,  99.3),
    (4,            0.0,   0.0,   0.0,   0.0,  91.0,  96.0,  98.0,  99.0,  99.1,  99.2),
    (5,            0.0,   0.0,   0.0,   0.0,   0.0,  91.0,  97.0,  98.6,  99.0,  99.1),
    (6,            0.0,   0.0,   0.0,   0.0,   0.0,   0.0,  91.0,  92.0,  93.0,  93.1)
) AS m (credit_insurer_rating, g1, g2, g3, g4, g5, g6, g7, g8, g9, g10)
CROSS JOIN (VALUES (1), (2), (3), (4), (5), (6), (7), (8), (9), (10)) AS g (guarantor_rating);
