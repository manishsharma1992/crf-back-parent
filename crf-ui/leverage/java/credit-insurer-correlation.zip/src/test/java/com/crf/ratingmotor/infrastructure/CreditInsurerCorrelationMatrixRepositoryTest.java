package com.crf.ratingmotor.infrastructure;

import com.crf.ratingmotor.domain.CounterpartyRating;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrix;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerCorrelationMatrixRepository;
import com.crf.ratingmotor.domain.creditinsurer.CreditInsurerTables;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.cache.Cache;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalStateException;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CreditInsurerCorrelationMatrixRepositoryTest {

    /** Adapt this one method if your entity is built with a constructor or a builder instead of setters. */
    static CreditInsurerCorrelationCoefficientEntity entity(int creditInsurerRating, int guarantorRating, BigDecimal coefficient) {
        CreditInsurerCorrelationCoefficientEntity e = new CreditInsurerCorrelationCoefficientEntity();
        e.setCreditInsurerRating((short) creditInsurerRating);
        e.setGuarantorRating((short) guarantorRating);
        e.setCoefficient(coefficient);
        return e;
    }

    /** The 60 rows of the business table. */
    static List<CreditInsurerCorrelationCoefficientEntity> fullTable() {
        List<CreditInsurerCorrelationCoefficientEntity> rows = new ArrayList<>();
        for (int r = 1; r <= 6; r++) {
            for (int g = 1; g <= 10; g++) {
                rows.add(entity(r, g, CreditInsurerTables.fraction(r, g)));
            }
        }
        return rows;
    }

    private static CounterpartyRating rating(int v) {
        return new CounterpartyRating(v);
    }

    @Nested
    @DisplayName("JPA adapter")
    class Adapter {

        private CreditInsurerCorrelationCoefficientDao dao;
        private CreditInsurerCorrelationMatrixRepositoryImpl repository;

        @BeforeEach
        void setUp() {
            dao = mock(CreditInsurerCorrelationCoefficientDao.class);
            repository = new CreditInsurerCorrelationMatrixRepositoryImpl(dao);
        }

        @Test
        @DisplayName("maps the 60 rows into the 6 x 10 table, in any order")
        void mapsRows() {
            List<CreditInsurerCorrelationCoefficientEntity> rows = fullTable();
            Collections.reverse(rows);
            when(dao.findAll()).thenReturn(rows);

            CreditInsurerCorrelationMatrix matrix = repository.load();

            assertExactly(matrix.coefficientFor(rating(3), rating(4)), "0.92");
            assertExactly(matrix.coefficientFor(rating(5), rating(8)), "0.986");
            assertExactly(matrix.coefficientFor(rating(6), rating(10)), "0.931");
            assertExactly(matrix.coefficientFor(rating(1), rating(1)), "1");
        }

        @Test
        void noRows() {
            when(dao.findAll()).thenReturn(List.of());
            assertThatIllegalStateException()
                .isThrownBy(() -> repository.load())
                .withMessage("No credit insurer correlation coefficients found");
        }

        @Test
        @DisplayName("a missing row is a server error naming the missing cell")
        void missingRow() {
            List<CreditInsurerCorrelationCoefficientEntity> rows = fullTable();
            rows.removeIf(e -> e.getCreditInsurerRating() == 4 && e.getGuarantorRating() == 9);
            when(dao.findAll()).thenReturn(rows);

            assertThatIllegalStateException()
                .isThrownBy(() -> repository.load())
                .withMessage("Credit insurer correlation coefficient data is incomplete")
                .satisfies(e -> assertThat(e.getCause())
                    .hasMessage("Credit insurer correlation: missing coefficient at row 4, column 9"));
        }

        @ParameterizedTest(name = "credit insurer rating {0} in the database is rejected")
        @ValueSource(ints = {0, 7, 10})
        void creditInsurerRatingOutOfRange(int value) {
            List<CreditInsurerCorrelationCoefficientEntity> rows = fullTable();
            rows.add(entity(value, 1, BigDecimal.ONE));
            when(dao.findAll()).thenReturn(rows);

            assertThatIllegalStateException()
                .isThrownBy(() -> repository.load())
                .withMessage("Credit insurer table: credit insurer rating out of range in database: " + value);
        }

        @ParameterizedTest(name = "guarantor rating {0} in the database is rejected")
        @ValueSource(ints = {0, 11})
        void guarantorRatingOutOfRange(int value) {
            List<CreditInsurerCorrelationCoefficientEntity> rows = fullTable();
            rows.add(entity(1, value, BigDecimal.ONE));
            when(dao.findAll()).thenReturn(rows);

            assertThatIllegalStateException()
                .isThrownBy(() -> repository.load())
                .withMessage("Credit insurer table: guarantor rating out of range in database: " + value);
        }
    }

    @Nested
    @DisplayName("cache")
    class Caching {

        private int loads;
        private boolean fail;
        private CachingCreditInsurerCorrelationMatrixRepository repository;

        @BeforeEach
        void setUp() {
            CreditInsurerCorrelationMatrixRepository delegate = () -> {
                loads++;
                if (fail) {
                    throw new IllegalStateException("database down");
                }
                return CreditInsurerTables.matrix();
            };
            repository = new CachingCreditInsurerCorrelationMatrixRepository(delegate,
                new ConcurrentMapCacheManager(CacheNames.CREDIT_INSURER_CORRELATION_MATRIX.getCacheName()));
        }

        @Test
        @DisplayName("the table is read once and then served from the cache")
        void cachesAfterFirstLoad() {
            CreditInsurerCorrelationMatrix first = repository.load();
            CreditInsurerCorrelationMatrix second = repository.load();

            assertThat(second).isSameAs(first);
            assertThat(loads).isEqualTo(1);
        }

        @Test
        void evictForcesReload() {
            repository.load();
            repository.evict();
            repository.load();

            assertThat(loads).isEqualTo(2);
        }

        @Test
        @DisplayName("a failed load is not cached")
        void failuresAreNotCached() {
            fail = true;
            assertThatThrownBy(() -> repository.load())
                .isInstanceOf(Cache.ValueRetrievalException.class)
                .hasCauseInstanceOf(IllegalStateException.class);

            fail = false;
            assertThat(repository.load()).isNotNull();
            assertThat(loads).isEqualTo(2);
        }

        @Test
        void cacheName() {
            assertThat(CacheNames.CREDIT_INSURER_CORRELATION_MATRIX.getCacheName()).isEqualTo("creditInsurerCorrelationMatrix");
        }
    }
}
