package com.crf.ratingmotor.domain.creditinsurer;

import com.crf.ratingmotor.common.RoundedValue;

import java.math.BigDecimal;

/** The business table, in percent exactly as specified, converted to fractions (92.0 -> 0.92). */
public final class CreditInsurerTables {

    /** Rows: credit insurer rating 1..6. Columns: guarantor rating 1..10. */
    public static final String[][] PERCENTAGES = {
        {"100", "100", "100", "100",  "100",  "100",  "100",  "100",  "100",  "100"},
        {"100", "100", "100", "100",  "100",  "100",  "100",  "100",  "100",  "100"},
        {"0",   "0",   "0",   "92.0", "95.0", "98.0", "99.0", "99.1", "99.2", "99.3"},
        {"0",   "0",   "0",   "0",    "91.0", "96.0", "98.0", "99.0", "99.1", "99.2"},
        {"0",   "0",   "0",   "0",    "0",    "91.0", "97.0", "98.6", "99.0", "99.1"},
        {"0",   "0",   "0",   "0",    "0",    "0",    "91.0", "92.0", "93.0", "93.1"}
    };

    private CreditInsurerTables() {}

    public static BigDecimal fraction(int creditInsurerRating, int guarantorRating) {
        return new BigDecimal(PERCENTAGES[creditInsurerRating - 1][guarantorRating - 1]).movePointLeft(2);
    }

    public static RoundedValue[][] cells() {
        RoundedValue[][] cells = new RoundedValue[6][10];
        for (int r = 1; r <= 6; r++) {
            for (int g = 1; g <= 10; g++) {
                cells[r - 1][g - 1] = RoundedValue.of(fraction(r, g));
            }
        }
        return cells;
    }

    public static CreditInsurerCorrelationMatrix matrix() {
        return new CreditInsurerCorrelationMatrix(cells());
    }
}
