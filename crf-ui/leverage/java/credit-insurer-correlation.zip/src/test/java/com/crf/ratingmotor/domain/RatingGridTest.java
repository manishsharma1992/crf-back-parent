package com.crf.ratingmotor.domain;

import com.crf.ratingmotor.common.RoundedValue;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static com.crf.ratingmotor.domain.TestValues.assertExactly;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatIllegalArgumentException;
import static org.assertj.core.api.Assertions.assertThatNullPointerException;

class RatingGridTest {

    /** row r, column c holds r.0c (row 2, column 3 = 2.03), so every cell is unique. */
    private static RoundedValue[][] cells(int rows, int columns) {
        RoundedValue[][] cells = new RoundedValue[rows][columns];
        for (int r = 1; r <= rows; r++) {
            for (int c = 1; c <= columns; c++) {
                cells[r - 1][c - 1] = RoundedValue.of(r + "." + (c < 10 ? "0" + c : "" + c));
            }
        }
        return cells;
    }

    private static CounterpartyRating rating(int value) {
        return new CounterpartyRating(value);
    }

    @Nested
    @DisplayName("lookup")
    class Lookup {

        private final RatingGrid grid = new RatingGrid("Test", 6, 10, cells(6, 10));

        @Test
        @DisplayName("the row rating picks the row and the column rating picks the column")
        void orientation() {
            assertExactly(grid.at(rating(2), rating(3)), "2.03");
            assertExactly(grid.at(rating(3), rating(2)), "3.02");
        }

        @Test
        void corners() {
            assertExactly(grid.at(rating(1), rating(1)), "1.01");
            assertExactly(grid.at(rating(6), rating(10)), "6.10");
        }

        @Test
        void exposesSize() {
            assertThat(grid.rows()).isEqualTo(6);
            assertThat(grid.columns()).isEqualTo(10);
        }

        @Test
        @DisplayName("a row rating beyond the table is rejected with the covered range")
        void rowOutOfTable() {
            assertThatIllegalArgumentException()
                .isThrownBy(() -> grid.at(rating(7), rating(1)))
                .withMessage("Test: no row for rating 7, the table covers ratings 1 to 6");
        }

        @Test
        @DisplayName("a column rating beyond the table is rejected with the covered range")
        void columnOutOfTable() {
            RatingGrid narrow = new RatingGrid("Narrow", 3, 4, cells(3, 4));
            assertThatIllegalArgumentException()
                .isThrownBy(() -> narrow.at(rating(1), rating(5)))
                .withMessage("Narrow: no column for rating 5, the table covers ratings 1 to 4");
        }

        @Test
        void rejectsNullRatings() {
            CounterpartyRating one = rating(1);
            assertThatNullPointerException().isThrownBy(() -> grid.at(null, one)).withMessage("row rating");
            assertThatNullPointerException().isThrownBy(() -> grid.at(one, null)).withMessage("column rating");
        }
    }

    @Nested
    @DisplayName("validation")
    class Validation {

        @ParameterizedTest(name = "{0} x {1} is rejected")
        @CsvSource({"0, 10", "11, 10", "6, 0", "6, 11"})
        void rejectsSizesOutsideOneToTen(int rows, int columns) {
            RoundedValue[][] cells = cells(1, 1);
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new RatingGrid("Test", rows, columns, cells))
                .withMessage("Test: size must be between 1 and 10 ratings, got " + rows + " x " + columns);
        }

        @Test
        void rejectsNullName() {
            RoundedValue[][] cells = cells(6, 10);
            assertThatNullPointerException().isThrownBy(() -> new RatingGrid(null, 6, 10, cells)).withMessage("name");
        }

        @Test
        void rejectsNullCells() {
            assertThatNullPointerException().isThrownBy(() -> new RatingGrid("Test", 6, 10, null)).withMessage("cells");
        }

        @Test
        void rejectsWrongRowCount() {
            RoundedValue[][] cells = cells(5, 10);
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new RatingGrid("Test", 6, 10, cells))
                .withMessage("Test: expected 6 rows but got 5");
        }

        @Test
        void rejectsNullRow() {
            RoundedValue[][] cells = cells(6, 10);
            cells[3] = null;
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new RatingGrid("Test", 6, 10, cells))
                .withMessage("Test: row 4 must have 10 columns");
        }

        @Test
        void rejectsWrongColumnCount() {
            RoundedValue[][] cells = cells(6, 10);
            cells[5] = new RoundedValue[9];
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new RatingGrid("Test", 6, 10, cells))
                .withMessage("Test: row 6 must have 10 columns");
        }

        @Test
        void rejectsMissingCell() {
            RoundedValue[][] cells = cells(6, 10);
            cells[2][7] = null;
            assertThatIllegalArgumentException()
                .isThrownBy(() -> new RatingGrid("Test", 6, 10, cells))
                .withMessage("Test: missing coefficient at row 3, column 8");
        }
    }

    @Test
    @DisplayName("changing the source array after construction does not change the grid")
    void defensiveCopy() {
        RoundedValue[][] cells = cells(6, 10);
        RatingGrid grid = new RatingGrid("Test", 6, 10, cells);

        cells[1][2] = RoundedValue.of("99");
        cells[0] = new RoundedValue[10];

        assertExactly(grid.at(rating(2), rating(3)), "2.03");
        assertExactly(grid.at(rating(1), rating(1)), "1.01");
    }
}
