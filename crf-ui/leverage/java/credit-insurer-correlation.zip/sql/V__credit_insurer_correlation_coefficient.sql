-- Credit insurer correlation coefficients (PostgreSQL).
-- One 6 x 10 table: credit insurer rating 1..6 (row) by guarantor rating 1..10 (column).
-- Values are written in percent exactly as in the specification and stored as fractions (92.0 -> 0.92).
-- Re-runnable: ON CONFLICT updates the coefficient of an existing cell.

CREATE TABLE IF NOT EXISTS facility_grr_pgnnr_credit_insurer_correlation_coefficient_matrix (
    id                    BIGSERIAL     PRIMARY KEY,   -- align with the id strategy of the guarantee table
    credit_insurer_rating SMALLINT      NOT NULL,
    guarantor_rating      SMALLINT      NOT NULL,
    coefficient           NUMERIC(10,6) NOT NULL,
    CONSTRAINT uq_credit_insurer_correlation_cell UNIQUE (credit_insurer_rating, guarantor_rating),
    CONSTRAINT ck_credit_insurer_rating CHECK (credit_insurer_rating BETWEEN 1 AND 6),
    CONSTRAINT ck_credit_insurer_guarantor_rating CHECK (guarantor_rating BETWEEN 1 AND 10),
    CONSTRAINT ck_credit_insurer_coefficient CHECK (coefficient BETWEEN 0 AND 1)
);

INSERT INTO facility_grr_pgnnr_credit_insurer_correlation_coefficient_matrix
    (credit_insurer_rating, guarantor_rating, coefficient)
SELECT m.credit_insurer_rating,
       g.guarantor_rating,
       CASE g.guarantor_rating
           WHEN 1 THEN m.g1  WHEN 2 THEN m.g2  WHEN 3 THEN m.g3  WHEN 4 THEN m.g4  WHEN 5 THEN m.g5
           WHEN 6 THEN m.g6  WHEN 7 THEN m.g7  WHEN 8 THEN m.g8  WHEN 9 THEN m.g9  ELSE m.g10
       END / 100.0
FROM (VALUES
    --  guarantor:  1      2      3      4      5      6      7      8      9     10
    (1,          100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0),
    (2,          100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0),
    (3,            0.0,   0.0,   0.0,  92.0,  95.0,  98.0,  99.0,  99.1,  99.2,  99.3),
    (4,            0.0,   0.0,   0.0,   0.0,  91.0,  96.0,  98.0,  99.0,  99.1,  99.2),
    (5,            0.0,   0.0,   0.0,   0.0,   0.0,  91.0,  97.0,  98.6,  99.0,  99.1),
    (6,            0.0,   0.0,   0.0,   0.0,   0.0,   0.0,  91.0,  92.0,  93.0,  93.1)
) AS m (credit_insurer_rating, g1, g2, g3, g4, g5, g6, g7, g8, g9, g10)
CROSS JOIN (VALUES (1), (2), (3), (4), (5), (6), (7), (8), (9), (10)) AS g (guarantor_rating)
ON CONFLICT ON CONSTRAINT uq_credit_insurer_correlation_cell
DO UPDATE SET coefficient = EXCLUDED.coefficient;
